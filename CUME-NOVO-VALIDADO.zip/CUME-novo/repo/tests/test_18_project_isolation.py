"""CUME-ISO-001: CUME must remain structurally and operationally independent from HUMAN-OMEGA."""
import json, re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BP = ROOT.parent / 'blueprint'
POLICY = ROOT / 'governance' / 'project_isolation_policy_v1.json'

checks = 0

def ok(cond, msg):
    global checks
    assert cond, msg
    checks += 1

ok(POLICY.exists(), 'CUME-ISO-001 policy artifact is missing')
policy = json.loads(POLICY.read_text(encoding='utf-8'))

ok(policy['policy_id'] == 'CUME-ISO-001', 'wrong policy id')
ok(policy['project'] == 'CUME', 'policy must govern CUME only')
ok(policy['independence_mode'] == 'HARD_PROJECT_ISOLATION', 'hard isolation must be explicit')
ok(policy['exceptions_allowed'] is False, 'isolation exceptions are not allowed')
ok(policy['cross_project_runtime_calls_allowed'] is False, 'cross-project runtime calls must be forbidden')
ok(policy['cross_project_package_dependencies_allowed'] is False, 'shared/cross-project package dependency must be forbidden')

required = {
    'source_repository','cloud_project','database_cluster','database_credentials',
    'iam_client_or_tenant','secrets','object_storage','queue_or_job_runtime',
    'observability_project','ci_cd_credentials','backup','disaster_recovery',
    'deployment_runtime','environment_namespace'
}
ok(required <= set(policy['must_be_dedicated']), 'dedicated-resource set is incomplete')

# Active runtime/configuration must not contain HUMAN-OMEGA coupling. Historical/reference
# material and the isolation policy/ADR may name it only to document the prohibition.
forbidden = re.compile(r'human[-_ ]?omega|humanomega', re.I)
active_roots = [ROOT/'db', ROOT/'domain_ref', ROOT/'spec', ROOT/'scripts', BP]
violations = []
for base in active_roots:
    if not base.exists():
        continue
    for path in base.rglob('*'):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT.parent)
        rels = rel.as_posix()
        if rels.startswith('blueprint/13_governance/'):
            continue
        if rels == 'blueprint/10_ai_ml/humanomega_mapping.md':
            # This active-path file must be removed/superseded; flag it by filename even if empty.
            violations.append(rels)
            continue
        if path.suffix.lower() not in {'.md','.yaml','.yml','.json','.sql','.py','.toml','.ini','.env','.ts','.tsx','.js','.mjs','.cjs','.ttl','.csv'}:
            continue
        try:
            text = path.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            continue
        if forbidden.search(text):
            violations.append(rels)
ok(not violations, f'active CUME architecture/runtime contains HUMAN-OMEGA coupling: {violations[:10]}')

print(f'== 18 project isolation: {checks} ok, 0 falha(s)')
