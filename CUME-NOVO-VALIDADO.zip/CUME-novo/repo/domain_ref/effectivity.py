"""CUME reference effectivity rules.

B-10: pricing reference time is the performed-item service instant. Version windows
are half-open [effective_from, effective_to). No caller-selected divergent date.
"""
from dataclasses import dataclass
from datetime import datetime

class EffectivityError(ValueError):
    pass

@dataclass(frozen=True)
class VersionWindow:
    version_id: str
    key: str
    effective_from: datetime
    effective_to: datetime|None


def _aware(value: datetime) -> bool:
    return isinstance(value,datetime) and value.tzinfo is not None and value.utcoffset() is not None


def select_effective(windows, at: datetime) -> VersionWindow:
    if not _aware(at):
        raise EffectivityError('reference instant must be timezone-aware')
    matches=[]
    for w in windows:
        if not _aware(w.effective_from) or (w.effective_to is not None and not _aware(w.effective_to)):
            raise EffectivityError('version window must be timezone-aware')
        if w.effective_to is not None and w.effective_to <= w.effective_from:
            raise EffectivityError('invalid version window')
        if at >= w.effective_from and (w.effective_to is None or at < w.effective_to):
            matches.append(w)
    if len(matches)!=1:
        raise EffectivityError(f'exactly one effective version required; found {len(matches)}')
    return matches[0]


def pricing_reference_at(performed_at: datetime, caller_reference_at: datetime|None=None) -> datetime:
    if not _aware(performed_at):
        raise EffectivityError('performed_at must be timezone-aware')
    if caller_reference_at is not None:
        if not _aware(caller_reference_at):
            raise EffectivityError('caller reference must be timezone-aware')
        if caller_reference_at != performed_at:
            raise EffectivityError('reference_at must equal performed_at')
    return performed_at
