#!/usr/bin/env python3
"""Extrai a classe Component do protótipo v2 (HTML do ChatGPT/Arley) para /tmp/v2_class.js. Uso: python3 extract_class.py <caminho do html>"""
import re,json,sys
h=open(sys.argv[1],encoding='utf-8').read()
t=json.loads(re.search(r'<script[^>]*type="__bundler/template"[^>]*>(.*?)</script>',h,re.S).group(1).strip())
js=re.search(r'<script type="text/x-dc"[^>]*>(.*?)</script>',t,re.S).group(1)
open('/tmp/v2_class.js','w').write(js);print('classe extraída:',len(js),'bytes')
