# ADR-0013 — Isolamento de tenant: FK composto + RLS + separação de roles
Status: PROPOSED (candidate; sem revisor independente) · Data: 2026-10-01

## Contexto
FATO (reproduzido): sem 0003 o banco aceitava referência cross-tenant; sem 0005 qualquer sessão lia todos os tenants.

## Alternativas
1. Só FK composto — impede *referência* cross-tenant, NÃO impede *leitura/escrita* de outro tenant. Insuficiente sozinho.
2. Só RLS — impede acesso, mas não garante integridade referencial entre linhas do mesmo banco. Insuficiente sozinho.
3. Schema/DB por tenant — isolamento forte, custo operacional alto; DEFER até haver evidência de requisito contratual.
4. FK composto + RLS + roles sem privilégio de DDL/DELETE/TRUNCATE — ESCOLHIDA.

## Decisão
- Integridade: 0003 (33 FKs compostos). Acesso: 0005 (RLS fail-closed em 27 tabelas, policy por `app.tenant_id`).
- `cume_app`: sem DELETE, sem TRUNCATE, sem DDL, sem UPDATE em audit_event/document_version/evidence. `cume_auditor`: somente leitura.
- Correção = adjustment/reversal/estado, nunca remoção.

## Verificado (receipt_cycle1c_rls_roles.txt)
Sem contexto => 0 linhas; contexto A não vê B; INSERT para B com contexto A barrado; UPDATE cross-tenant = 0 linhas (estado conferido); DELETE/TRUNCATE/DROP/DISABLE TRIGGER barrados; trigger de teto continua ativo sob RLS.

## Limites / riscos residuais
- `app.tenant_id` é GUC de sessão: um `cume_app` comprometido pode trocá-lo. RLS protege contra BUG de aplicação, não contra aplicação comprometida. Mitigação a desenhar: contexto setado por camada de autenticação via `SET LOCAL` por transação + pooler que reseta sessão (NÃO testado).
- Owner/superusuário bypassa RLS e triggers: credenciais de migração fora do runtime (NÃO implementado).
- Performance de RLS não medida. Sem teste de pooler. Sem revisão de segurança independente.
## Revisão: reabrir se houver requisito de isolamento físico por cliente.
