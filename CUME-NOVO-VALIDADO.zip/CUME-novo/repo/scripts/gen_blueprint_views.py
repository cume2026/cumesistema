#!/usr/bin/env python3
"""Generate/check derived CUME blueprint views from canonical specs and migrations.

Generated outputs:
- blueprint/01_taxonomy/generated_catalog.yaml (DDL-derived relation catalog)
- blueprint/02_ontology/cume.ttl (ontology view)
- blueprint/03_state_machines/state_machines.mmd (state-machine view)
- repo/docs/erd.mmd (DDL/ontology ERD view)
- 00_START_HERE/MASTER_INDEX.md (current package index)

`--check` is fail-closed and performs no writes.
"""
from __future__ import annotations
import re,sys,yaml
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
PKG=ROOT.parent
BP=PKG/'blueprint'
sys.path.insert(0,str(Path(__file__).resolve().parent))
from generate_data_inventory_from_migrations import build_schema

onto=yaml.safe_load((BP/'02_ontology'/'onto_ops_cume.yaml').read_text(encoding='utf-8'))
sm=yaml.safe_load((ROOT/'spec'/'state_machines.yaml').read_text(encoding='utf-8'))['machines']

def iri(s): return re.sub(r'[^A-Za-z0-9_]','_',s)

def migration_range():
    fs=sorted((ROOT/'db/migrations').glob('0*.sql'))
    if not fs: return 'NONE',[]
    ids=[f.name.split('_',1)[0] for f in fs]
    return f'{ids[0]}–{ids[-1]}',fs

def relation_catalog():
    schema=build_schema(ROOT/'db/migrations')
    out=[]
    for sch in sorted({s for s,_ in schema}):
        rels=[]
        for (s,t),cols in sorted(schema.items()):
            if s!=sch: continue
            is_view=bool(cols) and all(v.get('data_type')=='UNKNOWN_VIEW_DERIVED' for v in cols.values())
            rels.append({'name':t,'kind':'VIEW' if is_view else 'TABLE','columns':len(cols)})
        out.append({'name':sch,'relations':rels})
    return out

def render_catalog():
    mr,_=migration_range()
    doc={
        'generated': True,
        'generated_by':'repo/scripts/gen_blueprint_views.py',
        'source':'repo/db/migrations/*.sql',
        'migration_range':mr,
        'note':'Static DDL-derived catalog. Live PostgreSQL catalog remains stronger evidence when executed.',
        'schemas':relation_catalog(),
    }
    return yaml.safe_dump(doc,sort_keys=False,allow_unicode=True)

def render_ttl():
    L=['@prefix cume: <https://cume.example/onto#> .','@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .','@prefix owl: <http://www.w3.org/2002/07/owl#> .','@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .','',
       '# GERADO por scripts/gen_blueprint_views.py. epistemic_state: DESIGNED (vocabulário; não é um grafo de dados).','']
    for c,m in {**onto['classes'], **onto.get('supporting_classes',{})}.items():
        L.append(f'cume:{iri(c)} a owl:Class ; rdfs:label "{c}" ; cume:backedByTable "{m["table"]}" .')
    for s,p,o,card,note in onto['relations'] + onto.get('supporting_relations',[]):
        if o=='*' or s=='*': continue
        L.append(f'cume:{iri(p)}_{iri(s)}_{iri(o)} a owl:ObjectProperty ; rdfs:domain cume:{iri(s)} ; rdfs:range cume:{iri(o)} ; cume:cardinality "{card}" ; rdfs:comment "{note.replace(chr(34),chr(39))}" .')
    return "\n".join(L)+"\n"

def render_state_machines():
    M=['%% GERADO por scripts/gen_blueprint_views.py a partir de spec/state_machines.yaml. Transições = HIPÓTESE DE DOMÍNIO (DESIGNED).']
    for n,m in sm.items():
        M.append(f'---\ntitle: {n} ({m["table"]}.{m["column"]})\n---\nstateDiagram-v2')
        for i in m['initial']: M.append(f'  [*] --> {i}')
        for a,bs in m['transitions'].items():
            for b in bs: M.append(f'  {a} --> {b}')
        for t in m.get('terminal',[]): M.append(f'  {t} --> [*]')
        M.append('')
    return "\n".join(M)

def render_erd():
    canonical={'public','clinical','rcm'}
    cat={s['name']:s['relations'] for s in relation_catalog()}
    tables=sorted(r['name'] for sch in canonical for r in cat.get(sch,[]) if r['kind']=='TABLE')
    class_to_table={k:v['table'].split('.')[-1] for k,v in onto['classes'].items()}
    lines=['erDiagram','  %% GERADO por scripts/gen_blueprint_views.py. Fonte: migrations + onto_ops_cume.yaml.','  %% Base tables in public/clinical/rcm are emitted explicitly; no historical DESIGNED placeholder section.']
    for t in tables:
        lines += [f'  {t.upper()} {{','    string __catalog_marker','  }']
    for s,p,o,card,note in onto['relations']:
        if s=='*' or o=='*' or s not in class_to_table or o not in class_to_table: continue
        a,b=class_to_table[s],class_to_table[o]
        if a not in tables or b not in tables: continue
        label=re.sub(r'[^A-Za-z0-9_]+','_',p).strip('_') or 'relates_to'
        # Cardinality is documented in ontology; Mermaid here is navigational, not a second source of cardinality truth.
        lines.append(f'  {a.upper()} ||--o{{ {b.upper()} : {label}')
    return "\n".join(lines)+"\n"

def render_master():
    mr,_=migration_range()
    tests=sorted((ROOT/'tests').glob('test_*.py'))
    nums=[int(m.group(1)) for f in tests if (m:=re.match(r'test_(\d+)',f.name))]
    mx=max(nums) if nums else 0
    return f'''# MASTER INDEX — CUME structural reconciliation (Phase 3/4, 2026-10-02)\n\nThis index is a generated current-state view. Historical cycle READMEs/evidence remain lineage, not current truth.\n\n## Current executable/static surface\n- PostgreSQL migrations: **{mr}** ({len(list((ROOT/'db/migrations').glob('0*.sql')))} files).\n- Test files: **{len(tests)}** (`test_01` through `test_{mx:02d}`; historical numbering collisions are documented in `repo/tests/TEST_NUMBERING.md`).\n- Canonical generated catalog: `blueprint/01_taxonomy/generated_catalog.yaml`.\n- Canonical taxonomy assignment: `blueprint/01_taxonomy/taxonomy.yaml`.\n- Generated ERD: `repo/docs/erd.mmd`.\n- Generated ontology view: `blueprint/02_ontology/cume.ttl`.\n- Generated state-machine view: `blueprint/03_state_machines/state_machines.mmd`.\n\n## Directory map\n| Path | Current role |\n|---|---|\n| `00_START_HERE/` | current entry point + historical candidate notes |\n| `blueprint/01_taxonomy/` | bounded-context taxonomy + DDL-derived catalog |\n| `blueprint/02_ontology/` | operational/epistemic ontology + generated RDF |\n| `blueprint/03_state_machines/` | generated Mermaid view; source is `repo/spec/state_machines.yaml` |\n| `blueprint/04_api_events/` | OpenAPI/event contracts |\n| `blueprint/05_rules_terminology/` | rule and terminology contracts |\n| `blueprint/06_integration/` | adapter pipeline specifications |\n| `blueprint/07_security_privacy/` | threat/access/data inventory/privacy specs |\n| `blueprint/08_observability/` | log/metric/dashboard contracts |\n| `blueprint/09_quality/` | adversarial/conformance/benchmark specs |\n| `blueprint/10_ai_ml/` | AI adoption/defer/reject matrix |\n| `blueprint/11_infra_deploy/` | CI/deploy/runbook candidates |\n| `blueprint/12_product_business/` | MVP/product hypotheses; market metrics remain UNKNOWN |\n| `blueprint/13_governance/` | epistemic ledger/traceability |\n| `blueprint/14_reconciliation/` | historical crosswalk/reconciliation |\n| `repo/db/migrations/` | canonical DDL migrations {mr} |\n| `repo/tests/` | executable test suites; see `TEST_NUMBERING.md` |\n| `repo/*_ref/` | pure/in-process reference contracts, not network services |\n| `repo/governance/` | findings/gates/backlog/terminal registries |\n| `repo/evidence/` | receipts/logs/mutants/patches by cycle |\n| `lineage/manifests/` | historical manifests moved out of root; expected to diverge from current tree |\n\n## Current epistemic boundary\nPhase 1/4 reopened the previous terminal closure after the Claude audit. Phase 2/4 reconciled generated architectural views and lineage/hygiene. Phase 3/4 materializes reproducible CI inputs and complete technical column classification while PostgreSQL/CI/DPO execution remains pending. No gate is promoted by this index.\n'''

def outputs():
    return {
        BP/'01_taxonomy'/'generated_catalog.yaml': render_catalog(),
        BP/'02_ontology'/'cume.ttl': render_ttl(),
        BP/'03_state_machines'/'state_machines.mmd': render_state_machines(),
        ROOT/'docs'/'erd.mmd': render_erd(),
        PKG/'00_START_HERE'/'MASTER_INDEX.md': render_master(),
    }

def main():
    check='--check' in sys.argv[1:]
    drift=[]
    for p,content in outputs().items():
        current=p.read_text(encoding='utf-8') if p.exists() else None
        if current!=content:
            drift.append(str(p.relative_to(PKG)))
            if not check:
                p.parent.mkdir(parents=True,exist_ok=True)
                p.write_text(content,encoding='utf-8')
    if check:
        if drift:
            print('CHECK_DRIFT')
            for x in drift: print(x)
            raise SystemExit(1)
        print('CHECK_OK generated views current')
    else:
        print('WRITE_OK '+(', '.join(drift) if drift else 'no changes'))

if __name__=='__main__': main()
