from __future__ import annotations
from dataclasses import dataclass
from datetime import date
from typing import Iterable, Optional

@dataclass(frozen=True)
class TerminologyVersion:
    code_system: str
    version: str
    competence: Optional[str]
    effective_from: Optional[date]
    effective_to: Optional[date]
    source_url: str
    source_hash: str
    retrieved_at: str
    validation_status: str

@dataclass(frozen=True)
class TerminologyCode:
    terminology_version: TerminologyVersion
    code: str
    display: str
    valid_from: date
    valid_to: Optional[date]
    status: str
    source_hash: str

@dataclass(frozen=True)
class CrosswalkMapping:
    source_system: str
    source_code: str
    target_system: str
    target_code: str
    relationship: str
    crosswalk_version: str
    effective_from: date
    effective_to: Optional[date]
    provenance: str
    source_hash: str


def _in_range(start: Optional[date], end: Optional[date], on: date) -> bool:
    return (start is None or start <= on) and (end is None or on <= end)


def resolve_code(codes: Iterable[TerminologyCode], code_system: str, code: str, service_date: date) -> TerminologyCode:
    """Resolve exactly one code valid on service_date; zero or ambiguity fail closed."""
    matches = [
        c for c in codes
        if c.terminology_version.code_system == code_system
        and c.code == code
        and _in_range(c.valid_from, c.valid_to, service_date)
        and _in_range(c.terminology_version.effective_from, c.terminology_version.effective_to, service_date)
    ]
    if len(matches) != 1:
        raise LookupError(f"expected exactly one active code, found {len(matches)}")
    return matches[0]


def resolve_crosswalk(mappings: Iterable[CrosswalkMapping], source_system: str, source_code: str, target_system: str, on: date) -> list[CrosswalkMapping]:
    """Return all version-valid mappings. Cardinality is intentionally not collapsed to 1:1."""
    return [
        m for m in mappings
        if m.source_system == source_system
        and m.source_code == source_code
        and m.target_system == target_system
        and _in_range(m.effective_from, m.effective_to, on)
    ]
