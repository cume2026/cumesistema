-- CUME 0007 — maker/checker EXECUTÁVEL (candidate, dados sintéticos).
-- Pré-requisito: financial_adjustment sem linhas (approval_id passa a ser NOT NULL). Em banco com dados, exige backfill decidido em ADR.
BEGIN;
ALTER TABLE approval_request ADD CONSTRAINT approval_request_tenant_uq UNIQUE (tenant_id, approval_id);

CREATE FUNCTION approval_request_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP='INSERT' THEN
    IF NEW.status <> 'PENDING' THEN RAISE EXCEPTION 'approval must be created PENDING' USING ERRCODE='check_violation'; END IF;
    IF NOT EXISTS (SELECT 1 FROM role_assignment WHERE tenant_id=NEW.tenant_id AND user_id=NEW.maker_id
                   AND role IN ('BILLING_CLERK','BILLING_APPROVER') AND revoked_at IS NULL) THEN
      RAISE EXCEPTION 'maker lacks active BILLING_CLERK/BILLING_APPROVER role' USING ERRCODE='insufficient_privilege';
    END IF;
    RETURN NEW;
  END IF;
  -- UPDATE
  IF OLD.status <> 'PENDING' THEN RAISE EXCEPTION 'decided approval is immutable' USING ERRCODE='integrity_constraint_violation'; END IF;
  IF NEW.tenant_id<>OLD.tenant_id OR NEW.operation<>OLD.operation OR NEW.subject_type<>OLD.subject_type
     OR NEW.subject_id<>OLD.subject_id OR NEW.maker_id<>OLD.maker_id THEN
    RAISE EXCEPTION 'approval subject/maker is immutable' USING ERRCODE='integrity_constraint_violation';
  END IF;
  IF NEW.status='APPROVED' AND NOT EXISTS (SELECT 1 FROM role_assignment WHERE tenant_id=NEW.tenant_id AND user_id=NEW.checker_id
                   AND role='BILLING_APPROVER' AND revoked_at IS NULL) THEN
    RAISE EXCEPTION 'checker lacks active BILLING_APPROVER role' USING ERRCODE='insufficient_privilege';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER approval_request_guard_t BEFORE INSERT OR UPDATE ON approval_request FOR EACH ROW EXECUTE FUNCTION approval_request_guard();
CREATE TRIGGER approval_request_no_delete BEFORE DELETE ON approval_request FOR EACH ROW EXECUTE FUNCTION forbid_mutation();

ALTER TABLE financial_adjustment ADD COLUMN approval_id uuid NOT NULL;
ALTER TABLE financial_adjustment ADD CONSTRAINT financial_adjustment_approval_fk FOREIGN KEY (tenant_id, approval_id) REFERENCES approval_request (tenant_id, approval_id);
ALTER TABLE financial_adjustment ADD CONSTRAINT financial_adjustment_approval_once UNIQUE (approval_id);

CREATE FUNCTION financial_adjustment_requires_approval() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a approval_request%ROWTYPE; need text;
BEGIN
  SELECT * INTO a FROM approval_request WHERE tenant_id=NEW.tenant_id AND approval_id=NEW.approval_id;
  need := CASE WHEN NEW.kind='WRITE_OFF' THEN 'WRITE_OFF' ELSE 'FINANCIAL_ADJUSTMENT' END;
  IF a.status IS DISTINCT FROM 'APPROVED' THEN RAISE EXCEPTION 'adjustment requires APPROVED approval (found %)', a.status USING ERRCODE='insufficient_privilege'; END IF;
  IF a.operation <> need OR a.subject_type <> 'financial_adjustment' OR a.subject_id <> NEW.adjustment_id THEN
    RAISE EXCEPTION 'approval does not cover this adjustment (operation/subject mismatch)' USING ERRCODE='insufficient_privilege';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER financial_adjustment_requires_approval_t BEFORE INSERT ON financial_adjustment FOR EACH ROW EXECUTE FUNCTION financial_adjustment_requires_approval();
-- ajuste consolidado é imutável: correção = novo ajuste (reversal) também aprovado
CREATE TRIGGER financial_adjustment_append_only BEFORE UPDATE OR DELETE ON financial_adjustment FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
REVOKE UPDATE ON financial_adjustment FROM cume_app;
COMMIT;
