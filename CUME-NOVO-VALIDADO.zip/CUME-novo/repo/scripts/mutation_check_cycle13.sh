#!/bin/bash
set -u
cd "$(dirname "$0")/.."
fail=0
mut(){ file="$1"; expr="$2"; test="$3"; name="$4"; d=$(mktemp -d); cp -a . "$d/repo"; sed -i -E "$expr" "$d/repo/$file"; if cmp -s "$file" "$d/repo/$file"; then echo "MUTATION_NOT_APPLIED $name"; fail=1; rm -rf "$d"; return; fi; (cd "$d/repo" && python3 "tests/$test" >/dev/null 2>&1); rc=$?; if [ $rc -ne 0 ]; then echo "DETECTED $name"; else echo "SURVIVED $name"; fail=1; fi; rm -rf "$d"; }
mut ops_ref/ci_contract.py 's/migration_role!=runtime_role/migration_role==runtime_role/' test_50_b08_ci_backup_contract.py b08_role_separation
mut ops_ref/observability.py 's/if bad: raise/if False and bad: raise/' test_51_b14_observability_contract.py b14_pii_guard
mut ops_ref/release_integrity.py 's/return build_manifest\(Path\(root\)\)==manifest/return True/' test_52_b16_release_integrity_contract.py b16_manifest_tamper
mut domain_ts_ref/financial_semantics.ts "s/return \{status:'UNKNOWN', cents:null\}/return {status:'KNOWN', cents:0n}/" test_54_b18_typescript_property_contract.py b18_unknown_to_zero_ts
exit $fail
