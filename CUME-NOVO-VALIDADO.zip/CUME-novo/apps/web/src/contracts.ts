export type EpistemicState =
  | "REQUESTED" | "SPECIFIED" | "DESIGNED" | "MATERIALIZED" | "EXECUTED"
  | "OBSERVED" | "VERIFIED" | "SETTLED" | "BLOCKED" | "FAILED" | "ABSTAIN";

export interface EvidenceItemView {
  id: string;
  label: string;
  state: EpistemicState;
  source: string;
  evidence: string;
  lastUpdated: string;
  responsible: string;
  nextAction: string;
  /** Preformatted by the server. The client never computes a financial amount. */
  displayValue: string;
}

export interface AppViewModel {
  title: string;
  items: readonly EvidenceItemView[];
}
