"""CUME application reference boundary.

Classification: MATERIALIZED candidate; reference-only, not production runtime.
Project scope: CUME_ONLY. No HUMAN-OMEGA dependency is permitted.
"""
