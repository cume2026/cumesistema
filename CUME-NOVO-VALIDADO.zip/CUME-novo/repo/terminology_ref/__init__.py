"""CUME-only reference contracts for versioned terminologies and TISS XML validation."""
