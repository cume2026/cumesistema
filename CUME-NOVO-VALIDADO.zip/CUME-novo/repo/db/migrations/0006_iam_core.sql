-- CUME 0006 — IAM core (candidate, dados sintéticos). Autenticação é EXTERNA (OIDC IdP): o banco guarda só o subject, nunca senha/hash.
BEGIN;
CREATE TABLE organization (
  organization_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  legal_name text NOT NULL,
  kind text NOT NULL CHECK (kind IN ('CLINIC','HOSPITAL','PAYER','OTHER')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, organization_id)
);
CREATE TABLE user_account (
  user_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  kind text NOT NULL CHECK (kind IN ('HUMAN','SERVICE')),
  idp_issuer text NOT NULL,
  idp_subject text NOT NULL,
  email text,
  practitioner_id uuid,
  mfa_enrolled boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE','SUSPENDED','DEACTIVATED')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, user_id),
  UNIQUE (idp_issuer, idp_subject),
  FOREIGN KEY (tenant_id, practitioner_id) REFERENCES practitioner (tenant_id, practitioner_id),
  CHECK (kind='SERVICE' OR email IS NOT NULL)
);
CREATE UNIQUE INDEX user_account_email_uq ON user_account (tenant_id, lower(email)) WHERE email IS NOT NULL;
CREATE TABLE role_assignment (
  assignment_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  user_id uuid NOT NULL,
  role text NOT NULL CHECK (role IN ('BILLING_CLERK','BILLING_APPROVER','PHYSICIAN','CLINIC_ADMIN','AUDITOR','SECURITY_ADMIN')),
  organization_id uuid,
  granted_by uuid NOT NULL,
  granted_at timestamptz NOT NULL DEFAULT now(),
  revoked_at timestamptz,
  FOREIGN KEY (tenant_id, user_id) REFERENCES user_account (tenant_id, user_id),
  FOREIGN KEY (tenant_id, granted_by) REFERENCES user_account (tenant_id, user_id),
  FOREIGN KEY (tenant_id, organization_id) REFERENCES organization (tenant_id, organization_id),
  CHECK (granted_by <> user_id),                 -- ninguém concede papel a si mesmo
  CHECK (revoked_at IS NULL OR revoked_at >= granted_at)
);
CREATE UNIQUE INDEX role_assignment_active_uq ON role_assignment (tenant_id, user_id, role, COALESCE(organization_id,'00000000-0000-0000-0000-000000000000')) WHERE revoked_at IS NULL;
-- maker/checker para operações críticas
CREATE TABLE approval_request (
  approval_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  operation text NOT NULL CHECK (operation IN ('CONTRACT_CHANGE','RULE_CHANGE','FINANCIAL_ADJUSTMENT','WRITE_OFF','DENIAL_ACCEPT','PERMISSION_CHANGE','PHYSICIAN_SETTLEMENT')),
  subject_type text NOT NULL,
  subject_id uuid NOT NULL,
  maker_id uuid NOT NULL,
  checker_id uuid,
  status text NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','APPROVED','REJECTED','CANCELLED')),
  requested_at timestamptz NOT NULL DEFAULT now(),
  decided_at timestamptz,
  FOREIGN KEY (tenant_id, maker_id) REFERENCES user_account (tenant_id, user_id),
  FOREIGN KEY (tenant_id, checker_id) REFERENCES user_account (tenant_id, user_id),
  CHECK (checker_id IS NULL OR checker_id <> maker_id),
  CHECK ((status IN ('APPROVED','REJECTED')) = (checker_id IS NOT NULL AND decided_at IS NOT NULL))
);
-- ator do audit = usuário real (humano ou serviço), conforme ERD
ALTER TABLE audit_event ADD CONSTRAINT audit_event_actor_fk FOREIGN KEY (tenant_id, actor_id) REFERENCES user_account (tenant_id, user_id);
-- grants + RLS (mesmo padrão da 0005)
GRANT SELECT ON organization, user_account, role_assignment, approval_request TO cume_app, cume_auditor;
GRANT INSERT, UPDATE ON organization, user_account, role_assignment, approval_request TO cume_app;
ALTER TABLE organization ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_account ENABLE ROW LEVEL SECURITY;
ALTER TABLE role_assignment ENABLE ROW LEVEL SECURITY;
ALTER TABLE approval_request ENABLE ROW LEVEL SECURITY;
CREATE POLICY organization_tenant_isolation ON organization FOR ALL TO cume_app, cume_auditor USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid) WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);
CREATE POLICY user_account_tenant_isolation ON user_account FOR ALL TO cume_app, cume_auditor USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid) WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);
CREATE POLICY role_assignment_tenant_isolation ON role_assignment FOR ALL TO cume_app, cume_auditor USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid) WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);
CREATE POLICY approval_request_tenant_isolation ON approval_request FOR ALL TO cume_app, cume_auditor USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid) WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);
COMMIT;
