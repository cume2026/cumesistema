-- CUME B-12 candidate: versioned terminology codes and explicit N:N crosswalk.
-- MATERIALIZED ONLY until executed against dedicated CUME PostgreSQL.

CREATE TABLE terminology_code (
  terminology_code_id uuid PRIMARY KEY,
  terminology_version_id uuid NOT NULL REFERENCES terminology_version(terminology_version_id),
  code_system text NOT NULL,
  code text NOT NULL,
  display text NOT NULL,
  effective_from date NOT NULL,
  effective_to date,
  status text NOT NULL CHECK (status IN ('ACTIVE','INACTIVE','DEPRECATED','ENTERED_IN_ERROR')),
  source_hash text NOT NULL CHECK (source_hash ~ '^[0-9a-f]{64}$'),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (effective_to IS NULL OR effective_to >= effective_from),
  UNIQUE (terminology_version_id, code, effective_from)
);
CREATE INDEX terminology_code_lookup_idx ON terminology_code(code_system, code, effective_from, effective_to);

CREATE TABLE terminology_crosswalk (
  terminology_crosswalk_id uuid PRIMARY KEY,
  source_code_id uuid NOT NULL REFERENCES terminology_code(terminology_code_id),
  target_code_id uuid NOT NULL REFERENCES terminology_code(terminology_code_id),
  relationship text NOT NULL CHECK (relationship IN ('EXACT','BROADER','NARROWER','RELATED')),
  crosswalk_version text NOT NULL,
  effective_from date NOT NULL,
  effective_to date,
  source_url text NOT NULL,
  source_hash text NOT NULL CHECK (source_hash ~ '^[0-9a-f]{64}$'),
  review_status text NOT NULL CHECK (review_status IN ('UNREVIEWED','HUMAN_REVIEWED','REJECTED')),
  reviewed_by uuid REFERENCES user_account(user_id),
  reviewed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (effective_to IS NULL OR effective_to >= effective_from),
  CHECK (relationship <> 'EXACT' OR review_status = 'HUMAN_REVIEWED'),
  CHECK ((review_status = 'HUMAN_REVIEWED') = (reviewed_by IS NOT NULL AND reviewed_at IS NOT NULL)),
  UNIQUE(source_code_id,target_code_id,crosswalk_version,effective_from)
);
CREATE INDEX terminology_crosswalk_source_idx ON terminology_crosswalk(source_code_id,effective_from,effective_to);

CREATE OR REPLACE FUNCTION cume_reject_terminology_history_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'terminology history is append-only';
END $$;
CREATE TRIGGER terminology_code_append_only BEFORE UPDATE OR DELETE ON terminology_code FOR EACH ROW EXECUTE FUNCTION cume_reject_terminology_history_mutation();
CREATE TRIGGER terminology_crosswalk_append_only BEFORE UPDATE OR DELETE ON terminology_crosswalk FOR EACH ROW EXECUTE FUNCTION cume_reject_terminology_history_mutation();
