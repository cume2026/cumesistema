#!/usr/bin/env python3
import pathlib,sys
from decimal import Decimal
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'domain_ref'))
from rounding_policy import RoundingPolicyError, allocate_minor_units
checks=[]
def ck(label,cond): checks.append((label,bool(cond))); print((' ✔ ' if cond else ' ✘ FALHA ')+label)
def blocked(fn):
    try: fn(); return False
    except RoundingPolicyError: return True

a=allocate_minor_units(Decimal('100.00'),{'A':Decimal('1'),'B':Decimal('1'),'C':Decimal('1')})
ck('soma das partes fecha exatamente no total',sum(a.values(),Decimal('0.00'))==Decimal('100.00'))
ck('resto de 1 centavo vai ao primeiro maior resto/tie-break estável',a=={'A':Decimal('33.34'),'B':Decimal('33.33'),'C':Decimal('33.33')})
b=allocate_minor_units(Decimal('0.01'),{'A':Decimal('1'),'B':Decimal('1'),'C':Decimal('1')})
ck('um centavo nunca desaparece',b=={'A':Decimal('0.01'),'B':Decimal('0.00'),'C':Decimal('0.00')})
c=allocate_minor_units(Decimal('10.00'),{'x':Decimal('1'),'y':Decimal('3')})
ck('proporção 1:3 preservada em centavos',c=={'x':Decimal('2.50'),'y':Decimal('7.50')})
ck('ordem de entrada não altera resultado',allocate_minor_units(Decimal('100.00'),{'C':Decimal('1'),'A':Decimal('1'),'B':Decimal('1')})==a)
ck('total zero permanece zero',allocate_minor_units(Decimal('0.00'),{'A':Decimal('1'),'B':Decimal('2')})=={'A':Decimal('0.00'),'B':Decimal('0.00')})
ck('peso negativo é rejeitado',blocked(lambda:allocate_minor_units(Decimal('10.00'),{'A':Decimal('-1'),'B':Decimal('2')})))
ck('todos pesos zero são rejeitados',blocked(lambda:allocate_minor_units(Decimal('10.00'),{'A':Decimal('0'),'B':Decimal('0')})))
ck('float é rejeitado',blocked(lambda:allocate_minor_units(10.0,{'A':Decimal('1')})))
ck('total com mais de 2 casas é rejeitado',blocked(lambda:allocate_minor_units(Decimal('10.001'),{'A':Decimal('1')})))
bad=[x for x in checks if not x[1]]
print(f'== 38 B-23 rounding remainder policy: {len(checks)-len(bad)} ok, {len(bad)} falha(s)')
sys.exit(1 if bad else 0)
