#!/usr/bin/env python3
import json, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
p=ROOT/'governance'/'cycle5_b01_registry.json'
assert p.exists(), 'cycle5_b01_registry.json missing'
d=json.loads(p.read_text())
assert d['project_scope']=='CUME_ONLY'
required={'B01_REFERENCE_API','B01_SYNTHETIC_OIDC','B01_TENANT_TX_REFERENCE','B01_REAL_OIDC','B01_REAL_POSTGRES_POOL','B01_REAL_CUME_APP_ROLE','B01_REAL_NETWORK_API','B01_PRODUCTION_STACK_DECISION'}
items={x['id']:x for x in d['elements']}
assert required <= set(items), sorted(required-set(items))
allowed={'REQUESTED','SPECIFIED','DESIGNED','MATERIALIZED','EXECUTED','OBSERVED','VERIFIED','SETTLED','BLOCKED','FAILED','ABSTAIN','SUPERSEDED','DEPRECATED'}
for x in items.values():
    assert x['project_scope']=='CUME_ONLY', x['id']
    c=x['classification']
    assert c['epistemic_state'] in allowed, (x['id'],c)
    assert c.get('lifecycle_status'), x['id']
    assert c.get('evidence_basis'), x['id']
    assert x.get('shares_runtime_with_human_omega') is False, x['id']
for i in ('B01_REAL_OIDC','B01_REAL_POSTGRES_POOL','B01_REAL_CUME_APP_ROLE','B01_REAL_NETWORK_API'):
    assert items[i]['classification']['epistemic_state']=='BLOCKED', (i,items[i]['classification'])
for i in ('B01_REFERENCE_API','B01_SYNTHETIC_OIDC','B01_TENANT_TX_REFERENCE'):
    assert items[i]['classification']['epistemic_state']=='OBSERVED', (i,items[i]['classification'])
assert items['B01_PRODUCTION_STACK_DECISION']['classification']['epistemic_state']=='SPECIFIED'
print(f'== 26 B-01 classification registry: {len(items)} elements classified ==')
