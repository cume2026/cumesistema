# Historical manifest lineage

These manifests are **historical snapshots** from earlier CUME candidates. They are intentionally preserved for lineage, but they are not expected to validate the current tree after later cycles changed files. Therefore historical hash **divergence is expected** and is not, by itself, evidence of tampering.

Only the manifest explicitly identified as current at the package root is intended to validate the current package bytes. Historical manifests live here so that an auditor does not confuse a superseded snapshot with current truth.

A manifest stored with the package proves internal consistency only. It does **not** establish external authenticity or provenance by itself. A detached signature/hash outside the ZIP can improve tamper detection, but a production authenticity claim still requires an independently trusted signing identity or external trust anchor.

Em termos de governança: consistência interna não equivale a **autenticidade** externa. A identidade de assinatura continua dependente de um trust anchor independente.

- `MANIFEST_PHASE3_OF4_AUD10_AUD11.sha256.json` — Phase 3 historical snapshot; divergence from Phase 4 is expected.
