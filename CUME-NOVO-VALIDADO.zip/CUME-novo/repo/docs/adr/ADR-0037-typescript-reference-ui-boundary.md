# ADR-0037 — TypeScript reference UI boundary

**Status:** ACCEPTED_FOR_LOCAL_REFERENCE_ONLY  
**Classification:** SPECIFIED → MATERIALIZED → EXECUTED → OBSERVED_LOCAL

## Decision
The replacement reference UI lives under `apps/web`, uses strict TypeScript, receives already-formatted financial display values from the server boundary, and never computes authoritative monetary totals in the browser. Every operational card exposes state, source, evidence, last update, responsible role and next action.

The legacy HTML files remain historical/reference artifacts and are not silently promoted or rewritten.

## Verification
- TypeScript strict compilation.
- Chromium pixel baseline at 1280×900.
- Chromium mobile smoke at 390×844.
- Browser semantic/a11y smoke.
- `axe`/`pa11y`: **BLOCKED_BY_DEPENDENCY / NOT_EXECUTED** in this environment.

## Non-claims
This ADR does not establish WCAG conformance, production API integration, real authentication, real data correctness or pilot readiness.
