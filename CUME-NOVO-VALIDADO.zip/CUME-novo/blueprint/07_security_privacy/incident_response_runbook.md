# Runbook de resposta a incidentes — CUME

**Classificação:** SPECIFIED / MATERIALIZED_DOCUMENT / NOT_DRILLED / UNVERIFIED_RUNTIME  
**Conformidade LGPD:** NOT_CLAIMED  
**Revisão DPO/jurídica:** PENDING

1. **Detectar/Triar:** confirmar ocorrência; identificar se há dados pessoais; avaliar risco ou dano relevante. O predicado local de B-15 é triagem técnica, não decisão jurídica final.
2. **Conter:** revogar credenciais/sessões; isolar tenant; interromper integrações/outbox quando necessário.
3. **Preservar evidências:** audit hash-chain, logs, hashes, snapshots e cadeia de custódia, sem copiar PII/saúde para payload livre.
4. **Erradicar/Recuperar:** corrigir causa-raiz; restaurar somente backup verificado; reexecutar invariantes.
5. **Decidir comunicabilidade:** controlador/encarregado/jurídico avaliam o RCIS vigente. Fonte ANPD observada em 2026-10-02 registra regra geral de 3 dias úteis para comunicação à ANPD/titulares quando aplicável; eventual regime de agente de pequeno porte depende de classificação do controlador e normativa específica. O CUME não resolve esse enquadramento automaticamente.
6. **Registrar:** incidentes de segurança com dados pessoais devem possuir política de retenção versionada. A fonte ANPD observada registra manutenção do registro por ao menos 5 anos; política real só fica ACTIVE após revisão qualificada.
7. **Aprender:** post-mortem, finding, teste de regressão, mutante e atualização de threat model.

Papéis candidatos: comandante do incidente, líder técnico, encarregado/DPO, jurídico e comunicação. Identidades e contatos reais: UNKNOWN/NOT_CONFIGURED.
