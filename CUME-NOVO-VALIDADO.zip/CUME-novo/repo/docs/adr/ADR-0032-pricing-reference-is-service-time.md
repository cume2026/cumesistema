# ADR-0032 — Pricing reference_at é o instante do serviço

**Status:** SPECIFIED + REFERENCE_EXECUTED/OBSERVED; DDL candidate MATERIALIZED; runtime PostgreSQL verification BLOCKED.

`pricing_snapshot.reference_at` must equal the linked `performed_item.performed_at`. Rule and contract selection uses half-open effectivity windows `[effective_from, effective_to)`. A caller may not select a divergent pricing date to obtain a different historical rule or contract.

Migration 0008 already checks effectivity of the chosen rule/contract at `reference_at`; migration 0016 adds the missing link from that reference instant to the performed service.
