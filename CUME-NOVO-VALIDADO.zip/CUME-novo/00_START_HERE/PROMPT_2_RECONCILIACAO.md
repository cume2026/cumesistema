Papel: AUDITOR DE CONSISTÊNCIA. Abra blueprint/14_reconciliation/chatgpt_reconciliation.md e chatgpt_crosswalk.csv.
1. Para cada um dos 27 itens (F01–F18, N01–N09) confirme ou conteste o mapeamento para o registro (repo/governance/findings_registry_v0_5.json). Se contestar, proponha o mapeamento correto.
2. Sobre as seções 4 e 5 da reconciliação: você consegue reproduzir F01, N03, N04 e N06 no HTML v2? (método em repo/evidence/prototype_v2_probe). Informe o que reproduziu, o que não, e por quê. Se não puder executar, diga.
3. Seu primeiro relatório concluiu "QA básico aprovado". Explique o que ele não testou e se mantém ou retira a conclusão.
4. Liste achados SEUS que o registro não contém.
Entregável: tabela item | seu veredito | evidência (comando e saída) | divergência com o pacote. Proibido: inventar saídas.
