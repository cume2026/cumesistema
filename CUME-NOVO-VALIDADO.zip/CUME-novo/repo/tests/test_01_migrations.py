from base import *
r=Report('01 migrações')
uri=start('mig')
for f in migrations(): r.expect(f'aplica {f.name}',sh(uri,f=f),'ok')
r.expect('ORIGINAL v0_3 do 0001 falha em PG real (regressão do CUME-DB-01)',sh(start('orig'),f=ROOT/'reference'/'0001_core_spine.ORIGINAL_v0_3_DEFEITUOSA.sql'),'fail','syntax error')
schemas="('public','clinical','rcm')"
tenant_schemas="('public','clinical','rcm','cume_content','privacy')"
n=int(q(uri,f"select count(*) from information_schema.tables where table_schema in {schemas} and table_type='BASE TABLE'")[0])
r.check('catálogo base canônico não vazio após todas as migrações',n>0,n)
r.check('RLS ligada em todas as tabelas com tenant_id nos schemas canônicos',q(uri,f"""select count(*) from pg_class c join pg_namespace ns on ns.oid=c.relnamespace where ns.nspname in {tenant_schemas} and c.relkind='r' and exists (select 1 from information_schema.columns k where k.table_schema=ns.nspname and k.table_name=c.relname and k.column_name='tenant_id') and not c.relrowsecurity""")[0]=='0')
r.check('FORCE RLS em todas as tabelas tenant-bearing canônicas',q(uri,f"""select count(*) from pg_class c join pg_namespace ns on ns.oid=c.relnamespace where ns.nspname in {tenant_schemas} and c.relkind='r' and exists (select 1 from information_schema.columns k where k.table_schema=ns.nspname and k.table_name=c.relname and k.column_name='tenant_id') and not c.relforcerowsecurity""")[0]=='0')
r.check('ao menos uma policy em toda tabela tenant-bearing canônica',q(uri,f"""select count(*) from pg_class c join pg_namespace ns on ns.oid=c.relnamespace where ns.nspname in {tenant_schemas} and c.relkind='r' and exists (select 1 from information_schema.columns k where k.table_schema=ns.nspname and k.table_name=c.relname and k.column_name='tenant_id') and not exists (select 1 from pg_policy p where p.polrelid=c.oid)""")[0]=='0')
r.done()
