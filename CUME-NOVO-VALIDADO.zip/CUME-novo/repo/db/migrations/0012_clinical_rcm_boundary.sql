-- CUME 0012 — Clinical↔RCM physical boundary candidate.
-- Classification: MATERIALIZED DDL CANDIDATE; NOT EXECUTED against PostgreSQL in this cycle.
-- Project scope: CUME_ONLY. External-product resources, roles, schemas, credentials and runtimes are forbidden.
-- B-04 / REQ-BOUNDARY-001 / I-18 / I-23.
BEGIN;

CREATE SCHEMA IF NOT EXISTS clinical;
CREATE SCHEMA IF NOT EXISTS rcm;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='cume_clinical') THEN
    CREATE ROLE cume_clinical NOLOGIN NOBYPASSRLS;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='cume_billing') THEN
    CREATE ROLE cume_billing NOLOGIN NOBYPASSRLS;
  END IF;
END $$;

-- Sensitive clinical tables leave public. Existing FKs/triggers follow relation OIDs.
ALTER TABLE public.clinical_document SET SCHEMA clinical;
ALTER TABLE public.document_version SET SCHEMA clinical;

-- Legacy broad cume_app must not remain a path into clinical after this migration.
REVOKE ALL ON SCHEMA clinical FROM PUBLIC, cume_app, cume_billing;
REVOKE ALL ON ALL TABLES IN SCHEMA clinical FROM PUBLIC, cume_app, cume_billing;
GRANT USAGE ON SCHEMA clinical TO cume_clinical, cume_auditor;
GRANT SELECT, INSERT, UPDATE ON clinical.clinical_document TO cume_clinical;
GRANT SELECT, INSERT ON clinical.document_version TO cume_clinical;
GRANT SELECT ON ALL TABLES IN SCHEMA clinical TO cume_auditor;

-- Billing inherits the already tenant-scoped public RCM privileges of cume_app,
-- but cume_app itself has just been revoked from the clinical schema/tables.
GRANT cume_app TO cume_billing;
GRANT USAGE ON SCHEMA public, rcm TO cume_billing;

-- Clinical service gets only shared-kernel access needed to resolve an encounter,
-- plus the one-way INSERT-only bridge into RCM.
GRANT USAGE ON SCHEMA public, rcm TO cume_clinical;
GRANT SELECT ON public.tenant, public.patient_identity, public.practitioner,
                public.appointment, public.encounter, public.terminology_version
TO cume_clinical;
GRANT UPDATE ON public.encounter TO cume_clinical;

-- Extend tenant RLS explicitly to cume_clinical for the shared kernel it may use.
CREATE POLICY tenant_clinical_service ON public.tenant
  FOR SELECT TO cume_clinical
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);
CREATE POLICY patient_identity_clinical_service ON public.patient_identity
  FOR SELECT TO cume_clinical
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);
CREATE POLICY practitioner_clinical_service ON public.practitioner
  FOR SELECT TO cume_clinical
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);
CREATE POLICY appointment_clinical_service ON public.appointment
  FOR SELECT TO cume_clinical
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);
CREATE POLICY encounter_clinical_service ON public.encounter
  FOR SELECT TO cume_clinical
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);
CREATE POLICY encounter_clinical_service_update ON public.encounter
  FOR UPDATE TO cume_clinical
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);
CREATE POLICY terminology_version_clinical_service ON public.terminology_version
  FOR SELECT TO cume_clinical
  USING (tenant_id IS NULL OR tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);
CREATE POLICY clinical_document_clinical_service ON clinical.clinical_document
  FOR ALL TO cume_clinical
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);
CREATE POLICY document_version_clinical_service ON clinical.document_version
  FOR ALL TO cume_clinical
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);

-- Typed, minimized Clinical→RCM bridge. There is intentionally no free-form
-- clinical narrative, diagnosis, medication, allergy, report body, tariff or price.
CREATE TABLE rcm.performed_item_event (
  event_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL,
  encounter_id uuid NOT NULL,
  performed_item_id uuid NOT NULL,
  event_type text NOT NULL DEFAULT 'PERFORMED_ITEM_RECORDED'
    CHECK (event_type='PERFORMED_ITEM_RECORDED'),
  event_version smallint NOT NULL DEFAULT 1 CHECK (event_version=1),
  code_system text NOT NULL,
  code text NOT NULL,
  quantity numeric(12,3) NOT NULL CHECK (quantity > 0 AND quantity <> 'NaN'::numeric),
  performed_at timestamptz NOT NULL,
  published_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, event_id),
  UNIQUE (tenant_id, performed_item_id),
  FOREIGN KEY (tenant_id, encounter_id)
    REFERENCES public.encounter(tenant_id, encounter_id)
);

CREATE TABLE rcm.performed_item_event_participant (
  event_id uuid NOT NULL,
  tenant_id uuid NOT NULL,
  practitioner_id uuid NOT NULL,
  function_code text NOT NULL,
  PRIMARY KEY (event_id, practitioner_id, function_code),
  FOREIGN KEY (tenant_id, event_id)
    REFERENCES rcm.performed_item_event(tenant_id, event_id),
  FOREIGN KEY (tenant_id, practitioner_id)
    REFERENCES public.practitioner(tenant_id, practitioner_id)
);

CREATE TRIGGER performed_item_event_append_only
  BEFORE UPDATE OR DELETE ON rcm.performed_item_event
  FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();
CREATE TRIGGER performed_item_event_participant_append_only
  BEFORE UPDATE OR DELETE ON rcm.performed_item_event_participant
  FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();

ALTER TABLE rcm.performed_item_event ENABLE ROW LEVEL SECURITY;
ALTER TABLE rcm.performed_item_event_participant ENABLE ROW LEVEL SECURITY;

CREATE POLICY performed_item_event_clinical_insert ON rcm.performed_item_event
  FOR INSERT TO cume_clinical
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);
CREATE POLICY performed_item_event_participant_clinical_insert ON rcm.performed_item_event_participant
  FOR INSERT TO cume_clinical
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);
CREATE POLICY performed_item_event_billing_read ON rcm.performed_item_event
  FOR SELECT TO cume_billing, cume_auditor
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);
CREATE POLICY performed_item_event_participant_billing_read ON rcm.performed_item_event_participant
  FOR SELECT TO cume_billing, cume_auditor
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);

REVOKE ALL ON ALL TABLES IN SCHEMA rcm FROM PUBLIC;
GRANT INSERT ON rcm.performed_item_event, rcm.performed_item_event_participant TO cume_clinical;
GRANT SELECT ON rcm.performed_item_event, rcm.performed_item_event_participant TO cume_billing, cume_auditor;

-- Deliberately absent: no trigger/function here creates a financial production row.
-- Encounter completion may publish the minimized performed-item event; pricing and
-- production materialization remain separate RCM operations requiring a valid snapshot.

COMMIT;
