# Arquitetura de implantação-alvo (DESIGNED; nada implantado)

**Princípio:** monólito modular + PostgreSQL + object storage + outbox transacional + fila de jobs + API versionada + plano de auditoria/evidência + observabilidade. **Sem microsserviços, Kubernetes, blockchain, event sourcing completo ou IA por moda** — só com evidência de necessidade (carga, equipe, custo). A escolha física final exige ADR (ADR-0019) após medir carga e custo.

```
[Web responsiva] ──HTTPS──▶ [API v1 (OIDC, escopos)] ──tx──▶ [PostgreSQL 16: RLS, triggers, outbox]
                                   │                               ▲
                                   ├──▶ [Worker: jobs, importador, matching, outbox publisher] ──┘
                                   ├──▶ [Object storage privado: documentos, retornos (sha256)]
                                   └──▶ [OTel Collector → métricas/logs/traces]
[IdP OIDC externo]   [Cofre de segredos]   [Backup cifrado + restore verificado]
```
## Decisões em aberto (ADRs)
Linguagem/framework (ADR-0014; o domínio de referência hoje é Python e TS no spine v0.3 — escolher UM para produção); nuvem/região/jurisdição (ADR-0015); IdP (ADR-0016); política de resto de arredondamento (0017); fila (Postgres SKIP LOCKED vs broker, ADR-0018); observabilidade (0019); estratégia de multi-tenancy (RLS+FK composto adotados em ADR-0013; schema/DB por tenant = DEFER); retenção vs append-only/eliminação (0021).

## Limite de projeto — REQ-ISO-001 / I-25
Toda infraestrutura concreta do CUME é dedicada ao próprio CUME. Repositório, projeto de cloud, banco, IAM, secrets, storage, filas/workers, observabilidade, CI/CD, runtime, backups e DR não podem ser compartilhados com outro produto. O mesmo fornecedor ou tecnologia pode ser selecionado independentemente, mas somente por meio de recursos/projetos/credenciais distintos. Dependências runtime entre produtos são proibidas. Fonte normativa: `repo/governance/project_isolation_policy_v1.json` e ADR-0023.

## Ambientes
`dev` (dados sintéticos) → `ci` (efêmero) → `staging` (sintético/anonimizado) → `prod` (só após G12). Dados reais proibidos fora de prod sem decisão do DPO. Ver `environments.yaml`.

## FinOps
Custos = UNKNOWN (volume, equipe, fornecedor). Alavancas: dimensionar Postgres por medição; storage frio para documentos antigos; retenção de logs/traces por política; sem serviços gerenciados caros antes de necessidade. Medir custo por tenant/importação após piloto.
