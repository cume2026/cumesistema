# CUME v0.5+B21+ISO+QA+B25 candidate — status 2026-10-02

- CUME-QA-01: `test_15` não pode mais retornar PASS/0 checks quando `blueprint/` está ausente; cenário negativo observado com exit 1.
- CUME-QA-02: `Dockerfile.tests` agora inclui o blueprint e declara `openapi-spec-validator` + `rdflib`.
- `test_19_qa_harness_contract.py`: TDD observado, RED 8 falhas → GREEN 13/13.
- Mutante removendo `COPY blueprint/` foi detectado; Dockerfile restaurado byte-identical.
- Docker build/CI real continuam BLOCKED neste host; findings permanecem OPEN.
- Nenhuma migração 0001–0011, regra financeira, domain_ref ou política de isolamento foi alterada por este ciclo.
- G0–G12 continuam BLOCKED.
