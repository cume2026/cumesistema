# CUME Cycle 9 — B-09 + B-10 + B-23 + B-24

## Classification

- B-09 NULL semantics reference: SPECIFIED → MATERIALIZED → EXECUTED → OBSERVED; independent verification NOT_EXECUTED.
- B-09 PostgreSQL enforcement: MATERIALIZED; EXECUTION=BLOCKED; VERIFIED=NO.
- B-10 effectivity/reference reference: SPECIFIED → MATERIALIZED → EXECUTED → OBSERVED.
- B-10 production-item pricing-reference trigger: MATERIALIZED; EXECUTION=BLOCKED.
- B-23 rounding candidate: SPECIFIED → MATERIALIZED → EXECUTED → OBSERVED; finance/RCM SME approval BLOCKED; SETTLED=NO.
- B-24 typed competence/operational clock reference: SPECIFIED → MATERIALIZED → EXECUTED → OBSERVED.
- B-24 PostgreSQL competence/timezone candidate: MATERIALIZED; EXECUTION=BLOCKED; legacy timezone backfill BLOCKED.
- B-24 business-day calendar: BLOCKED/NOT_MATERIALIZED because no authoritative calendar/rule source is available.

## Decisions

1. Remittance NULL/absent means UNKNOWN and never zero. Zero is a KNOWN explicit monetary value.
2. Pricing `reference_at` equals the linked `performed_item.performed_at`; effectivity windows are half-open `[from,to)`.
3. Candidate rounding uses exact Decimal and largest remainder at currency minor-unit precision, with deterministic lexical tie-break.
4. Competence is typed year-month and derives from the service instant in explicit IANA timezone. Client date strings and raw UTC date must not determine competence.
5. No timezone is fabricated for legacy tenants. Migration 0016 exposes historical rows needing controlled backfill.
6. Deadline reference currently supports calendar days only; business-day/holiday rules remain BLOCKED.

## Evidence

- test_36: 10/10 PASS.
- test_37: 9/9 PASS.
- test_38: 10/10 PASS.
- test_39: 12/12 PASS.
- test_40: 30/30 PASS.
- Four critical mutants were detected: UNKNOWN→zero, divergent reference_at, dropped remainder, ignored operational timezone.

No gate is promoted by this cycle. G2 and G4 remain BLOCKED pending PostgreSQL execution, independent review and the stated human/domain dependencies.
