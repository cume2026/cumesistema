# ADR-0031 — Competência tipada e tempo operacional

**Status:** SPECIFIED + REFERENCE_EXECUTED/OBSERVED; DDL candidate MATERIALIZED; PostgreSQL execution BLOCKED; VERIFIED=NO.

Competence is a typed year-month (`YYYY-MM`) derived from the service instant in an explicit IANA operational timezone, never from presentation strings or the client clock. New performed items persist the timezone used and the first day of the competence month as a typed date.

No default timezone is fabricated for pre-existing tenants. Migration 0016 exposes unresolved historical rows through `performed_item_temporal_backfill_needed`. A controlled backfill requires an authoritative tenant timezone.

The current reference deadline helper implements **calendar days only** while preserving local wall time. Business-day/holiday deadlines remain BLOCKED until an authoritative calendar and contractual rule source exist.
