# Reconciliação: relatórios do ChatGPT × este pacote (2026-10-01)

## 1. Identidade dos artefatos (FATO, verificado por mim)
| Artefato | sha256 declarado pelo ChatGPT | Calculado por mim | Confere |
|---|---|---|---|
| HTML v1 (563.486 B) | a7f7849c…ba399f3 | a7f7849c…ba399f3 | sim |
| HTML v2 (601.699 B) | d3e97981…ba17a5 | d3e97981…ba17a5 | sim |
Os relatórios do ChatGPT se referem, portanto, aos mesmos arquivos que usei.

## 2. Três relatórios do ChatGPT, três profundidades
1. **"Relatório pericial de análise integral"** (sobre o HTML da apresentação): conclui **"QA básico aprovado"** e **"prontidão para validação com usuários: Alta"**; **não identifica** nenhum dos P0 de integridade (duplicação, guia paga×produção aguardando, negativo, tarifa→zero, agosto→setembro).
2. **"Vistoria completa" v1** (30/09): executa a classe com estado isolado e **reproduz** 5 defeitos P0 + 13 outros (F01–F18).
3. **"Vistoria v2"** (01/10): confirma que os 5 persistem na v2 e acrescenta N01–N09 (domínio clínico).
**INTERPRETAÇÃO:** (1) é teste de fumaça de UI (carrega, navega, sem erro de console); (2) e (3) são testes de lógica. A conclusão "QA aprovado" de (1) **não deve ser usada**: é contradita por (2)/(3) e, nos pontos que reproduzi (F01, N03, N06), pelos meus testes. Isso reforça a regra: *ausência de erro de console ≠ integridade de domínio*.

## 3. ARMADILHA DE NUMERAÇÃO (leia antes de cruzar os documentos)
- **IDs do ChatGPT:** F01–F18 (v1/v2) e N01–N09 (clínicos, v2).
- **IDs deste pacote:** F-01…F-34, CLIN-01…CLIN-15, CUME-DB-01…15.
- Só F01–F06 coincidem com F-01–F-06. **Exemplos de divergência:** ChatGPT F07 (histórico) = nosso F-11; F12 (parser) = F-15; F16 (agosto) = F-27; N03 = CLIN-14. Eu havia chamado meus achados de banco de CUME-N01…N11, o que **colidia** com N01–N09 do ChatGPT — **renomeados para CUME-DB-xx** (`legacy_id` preservado).
- Use sempre `chatgpt_crosswalk.csv` (27 linhas) ou o campo `chatgpt_ids` do registro.

## 4. O que EU verifiquei por conta própria (sonda do protótipo v2, n=1, sandbox)
| Alegação | Resultado |
|---|---|
| F01 duplicação entre agenda clínica e semanal | **Reproduzido** (n1 e n2, R$120 cada) |
| N03 visita futura pendente (a9, 02/10) pode ser concluída | **Reproduzido** (cria ehr-a9, R$120; agenda vira Realizada) |
| N04 outubro entra nos totais de setembro | **Parcial**: total 7.966,20→8.086,20. Não verifiquei guia 0901-0013 nem exclusão no relatório |
| N06 relatório com placeholders é aceito | **Reproduzido** (a lacuna de validação; não verifiquei o texto dos modelos do app) |
Todo o restante (F02–F18 exceto F01, N01–N02, N05, N07–N09) é **HERDADO**: não o reproduzi.

## 5. Contradições e imprecisões entre os relatórios (não resolvidas por mim)
- Exemplo do parser monetário: v1 "1.23 vira 123"; v2 "100.50 vira 10050". Mesmo defeito, exemplos diferentes; nenhum verificado por mim.
- Medidas de overflow a 390px diferem levemente entre v1 e v2 (faturamento 800 vs 802 px): variação plausível, sem importância.
- v2 declara a comparação como "baseada no relatório v1 e nova inspeção, **não diff byte a byte**": comparações do tipo "persiste/novo" dependem de teste caso a caso.
- v2 diz que clínica→prontuário mantém **uma** produção e prontuário→semanal gera duas: **não testei**.
- Dados de aparência real (telefones, carteirinhas, PIX): os relatórios tratam como fictícios "conforme a interface"; **não verifiquei** que sejam sintéticos.

## 6. Itens meus que o ChatGPT NÃO lista como F/N
F-10 (runtime com execução dinâmica; citado em prosa), F-19 (métricas/denominadores; prosa), F-21, F-22, F-24, F-29–F-33, CLIN-04, CLIN-07, CLIN-10 e todos os CUME-DB (camada de banco, que o ChatGPT não analisou). Vice-versa: nenhum achado F/N do ChatGPT ficou sem correspondente no registro.

## 7. O que o ChatGPT deve fazer com isto
Ver `00_START_HERE/COMO_APRESENTAR_AO_CHATGPT.md`.
