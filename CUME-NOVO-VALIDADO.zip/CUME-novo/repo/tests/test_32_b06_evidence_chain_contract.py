#!/usr/bin/env python3
import pathlib,sys,uuid,copy
from datetime import datetime, timezone, timedelta
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from evidence_ref.audit_chain import AuditEventInput, append_event, make_checkpoint, verify_chain, validate_evidence_link, EvidenceLinkError

checks=[]
def ck(label,cond):
    checks.append((label,bool(cond))); print((' ✔ ' if cond else ' ✘ FALHA ')+label)

tenant=str(uuid.uuid4()); actor=str(uuid.uuid4()); agg=str(uuid.uuid4()); t0=datetime(2026,10,2,12,0,tzinfo=timezone.utc)
raw=[
 AuditEventInput(str(uuid.uuid4()),tenant,actor,'CREATE','claim',agg,'corr-1',None,{'status':'DRAFT'},'R1',t0),
 AuditEventInput(str(uuid.uuid4()),tenant,actor,'SUBMIT','claim',agg,'corr-1',{'status':'DRAFT'},{'status':'SUBMITTED'},'R2',t0+timedelta(seconds=1)),
 AuditEventInput(str(uuid.uuid4()),tenant,actor,'ACK','claim',agg,'corr-1',{'status':'SUBMITTED'},{'status':'ACKNOWLEDGED'},None,t0+timedelta(seconds=2)),
]
chain=[]
for ev in raw: chain.append(append_event(chain,ev))
ck('sequência inicia em 1 e é contígua',[e.sequence_no for e in chain]==[1,2,3])
ck('primeiro prev_hash é GENESIS',chain[0].prev_hash=='0'*64)
ck('cada evento aponta para hash anterior',chain[1].prev_hash==chain[0].event_hash and chain[2].prev_hash==chain[1].event_hash)
ck('hashes SHA-256 hex',all(len(e.event_hash)==64 and set(e.event_hash)<=set('0123456789abcdef') for e in chain))
ck('verificador aceita cadeia íntegra',verify_chain(chain).valid)
cp=make_checkpoint(chain)
ck('checkpoint ancora tenant/contagem/head',cp.tenant_id==tenant and cp.event_count==3 and cp.head_hash==chain[-1].event_hash)
ck('cadeia íntegra confere com checkpoint',verify_chain(chain,cp).valid)

mut=copy.deepcopy(chain); mut[1]=mut[1].__class__(**{**mut[1].__dict__,'action':'ALTERED'})
ck('adulteração de conteúdo é detectada',not verify_chain(mut,cp).valid)
ck('remoção intermediária é detectada',not verify_chain([chain[0],chain[2]],cp).valid)
ck('remoção da cauda é detectada por checkpoint',not verify_chain(chain[:-1],cp).valid)
ck('reordenação é detectada',not verify_chain([chain[1],chain[0],chain[2]],cp).valid)

other=AuditEventInput(str(uuid.uuid4()),str(uuid.uuid4()),actor,'X','claim',agg,'c',None,None,None,t0)
try:
    append_event(chain,other); cross=False
except ValueError: cross=True
ck('cadeia não mistura tenants',cross)

ck('evidence pode vincular audit_event',validate_evidence_link(audit_event_id=chain[0].audit_event_id,source_document_id=None,artifact_hash=chain[0].event_hash))
ck('evidence pode vincular source_document',validate_evidence_link(audit_event_id=None,source_document_id=str(uuid.uuid4()),artifact_hash='a'*64))
try:
    validate_evidence_link(audit_event_id=None,source_document_id=None,artifact_hash='a'*64); orphan=False
except EvidenceLinkError: orphan=True
ck('evidence órfã é rejeitada',orphan)
try:
    validate_evidence_link(audit_event_id=chain[0].audit_event_id,source_document_id=None,artifact_hash='xyz'); badhash=False
except EvidenceLinkError: badhash=True
ck('artifact_hash inválido é rejeitado',badhash)

bad=[x for x in checks if not x[1]]
print(f'== 32 B-06 evidence chain contract: {len(checks)-len(bad)} ok, {len(bad)} falha(s)')
sys.exit(1 if bad else 0)
