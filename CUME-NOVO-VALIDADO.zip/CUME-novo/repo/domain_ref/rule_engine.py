"""CUME deterministic reference pricing engine. Pure, no I/O."""
import json
from copy import deepcopy
from rule_eval import evaluate
from pricing_hash import pricing_snapshot_hash

def price_item(*, rule_version_id, contract_version_id, definition, tariffs, inputs, reference_time):
    result=evaluate(deepcopy(definition),deepcopy(inputs),deepcopy(tariffs))
    inputs_json=json.dumps(result['inputs'],ensure_ascii=False,sort_keys=True,separators=(',',':'))
    inter_json=json.dumps(result['intermediate_values'],ensure_ascii=False,sort_keys=True,separators=(',',':'))
    h=pricing_snapshot_hash(rule_version_id,contract_version_id,result['currency'],result['expected_amount'],result['price_status'],inputs_json,inter_json,result['formula'],reference_time)
    return {
      'rule_version_id':rule_version_id,'contract_version_id':contract_version_id,
      'currency':result['currency'],'price_status':result['price_status'],
      'expected_amount':result['expected_amount'],'inputs':result['inputs'],
      'intermediate_values':result['intermediate_values'],'formula':result['formula'],
      'unknown_reason':result['unknown_reason'],'reference_time':reference_time.isoformat(),
      'snapshot_hash':h
    }
