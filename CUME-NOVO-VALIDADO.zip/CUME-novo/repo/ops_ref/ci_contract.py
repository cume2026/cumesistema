from __future__ import annotations
import hashlib

def validate_ci_contract(text:str)->list[str]:
    """Validate the self-contained embedded regression workflow.

    Provider DB credentials are deliberately *not* part of this CI contract. Production
    credential separation is a distinct deployment/runtime contract and is tested by
    validate_role_separation plus migration/role tests.
    """
    required=[
        'repo/requirements-ci.lock',
        'repo/scripts/verify_ci_lock.py',
        'scripts/gen_blueprint_views.py --check',
        'scripts/generate_data_inventory_from_migrations.py --check',
        'tests/run_all.py',
        'scripts/mutation_check.sh',
        'playwright install --with-deps chromium',
    ]
    issues=[f'missing:{x}' for x in required if x not in text]
    if 'CUME_PG_MIGRATION_URI' in text or 'CUME_PG_RUNTIME_URI' in text:
        issues.append('embedded_ci_must_not_require_provider_pg_secrets')
    return issues

def validate_role_separation(migration_role:str,runtime_role:str)->bool:
    return bool(migration_role and runtime_role and migration_role!=runtime_role)

def _sha(v:str)->str: return hashlib.sha256(v.encode()).hexdigest()

def backup_manifest(files:dict[str,str],*,counts:dict[str,int],invariants:dict[str,int])->dict:
    return {'schema':'CUME-BACKUP-MANIFEST-v1','files':{k:_sha(v) for k,v in sorted(files.items())},'counts':dict(sorted(counts.items())),'invariants':dict(sorted(invariants.items()))}

def verify_backup_manifest(manifest,files,*,counts,invariants)->bool:
    return manifest==backup_manifest(files,counts=counts,invariants=invariants)
