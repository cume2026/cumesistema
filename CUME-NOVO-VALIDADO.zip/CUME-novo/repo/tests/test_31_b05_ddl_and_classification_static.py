#!/usr/bin/env python3
import pathlib,json,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
checks=[]
def ck(label,cond):
    checks.append((label,bool(cond))); print((' ✔ ' if cond else ' ✘ FALHA ')+label)

mig=ROOT/'db/migrations/0013_clinical_document_lifecycle.sql'
reg=ROOT/'governance/cycle7_b05_registry.json'
ck('migration 0013 existe',mig.exists())
ck('registry B-05 existe',reg.exists())
if mig.exists():
    s=mig.read_text().lower()
    ck('server_recorded_at perde default cliente-contornável','alter column server_recorded_at drop default' in s)
    ck('timestamp explícito do cliente é barrado','client supplied server_recorded_at is forbidden' in s)
    ck('app.user_id obrigatório',"current_setting('app.user_id', true)" in s)
    ck('author_user_id materializado','author_user_id' in s)
    ck('author_practitioner derivado de user_account','from public.user_account' in s and 'practitioner_id' in s)
    ck('SIGNED exige PHYSICIAN','role = \'physician\'' in s)
    ck('SIGNED exige organização da prática','practice_organization_id' in s and 'organization_id' in s)
    ck('pós-FINAL exige supersedes_version_id','supersedes_version_id' in s and 'post-final version must supersede prior version' in s)
    ck('máquina canônica é consultada','public.state_transition_rule' in s)
    ck('consulta usa colunas reais da máquina de estados',"r.table_name = 'clinical_document'" in s and "r.state_column = 'current_status'" in s)
    ck('cume_clinical recebe leitura da máquina de estados','grant select on public.state_transition_rule to cume_clinical' in s)
    ck('não aceita client_recorded_at','client_recorded_at' not in s)
    ck('não materializa TSA/assinatura criptográfica no DDL','create extension' not in s and 'signature_value' not in s and 'certificate_chain' not in s)
if reg.exists():
    r=json.loads(reg.read_text())
    elems={e['id']:e for e in r['elements']}
    required={'B05_LIFECYCLE_REFERENCE','B05_DDL_ENFORCEMENT','B05_SERVER_RECORDED_TIME','B05_INDEPENDENT_TRUSTED_TIMESTAMP','B05_REAL_SIGNATURE_VALIDATION'}
    ck('registry contém 5 elementos mínimos',required<=set(elems))
    ck('DDL não é promovido a EXECUTED',elems['B05_DDL_ENFORCEMENT']['classification']['epistemic_state']=='MATERIALIZED')
    ck('server time separado de trusted timestamp',elems['B05_SERVER_RECORDED_TIME']['classification']['epistemic_state'] in {'MATERIALIZED','EXECUTED','OBSERVED'} and elems['B05_INDEPENDENT_TRUSTED_TIMESTAMP']['classification']['epistemic_state']=='BLOCKED')
    ck('assinatura real não é fingida',elems['B05_REAL_SIGNATURE_VALIDATION']['classification']['epistemic_state']=='BLOCKED')

bad=[x for x in checks if not x[1]]
print(f'== 31 B-05 DDL + classification static: {len(checks)-len(bad)} ok, {len(bad)} falha(s)')
sys.exit(1 if bad else 0)
