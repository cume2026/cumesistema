# ADR-0018 — Fila/outbox

**Status:** PROPOSED (rascunho; nenhuma decisão tomada)

Postgres (SKIP LOCKED) vs broker. Começar com Postgres; revisar com carga medida. Status: PROPOSED.

**Consequências:** a preencher após decisão.
