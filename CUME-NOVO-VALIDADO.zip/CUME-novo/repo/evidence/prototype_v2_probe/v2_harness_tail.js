function mk(){ const c=new Component({}); return c; }
const R={};
// ---- CONTROLE F01: mesma consulta realizada pela agenda da clínica (a1) e pela agenda semanal do médico
{ const c=mk(); c.setState({role:'cume',doc:'joao'});
  const v=c.renderVals(); const a1=v.agClin.find(x=>x.id==='a1'); a1.act();
  R.F01_apos_clinica=c.state.extra.length;
  // semanal: encontrar item de Maria Santos hoje 08:00 e marcar
  c.setState({screen:'agmed',doc:'joao'}); let found=null;
  for(let wk=0;wk<1;wk++){ const vv=c.renderVals(); for(const d of vv.week){ if(!d.today) continue; for(const it of d.items){ if(/Maria Santos/.test(it.pacF||it.titulo||'')||/08:00/.test(it.hora||'')){ found=it; } } } }
  R.F01_item_semanal_encontrado=!!found;
  if(found){ found.pick(); const vv=c.renderVals(); R.F01_canMark=vv.isel.canMark; if(vv.isel.canMark){ vv.isel.mark(); } }
  R.F01_apos_semanal=c.state.extra.length; R.F01_linhas=c.state.extra.map(x=>x.id+':'+x.pac+':'+x.esp);
}
// ---- N03: concluir visita FUTURA (a9, 02/10, Pendente) em 30/09-01/10
{ const c=mk(); c.setState({role:'medico',doc:'joao'});
  c.ehrOpen('a9'); c.ehrSet('queixa','q');c.ehrSet('avaliacao','a');c.ehrSet('plano','p');
  c.renderVals().ehrFinish(); R.N03_confirmacao=c.state.ehrConfirm; c.renderVals().ehrFinish();
  R.N03_final=!!c.state.ehrFinal['a9']; R.N03_extra=c.state.extra.map(x=>({id:x.id,data:x.data,esp:x.esp,status:x.status}));
  R.N03_status_agenda=c.state.ag['a9']||'(nao alterado)';
  // N04: o registro de outubro entra nos totais?
  const tot=(cc)=>cc.records().reduce((a,r)=>a+r.esp,0);
  const base=mk(); base.setState({role:'cume'}); R.N04_total_antes=tot(base); R.N04_total_depois=tot(c);
  R.N04_registro_data=c.records().filter(r=>r.novo).map(r=>r.data);
}
// ---- N06: relatório com placeholders é aceito e emitido?
{ const c=mk(); c.setState({role:'medico',doc:'joao',ehrVisit:'a1',ehrTab:'relatorio'});
  c.docSet('finalidade','Acompanhamento'); c.docSet('texto','Paciente em acompanhamento desde [data]. Encaminhar a [especialidade]. [preencher]');
  const g={id:'a1',pid:'p1',data:'30/09'}; c.docShow(g); R.N06_preview=!!c.state.docPreview; R.N06_erro=c.state.docError;
  if(c.state.docPreview){ c.docEmit(); R.N06_emitido=c.state.docHistory.length; R.N06_corpo=c.state.docHistory[0]&&c.state.docHistory[0].body; }
}
// ---- Controle extra F03: status manual pago com valor negativo (c6)
{ const c=mk(); c.setState({role:'cume'}); const v=c.renderVals(); R.F03_chaves=Object.keys(v).filter(k=>/^se|manual|valor|pagoMan/i.test(k)).slice(0,12); }
console.log(JSON.stringify(R,null,1)); process.exit(0);
