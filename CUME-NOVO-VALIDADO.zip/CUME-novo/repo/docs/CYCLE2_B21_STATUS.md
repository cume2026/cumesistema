# CUME — Ciclo 2 / B-21 — status candidato

- Baseline de origem: **v0.5**, preservado como artefato de entrada.
- Delta: **B-21 somente**.
- Estado máximo alcançado neste host: **MATERIALIZED**.
- Subcomponente `domain_ref/content_address.py`: **EXECUTED + OBSERVED** por teste unitário red→green.
- PostgreSQL `0011` / `test_17`: **BLOCKED** por ausência de `postgres`/`psql`/`pgserver` neste host.
- Gate G4: **BLOCKED**; nenhuma promoção.
- Finding `CUME-DB-13`: **OPEN**; remediation materializada, não verificada em banco.
- Schema `public`: preservado no contrato anterior de 33 tabelas.
- Supporting store novo: schema `cume_content` com `rule_definition`, `contract_content`, `tariff_line`.
- Nenhum dado contratual real foi criado; fixtures permanecem ilustrativas/sintéticas.
