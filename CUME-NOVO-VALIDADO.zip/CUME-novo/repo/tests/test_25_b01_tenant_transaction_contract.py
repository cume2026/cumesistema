#!/usr/bin/env python3
import pathlib, sys, uuid
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from application_ref.tenant_tx import tenant_transaction, RuntimeDbPolicy

class FakePooledConnection:
    """Models PostgreSQL transaction-local GUC semantics only; not a PostgreSQL substitute."""
    def __init__(self, login_role='cume_app'):
        self.login_role=login_role; self.in_tx=False; self.local={}; self.log=[]
    def begin(self):
        assert not self.in_tx; self.in_tx=True; self.local={}; self.log.append(('BEGIN',None))
    def execute(self,sql,params=()):
        assert self.in_tx; self.log.append((sql,params))
        if sql == "SELECT set_config('app.tenant_id', %s, true)":
            self.local['app.tenant_id']=params[0]
    def commit(self):
        assert self.in_tx; self.log.append(('COMMIT',None)); self.in_tx=False; self.local={}
    def rollback(self):
        assert self.in_tx; self.log.append(('ROLLBACK',None)); self.in_tx=False; self.local={}

checks=[]
def ck(label,cond):
    checks.append((label,bool(cond))); print((' ✔ ' if cond else ' ✘ FALHA ')+label)

policy=RuntimeDbPolicy()
ck('role runtime é cume_app',policy.application_role=='cume_app')
ck('role de migração é distinta',policy.migration_role!='cume_app')
ck('tenant GUC é app.tenant_id',policy.tenant_guc=='app.tenant_id')
try:
    with tenant_transaction(FakePooledConnection(login_role=policy.migration_role),str(uuid.uuid4())):
        pass
    migration_rejected=False
except PermissionError:
    migration_rejected=True
ck('credencial/role de migração é rejeitada no runtime',migration_rejected)

a=str(uuid.uuid4()); b=str(uuid.uuid4()); c=FakePooledConnection()
with tenant_transaction(c,a):
    ck('transação A instala tenant A localmente',c.local.get('app.tenant_id')==a)
ck('commit limpa contexto local',c.local=={} and not c.in_tx)
with tenant_transaction(c,b):
    ck('mesma conexão reutilizada recebe tenant B',c.local.get('app.tenant_id')==b)
    ck('tenant A não foi herdado',c.local.get('app.tenant_id')!=a)
ck('segundo commit limpa contexto',c.local=={})
sets=[x for x in c.log if x[0]=="SELECT set_config('app.tenant_id', %s, true)"]
ck('contexto foi instalado em cada transação',sets==[(sets[0][0],(a,)),(sets[1][0],(b,))] if len(sets)==2 else False)

c2=FakePooledConnection()
try:
    with tenant_transaction(c2,a):
        raise RuntimeError('boom')
except RuntimeError:
    pass
ck('erro provoca rollback',('ROLLBACK',None) in c2.log)
ck('rollback também limpa contexto',c2.local=={} and not c2.in_tx)

try:
    with tenant_transaction(FakePooledConnection(),'not-a-uuid'):
        pass
    invalid=False
except ValueError:
    invalid=True
ck('tenant inválido é rejeitado antes de tocar o contexto',invalid)

bad=[x for x in checks if not x[1]]
print(f'== 25 B-01 tenant transaction reference contract: {len(checks)-len(bad)} ok, {len(bad)} falha(s)')
sys.exit(1 if bad else 0)
