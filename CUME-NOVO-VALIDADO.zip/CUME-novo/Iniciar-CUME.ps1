param([int]$Porta = 8765, [switch]$Reconstruir)
$ErrorActionPreference = 'Stop'
$sessionRoot = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$pythonCume = Join-Path $sessionRoot 'work\cume-venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $pythonCume)) { throw 'Ambiente Python isolado não encontrado. Consulte PREPARACAO.md.' }
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'
$env:CUME_TSC_JS = Join-Path $sessionRoot 'work\cume-tools\node_modules\typescript\bin\tsc'
if ($Reconstruir) {
    & $pythonCume (Join-Path $PSScriptRoot 'apps\web\build_frontend.py')
    if ($LASTEXITCODE -ne 0) { throw 'Falha ao reconstruir a interface.' }
}
Write-Host "CUME de referência: http://127.0.0.1:$Porta — Ctrl+C para encerrar."
& $pythonCume -m http.server $Porta --bind 127.0.0.1 --directory (Join-Path $PSScriptRoot 'apps\web\dist')
if ($LASTEXITCODE -ne 0) { throw 'O servidor não iniciou; verifique se a porta está disponível.' }
