Você receberá o zip CUME_Complete_Package_v0_5. Papel: ENGENHEIRO DE VERIFICAÇÃO. Não implemente nada nesta etapa.
1. Liste o conteúdo do zip (nome e tamanho). Confira MANIFEST.sha256.json: informe quantos arquivos conferem e quais divergem.
2. Leia 00_START_HERE/README.md, repo/docs/HANDOFF_MASTER.md e blueprint/13_governance/epistemic_status_ledger.yaml. Devolva uma tabela: artefato | estado declarado | evidência declarada.
3. Informe seu ambiente: tem PostgreSQL 16 e Python 3.12? Consegue rodar `python3 repo/tests/run_all.py`? Se NÃO, diga e pare nesse ponto (não simule).
4. Liste ambiguidades ou contradições que encontrou no pacote (com arquivo e trecho).
Regras: rotule FATO/INFERÊNCIA/NÃO VERIFICADO; nada de elogio genérico; cite arquivo para cada afirmação.
