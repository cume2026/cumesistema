from dataclasses import dataclass, replace
from datetime import datetime

UNKNOWN_MARKERS={None,'','UNKNOWN'}
REQUEST_TYPES={'ACCESS','CORRECTION','ERASURE','ANONYMIZATION','PORTABILITY','INFORMATION','REVOCATION'}
REQUEST_TRANSITIONS={
 'RECEIVED': {'IDENTITY_VERIFICATION'},
 'IDENTITY_VERIFICATION': {'IN_REVIEW','REFUSED'},
 'IN_REVIEW': {'FULFILLED','PARTIAL','REFUSED'},
 'FULFILLED': set(), 'PARTIAL': set(), 'REFUSED': set(),
}

@dataclass(frozen=True)
class ProcessingActivity:
    activity_id: str
    purpose_code: str
    legal_basis_code: str
    sensitive_basis_code: str|None
    sensitive_data: bool
    data_categories: tuple[str,...]
    retention_policy_id: str|None
    status: str='DRAFT'

@dataclass(frozen=True)
class OperatorBinding:
    binding_id: str
    controller_ref: str
    operator_ref: str
    purpose_code: str
    contract_ref: str
    status: str='ACTIVE'

@dataclass(frozen=True)
class DataSubjectRequest:
    request_id: str
    subject_ref: str
    request_type: str
    status: str='RECEIVED'
    decision_reason: str|None=None
    decision_basis_source: str|None=None

@dataclass(frozen=True)
class IncidentAssessment:
    confirmed: bool
    involves_personal_data: bool
    relevant_risk_or_damage: bool
    assessed_at: datetime


def validate_processing_activity(a: ProcessingActivity):
    if a.status not in {'DRAFT','ACTIVE','RETIRED'}:
        raise ValueError('INVALID_ACTIVITY_STATUS')
    if not a.activity_id or not a.purpose_code or not a.data_categories:
        raise ValueError('INCOMPLETE_PROCESSING_ACTIVITY')
    if a.status=='ACTIVE':
        if a.legal_basis_code in UNKNOWN_MARKERS or a.retention_policy_id in UNKNOWN_MARKERS:
            raise ValueError('ACTIVE_ACTIVITY_REQUIRES_DECLARED_BASIS_AND_RETENTION')
        if a.sensitive_data and a.sensitive_basis_code in UNKNOWN_MARKERS:
            raise ValueError('SENSITIVE_ACTIVITY_REQUIRES_DECLARED_SENSITIVE_BASIS')
    return a


def validate_operator_binding(b: OperatorBinding):
    if not all((b.binding_id,b.controller_ref,b.operator_ref,b.purpose_code,b.contract_ref)):
        raise ValueError('INCOMPLETE_OPERATOR_BINDING')
    if b.controller_ref==b.operator_ref:
        raise ValueError('CONTROLLER_OPERATOR_MUST_BE_DISTINCT_REFS')
    if b.status not in {'ACTIVE','SUSPENDED','TERMINATED'}:
        raise ValueError('INVALID_OPERATOR_STATUS')
    return b


def minimize_record(record: dict, allowed_fields: set[str]|frozenset[str]):
    if not isinstance(record,dict):
        raise ValueError('RECORD_MUST_BE_OBJECT')
    return {k:v for k,v in record.items() if k in allowed_fields}


def transition_request(req: DataSubjectRequest, target: str, reason: str|None=None, basis_source: str|None=None):
    if req.request_type not in REQUEST_TYPES:
        raise ValueError('INVALID_REQUEST_TYPE')
    if target not in REQUEST_TRANSITIONS.get(req.status,set()):
        raise ValueError('INVALID_REQUEST_TRANSITION')
    if target in {'REFUSED','PARTIAL'} and (reason in UNKNOWN_MARKERS or basis_source in UNKNOWN_MARKERS):
        raise ValueError('ADVERSE_OR_PARTIAL_DECISION_REQUIRES_REASON_AND_SOURCE')
    return replace(req,status=target,decision_reason=reason,decision_basis_source=basis_source)


def meets_notification_trigger(a: IncidentAssessment):
    """Technical triage predicate only; controller/legal review remains required."""
    return bool(a.confirmed and a.involves_personal_data and a.relevant_risk_or_damage)
