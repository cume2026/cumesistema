from __future__ import annotations
from datetime import datetime,timezone
import random,secrets
PROHIBITED={'cpf','patient_id','patient_name','name','phone','email','clinical_text','request_body','authorization_header','token'}
METRIC_LABELS={
'cume_http_requests_total':{'route','method','status_class'},
'cume_command_total':{'command','outcome'},
'cume_priced_items_total':{'price_status'},
'cume_security_event_total':{'kind'},
}
def new_correlation_id()->str: return secrets.token_hex(16)
def make_log(*,level,service,msg,correlation_id,**fields):
    bad=PROHIBITED.intersection(fields)
    if bad: raise ValueError('prohibited log fields: '+','.join(sorted(bad)))
    if level not in {'DEBUG','INFO','WARN','ERROR'}: raise ValueError('bad level')
    out={'ts':datetime.now(timezone.utc).isoformat(),'level':level,'service':service,'msg':msg,'correlation_id':correlation_id}
    out.update(fields); return out
def validate_metric_labels(name:str,labels:dict)->bool:
    if PROHIBITED.intersection(labels): return False
    allowed=METRIC_LABELS.get(name)
    return allowed is not None and set(labels).issubset(allowed)
def synthetic_dashboard_snapshot(seed:int=0)->dict:
    r=random.Random(seed)
    unknown=r.randint(0,20); total=max(unknown,r.randint(50,200))
    return {
      'engineering':{'http_error_rate':round(r.random()/20,4),'p95_ms':r.randint(20,300)},
      'operations':{'outbox_pending':r.randint(0,25),'approvals_pending':r.randint(0,15)},
      'revenue_cycle':{'matched_items':r.randint(10,100),'price_unknown_rate':round(unknown/total,4)},
      'security':{'authz_denied':r.randint(0,4),'invariant_attempts':0},
      'business':{'reconciliation_coverage':round(r.random(),4),'commercial_kpis':'UNKNOWN'},
    }
