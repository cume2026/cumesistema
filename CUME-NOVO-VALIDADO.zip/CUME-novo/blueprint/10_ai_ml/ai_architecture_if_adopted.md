# Arquitetura-alvo SE (e somente se) componentes AI-04/05/07/12 forem adotados — DESIGNED

## Pipeline de conhecimento (terminologias/contratos/normas)
`fonte oficial → arquivo original (hash) → extração → normalização → chunking por tipo → indexação lexical (BM25/FTS) + densa (embeddings) → fusão (RRF) → [rerank] → resposta com citação (id do trecho, versão, vigência) → avaliação`
- **Chunking**: por estrutura (cláusula/artigo/linha), com âncoras (documento, versão, página); declarar método e perdas; sem chunks cruzando versões de vigência.
- **Índice**: separado por tenant quando contiver dado do cliente; terminologias oficiais podem ser globais. Metadados filtráveis: code_system, versão, vigência, competência.
- **Embeddings**: modelo, versão e dimensão registrados; reindexar ao trocar modelo; nunca misturar vetores de modelos distintos.
- **Recuperação híbrida**: lexical + denso com fusão por reciprocidade (RRF); parâmetros (k, pesos) calibrados no conjunto de avaliação, não fixados por convenção.
- **Resposta**: só com evidência citável; abstenção quando confiança/cobertura insuficientes; saída em estado CANDIDATE.
- **Observabilidade**: latência por estágio, taxa de abstenção, acurácia de citação, drift de distribuição de consultas, custo por consulta.

## Avaliação (protocolos em `09_quality/benchmark_protocols.md`)
Conjunto-ouro rotulado por 2 revisores (κ reportado); separação treino/calibração/teste; relatório com IC; comparação obrigatória com baseline determinístico; teste de injeção de prompt (documentos hostis); teste de vazamento cross-tenant.

## O que NÃO se faz
Sem vetor/grafo/LLM no caminho crítico de dinheiro; sem dado real em API externa sem DPA/DPO; sem métrica "alvo" tratada como medida.
