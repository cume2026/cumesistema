from __future__ import annotations
from decimal import Decimal
import random
from domain_ref.financial_semantics import observe_amount

def deterministic_property_probe(*,seed:int,cases:int)->dict:
    r=random.Random(seed); failures=0; unknown=0
    for _ in range(cases):
        # Primary invariant under fuzz: absent monetary observation never becomes zero.
        obs=observe_amount(None)
        unknown += int(obs.status=='UNKNOWN' and obs.amount is None)
        x=Decimal(r.randint(0,10_000))/100
        k=observe_amount(x)
        if k.amount != x.quantize(Decimal('0.01')) or k.status!='KNOWN': failures+=1
    return {'seed':seed,'cases':cases,'failures':failures,'unknown_preserved':unknown}
def classify_capability(available:bool,name:str)->str:
    return 'EXECUTABLE' if available else 'BLOCKED_BY_ENVIRONMENT'
