#!/usr/bin/env python3
import pathlib, sys, uuid
from datetime import datetime, timezone, timedelta
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from clinical_ref.document_lifecycle import (
    AuthenticatedActor, DocumentVersion, LifecycleError,
    allowed_transitions, transition_document
)

checks=[]
def ck(label,cond):
    checks.append((label,bool(cond))); print((' ✔ ' if cond else ' ✘ FALHA ')+label)

matrix=allowed_transitions()
states={'DRAFT','FINAL','SIGNED','AMENDED','CANCELLED','SUPERSEDED','ENTERED_IN_ERROR'}
expected={
 'DRAFT':{'FINAL','CANCELLED','ENTERED_IN_ERROR'},
 'FINAL':{'SIGNED','AMENDED','CANCELLED','ENTERED_IN_ERROR'},
 'SIGNED':{'AMENDED','SUPERSEDED','ENTERED_IN_ERROR'},
 'AMENDED':{'SIGNED','SUPERSEDED','ENTERED_IN_ERROR'},
 'CANCELLED':set(),'SUPERSEDED':set(),'ENTERED_IN_ERROR':set(),
}
ck('matriz canônica tem todos os estados',set(matrix)==states)
ck('matriz canônica coincide com spec',matrix==expected)

actor=AuthenticatedActor(
    user_id=str(uuid.uuid4()), practitioner_id=str(uuid.uuid4()),
    role_assignments=(('PHYSICIAN','org-1'),)
)
now=datetime(2026,10,2,12,0,tzinfo=timezone.utc)
base=DocumentVersion(str(uuid.uuid4()),str(uuid.uuid4()),1,'DRAFT',actor.user_id,actor.practitioner_id,now,None)

# matriz completa: todas as 49 combinações devem seguir exatamente a spec.
for src in sorted(states):
    prev=base.__class__(str(uuid.uuid4()),base.document_id,1,src,actor.user_id,actor.practitioner_id,now,None)
    for dst in sorted(states):
        try:
            transition_document(prev,dst,actor,practice_organization_id='org-1',server_now=now+timedelta(seconds=1))
            allowed=True
        except LifecycleError:
            allowed=False
        ck(f'matriz {src}->{dst}',allowed==(dst in expected[src]))

final=base.__class__(str(uuid.uuid4()),base.document_id,4,'FINAL',actor.user_id,actor.practitioner_id,now,None)
amended=transition_document(final,'AMENDED',actor,practice_organization_id='org-1',server_now=now+timedelta(minutes=1))
ck('alteração pós-FINAL cria nova versão',amended.version_number==5 and amended.document_version_id!=final.document_version_id)
ck('alteração pós-FINAL referencia versão anterior',amended.supersedes_version_id==final.document_version_id)
ck('tempo vem do servidor fornecido',amended.server_recorded_at==now+timedelta(minutes=1))
ck('autor vem do ator autenticado',amended.author_user_id==actor.user_id and amended.author_practitioner_id==actor.practitioner_id)

no_phys=AuthenticatedActor(str(uuid.uuid4()),str(uuid.uuid4()),(('CLINIC_ADMIN','org-1'),))
try:
    transition_document(final,'SIGNED',no_phys,practice_organization_id='org-1',server_now=now)
    signed_no_phys=False
except LifecycleError:
    signed_no_phys=True
ck('SIGNED exige papel PHYSICIAN',signed_no_phys)

wrong_practice=AuthenticatedActor(str(uuid.uuid4()),str(uuid.uuid4()),(('PHYSICIAN','org-2'),))
try:
    transition_document(final,'SIGNED',wrong_practice,practice_organization_id='org-1',server_now=now)
    signed_wrong_practice=False
except LifecycleError:
    signed_wrong_practice=True
ck('SIGNED exige PHYSICIAN vinculado à prática do documento',signed_wrong_practice)

signed=transition_document(final,'SIGNED',actor,practice_organization_id='org-1',server_now=now+timedelta(minutes=2))
ck('SIGNED válido cria nova versão assinada',signed.status=='SIGNED' and signed.supersedes_version_id==final.document_version_id)

try:
    transition_document(final,'AMENDED',actor,practice_organization_id='org-1',server_now=now,client_timestamp=now-timedelta(days=1))
    client_time_blocked=False
except LifecycleError:
    client_time_blocked=True
ck('timestamp de cliente é rejeitado explicitamente',client_time_blocked)

try:
    transition_document(final,'AMENDED',actor,practice_organization_id='org-1',server_now=datetime(2026,10,2,12,0))
    naive_blocked=False
except LifecycleError:
    naive_blocked=True
ck('tempo de servidor deve ser timezone-aware',naive_blocked)

bad=[x for x in checks if not x[1]]
print(f'== 30 B-05 clinical document lifecycle contract: {len(checks)-len(bad)} ok, {len(bad)} falha(s)')
sys.exit(1 if bad else 0)
