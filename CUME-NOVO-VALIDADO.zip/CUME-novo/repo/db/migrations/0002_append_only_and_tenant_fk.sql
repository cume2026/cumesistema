-- CUME 0002 — F-AUDIT-APPEND-ONLY / F-TENANT-ISOLATION (candidate, synthetic data only)
BEGIN;
CREATE FUNCTION forbid_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'append-only: % on % forbidden', TG_OP, TG_TABLE_NAME USING ERRCODE='integrity_constraint_violation'; END $$;
CREATE TRIGGER audit_event_append_only BEFORE UPDATE OR DELETE ON audit_event FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
CREATE TRIGGER document_version_append_only BEFORE UPDATE OR DELETE ON document_version FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
-- tenant-consistent reference: encounter.patient must belong to same tenant
ALTER TABLE document_version ADD CONSTRAINT document_version_tenant_uq UNIQUE (tenant_id, document_version_id);
ALTER TABLE encounter ADD CONSTRAINT encounter_patient_same_tenant FOREIGN KEY (tenant_id, patient_id) REFERENCES patient_identity (tenant_id, patient_id);
COMMIT;
