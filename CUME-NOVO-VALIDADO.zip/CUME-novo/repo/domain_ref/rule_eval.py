"""Avaliador de REFERÊNCIA da DSL (spec/rules/rule_definition.schema.json). Puro: sem I/O, sem relógio, sem aleatoriedade.
Propaga UNKNOWN: qualquer tarifa ausente/ilegível => UNKNOWN (NUNCA zero). Resultado negativo => erro (estorno é AJUSTE aprovado, não preço)."""
import json,hashlib
from decimal import Decimal,ROUND_HALF_EVEN,ROUND_HALF_UP,ROUND_DOWN,InvalidOperation
MODES={'HALF_EVEN':ROUND_HALF_EVEN,'HALF_UP':ROUND_HALF_UP,'DOWN':ROUND_DOWN}
class RuleError(ValueError): pass
UNKNOWN=object()
def canonical_definition_hash(defn:dict)->str:
    return hashlib.sha256(json.dumps(defn,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf-8')).hexdigest()
def _dec(x):
    try:
        d=Decimal(str(x))
        if not d.is_finite(): raise InvalidOperation
        return d
    except (InvalidOperation,ValueError): return UNKNOWN
def _when(w,inputs): return True if not w else inputs.get(w['input'])==w['eq']
def evaluate(defn:dict,inputs:dict,tariffs:dict)->dict:
    """tariffs: {tabela: {codigo: 'valor decimal string'}} — conteúdo do CONTRATO vigente (fornecido pelo contrato real, nunca inventado)."""
    vals={};inter={};lines=[];unknown_reason=None
    q=Decimal(1).scaleb(-defn['rounding']['scale']);mode=MODES[defn['rounding']['mode']]
    for s in defn['steps']:
        i,op=s['id'],s['op']
        if op=='tariff':
            raw=tariffs.get(s['table'],{}).get(str(inputs.get(s['key'])))
            v=UNKNOWN if raw is None else _dec(raw)
            if v is UNKNOWN: unknown_reason=unknown_reason or f"tarifa ausente/ilegível: {s['table']}[{inputs.get(s['key'])}]"
            lines.append(f"{i} = tarifa({s['table']}, {s['key']})")
        else:
            src=vals.get(s['of'],UNKNOWN)
            if op=='mul_pct':
                pct=_dec(s['pct']) if 'pct' in s else _dec(inputs.get(s.get('pct_input')))
                v=UNKNOWN if (src is UNKNOWN or pct is UNKNOWN) else (src*pct/Decimal(100) if _when(s.get('when'),inputs) else src)
                lines.append(f"{i} = {s['of']} × {s.get('pct',s.get('pct_input'))}%"+(f" se {s['when']['input']}={s['when']['eq']}" if s.get('when') else ''))
            elif op=='mul':
                by=_dec(s['by']);v=UNKNOWN if (src is UNKNOWN or by is UNKNOWN) else (src*by if _when(s.get('when'),inputs) else src)
                lines.append(f"{i} = {s['of']} × {s['by']}"+(f" se {s['when']['input']}={s['when']['eq']}" if s.get('when') else ''))
            elif op=='mul_qty':
                qty=_dec(inputs.get(s.get('qty_input','quantity'),1));v=UNKNOWN if (src is UNKNOWN or qty is UNKNOWN or qty<=0) else src*qty
                lines.append(f"{i} = {s['of']} × qtd")
            elif op=='round':
                v=UNKNOWN if src is UNKNOWN else src.quantize(q,rounding=mode)
                lines.append(f"{i} = arredonda({s['of']}, {defn['rounding']['mode']}, {defn['rounding']['scale']})")
            else: raise RuleError(f'op desconhecida {op}')
        vals[i]=v;inter[i]=None if v is UNKNOWN else str(v)
    res=vals.get(defn['result'],UNKNOWN)
    safe_inputs={k:(str(v) if isinstance(v,Decimal) else v) for k,v in inputs.items()}
    if res is UNKNOWN or unknown_reason:
        return dict(price_status='UNKNOWN',expected_amount=None,inputs=safe_inputs,intermediate_values=inter,formula="; ".join(lines),unknown_reason=unknown_reason or 'valor intermediário desconhecido',currency=defn['currency'])
    if res<0: raise RuleError('preço negativo não é permitido (use ajuste aprovado)')
    st='CONTRACTUAL_ZERO' if res==0 else 'PRICED'
    return dict(price_status=st,expected_amount=str(res),inputs=safe_inputs,intermediate_values=inter,formula="; ".join(lines),unknown_reason=None,currency=defn['currency'])
