-- CUME 0015 — candidate enforcement for remaining critical approval operations.
-- Classification: MATERIALIZED only; PostgreSQL execution remains BLOCKED in the current host.
BEGIN;

-- Operation-aware maker/checker policy. Existing billing operations preserve the 0007 rule;
-- PERMISSION_CHANGE is isolated to SECURITY_ADMIN actors.
CREATE OR REPLACE FUNCTION approval_request_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE maker_ok boolean; checker_ok boolean;
BEGIN
  IF TG_OP='INSERT' THEN
    IF NEW.status <> 'PENDING' THEN RAISE EXCEPTION 'approval must be created PENDING' USING ERRCODE='check_violation'; END IF;
    IF NEW.operation='PERMISSION_CHANGE' THEN
      SELECT EXISTS(SELECT 1 FROM role_assignment WHERE tenant_id=NEW.tenant_id AND user_id=NEW.maker_id AND role='SECURITY_ADMIN' AND revoked_at IS NULL) INTO maker_ok;
    ELSE
      SELECT EXISTS(SELECT 1 FROM role_assignment WHERE tenant_id=NEW.tenant_id AND user_id=NEW.maker_id AND role IN ('BILLING_CLERK','BILLING_APPROVER') AND revoked_at IS NULL) INTO maker_ok;
    END IF;
    IF NOT maker_ok THEN RAISE EXCEPTION 'maker lacks active role required for operation %',NEW.operation USING ERRCODE='insufficient_privilege'; END IF;
    RETURN NEW;
  END IF;
  IF OLD.status <> 'PENDING' THEN RAISE EXCEPTION 'decided approval is immutable' USING ERRCODE='integrity_constraint_violation'; END IF;
  IF NEW.tenant_id<>OLD.tenant_id OR NEW.operation<>OLD.operation OR NEW.subject_type<>OLD.subject_type OR NEW.subject_id<>OLD.subject_id OR NEW.maker_id<>OLD.maker_id THEN
    RAISE EXCEPTION 'approval subject/maker is immutable' USING ERRCODE='integrity_constraint_violation';
  END IF;
  IF NEW.checker_id=NEW.maker_id THEN RAISE EXCEPTION 'checker_id <> maker_id required' USING ERRCODE='check_violation'; END IF;
  IF NEW.status='APPROVED' THEN
    IF NEW.operation='PERMISSION_CHANGE' THEN
      SELECT EXISTS(SELECT 1 FROM role_assignment WHERE tenant_id=NEW.tenant_id AND user_id=NEW.checker_id AND role='SECURITY_ADMIN' AND revoked_at IS NULL) INTO checker_ok;
    ELSE
      SELECT EXISTS(SELECT 1 FROM role_assignment WHERE tenant_id=NEW.tenant_id AND user_id=NEW.checker_id AND role='BILLING_APPROVER' AND revoked_at IS NULL) INTO checker_ok;
    END IF;
    IF NOT checker_ok THEN RAISE EXCEPTION 'checker lacks active role required for operation %',NEW.operation USING ERRCODE='insufficient_privilege'; END IF;
  END IF;
  RETURN NEW;
END $$;

-- DENIAL_ACCEPT: explicit approval reference on the transition to ACCEPTED.
ALTER TABLE denial ADD COLUMN acceptance_approval_id uuid;
ALTER TABLE denial ADD CONSTRAINT denial_acceptance_approval_fk FOREIGN KEY (tenant_id, acceptance_approval_id) REFERENCES approval_request(tenant_id, approval_id);
ALTER TABLE denial ADD CONSTRAINT denial_acceptance_approval_uq UNIQUE (acceptance_approval_id);
CREATE FUNCTION denial_accept_requires_approval() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a approval_request%ROWTYPE;
BEGIN
  IF OLD.status='ACCEPTED' AND NEW.acceptance_approval_id IS DISTINCT FROM OLD.acceptance_approval_id THEN
    RAISE EXCEPTION 'accepted denial approval is immutable' USING ERRCODE='integrity_constraint_violation';
  END IF;
  IF NEW.status='ACCEPTED' AND OLD.status IS DISTINCT FROM 'ACCEPTED' THEN
    SELECT * INTO a FROM approval_request WHERE tenant_id=NEW.tenant_id AND approval_id=NEW.acceptance_approval_id;
    IF a.status IS DISTINCT FROM 'APPROVED' THEN RAISE EXCEPTION 'DENIAL_ACCEPT requires APPROVED approval' USING ERRCODE='insufficient_privilege'; END IF;
    IF a.operation <> 'DENIAL_ACCEPT' OR a.subject_type <> 'denial' OR a.subject_id <> NEW.denial_id THEN RAISE EXCEPTION 'approval does not cover DENIAL_ACCEPT' USING ERRCODE='insufficient_privilege'; END IF;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER denial_accept_requires_approval_t BEFORE UPDATE OF status, acceptance_approval_id ON denial FOR EACH ROW EXECUTE FUNCTION denial_accept_requires_approval();

-- Runtime role grants: PERMISSION_CHANGE approval. Owner/bootstrap remains a separate deployment concern (B-08).
ALTER TABLE role_assignment ADD COLUMN approval_id uuid;
ALTER TABLE role_assignment ADD CONSTRAINT role_assignment_approval_fk FOREIGN KEY (tenant_id, approval_id) REFERENCES approval_request(tenant_id, approval_id);
ALTER TABLE role_assignment ADD CONSTRAINT role_assignment_approval_uq UNIQUE (approval_id);
CREATE FUNCTION role_assignment_guard_b07() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a approval_request%ROWTYPE;
BEGIN
  IF TG_OP='UPDATE' AND (NEW.tenant_id<>OLD.tenant_id OR NEW.user_id<>OLD.user_id OR NEW.role<>OLD.role OR NEW.organization_id IS DISTINCT FROM OLD.organization_id OR NEW.granted_by<>OLD.granted_by OR NEW.approval_id IS DISTINCT FROM OLD.approval_id) THEN
    RAISE EXCEPTION 'role assignment identity/approval is immutable; only revocation is mutable' USING ERRCODE='integrity_constraint_violation';
  END IF;
  IF NEW.revoked_at IS NULL THEN
    IF NEW.role='SECURITY_ADMIN' AND EXISTS(SELECT 1 FROM role_assignment r WHERE r.tenant_id=NEW.tenant_id AND r.user_id=NEW.user_id AND r.revoked_at IS NULL AND r.role IN ('BILLING_CLERK','BILLING_APPROVER') AND r.assignment_id<>NEW.assignment_id) THEN
      RAISE EXCEPTION 'SECURITY_ADMIN must be segregated from BILLING roles' USING ERRCODE='insufficient_privilege';
    END IF;
    IF NEW.role IN ('BILLING_CLERK','BILLING_APPROVER') AND EXISTS(SELECT 1 FROM role_assignment r WHERE r.tenant_id=NEW.tenant_id AND r.user_id=NEW.user_id AND r.revoked_at IS NULL AND r.role='SECURITY_ADMIN' AND r.assignment_id<>NEW.assignment_id) THEN
      RAISE EXCEPTION 'SECURITY_ADMIN must be segregated from BILLING roles' USING ERRCODE='insufficient_privilege';
    END IF;
  END IF;
  IF TG_OP='INSERT' AND current_user='cume_app' THEN
    SELECT * INTO a FROM approval_request WHERE tenant_id=NEW.tenant_id AND approval_id=NEW.approval_id;
    IF a.status IS DISTINCT FROM 'APPROVED' THEN RAISE EXCEPTION 'role grant requires APPROVED approval' USING ERRCODE='insufficient_privilege'; END IF;
    IF a.operation <> 'PERMISSION_CHANGE' OR a.subject_type <> 'role_assignment' OR a.subject_id <> NEW.assignment_id THEN RAISE EXCEPTION 'approval does not cover PERMISSION_CHANGE role_assignment' USING ERRCODE='insufficient_privilege'; END IF;
    IF NOT EXISTS(SELECT 1 FROM role_assignment WHERE tenant_id=NEW.tenant_id AND user_id=NEW.granted_by AND role='SECURITY_ADMIN' AND revoked_at IS NULL) THEN RAISE EXCEPTION 'grantor lacks active SECURITY_ADMIN' USING ERRCODE='insufficient_privilege'; END IF;
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER role_assignment_guard_b07_t BEFORE INSERT OR UPDATE ON role_assignment FOR EACH ROW EXECUTE FUNCTION role_assignment_guard_b07();

-- PHYSICIAN_SETTLEMENT is intentionally not materialized here: its entity/table is a B-11 dependency.
COMMIT;
