# Novo CUME — preparação local

Esta pasta é uma cópia independente do ZIP anexado. Nenhum projeto existente foi utilizado como destino. Não há repositório GitHub novo confirmado por URL na conversa; nenhuma alteração foi enviada ao GitHub.

## Rodar a interface

No PowerShell, a partir desta pasta:

```powershell
.\Iniciar-CUME.ps1
```

Abra http://127.0.0.1:8765. Para reconstruir: ` .\Iniciar-CUME.ps1 -Reconstruir`. Para escolher outra porta: `.\Iniciar-CUME.ps1 -Porta 8766`. Encerre com Ctrl+C.

A interface usa dados sintéticos. O pacote contém implementações de referência Python, mas não fornece uma API de rede integrada à interface nem um produto completo para produção.

## Estrutura

- `apps/web`: componentes TypeScript, estilos e interface HTML gerada.
- `repo`: módulos Python de referência, 21 migrações SQL e 76 arquivos de teste.
- `blueprint`: arquitetura, contratos, segurança, inventário e governança.
- `00_START_HERE`: índices e documentação do pacote.
- `lineage` e `repo/evidence`: evidências históricas, não resultados desta preparação.
- `.github/workflows/ci.yml`: fluxo de validação Ubuntu com Python 3.12.3.

O `repo/README.md` ainda menciona fase 2; o estado mais recente fornecido pelo ZIP está em `PHASE4_OF4_STATUS.md`.

## Ambiente isolado

Python 3.12.14, dependências exatas de `repo/requirements-ci.lock`, TypeScript 5.9.3 e Chromium de teste estão na pasta `work` desta sessão, fora desta pasta de fontes. Os lançadores dependem desse ambiente local. Nenhum serviço ou banco existente foi configurado.

O pacote Windows de `pgserver` não incluía a pasta de fusos horários exigida por `pg_timezone_names`. Foi acrescentada à instalação isolada uma cópia dos arquivos TZif do runtime Python disponível (tzdata 2026.3 / IANA 2026c). Essa dependência complementar está registrada em `../alteracoes-locais.json` e deve ser reproduzida se esse mesmo pacote for instalado em outro Windows.

Também foram copiadas do mesmo runtime para o ambiente isolado as dependências `tzdata==2026.3` (ZoneInfo no Windows) e `lxml==6.1.1` (validação XSD), ausentes do lock original. A lista completa do ambiente está em `../dependencias-instaladas.txt`. Os pins originais foram preservados.

Para repetir os testes: `.\Verificar-CUME.ps1`. Esse lançador limpa referências externas de banco e usa PostgreSQL embutido com bancos temporários e dados sintéticos em `work`. Não execute testes como administrador de um banco existente.

Para recriar em outro computador, use um ambiente virtual Python 3.12, instale `repo/requirements-ci.lock`, instale Chromium com `python -m playwright install chromium` e disponibilize TypeScript 5.9.3. O compilador pode ser indicado por `CUME_TSC_JS` (caminho completo de `typescript/bin/tsc`), com Node no PATH. O teste de assinatura também exige Bash e OpenSSL. A comparação visual histórica usa uma imagem gerada em outro sistema e pode divergir no Windows.

## Correções na cópia nova

- Compilador TypeScript configurável e navegador Playwright disponível no Windows.
- Argumentos de `psql` posicionados antes da conexão: o binário Windows ignorava as opções posteriores, incluindo comandos SQL.
- Diagnósticos de PostgreSQL preservados e leitura tolerante à codificação das mensagens.
- SQL enviado ao `psql` por entrada UTF-8 no Windows, mantendo a transação única de cada chamada.
- Migração 0021 restringida a tabelas reais: o ZIP tentava aplicar RLS à view `performed_item_temporal_backfill_needed`, abortando a transação.

## Resolução das nove pendências

As duas colunas financeiras de settlement/physician_settlement receberam checks anti-NaN na migração candidata 0017. Os testes de auditoria, retorno e transições foram alinhados às regras de autoria, UNKNOWN/KNOWN e aprovação obrigatória já presentes no pacote. A preparação dos testes agora reutiliza metadados estáveis do catálogo e mantém o cache Hypothesis em `work`.

No Windows, a assinatura sintética usa Ed25519 via Node/OpenSSL quando Bash não está disponível. A referência visual Windows foi criada a partir da captura desktop inspecionada nesta sessão, com versão do navegador e hash registrados; a imagem Linux original foi preservada. A comparação exige igualdade de pixels e detecta uma alteração proposital do título. Não foi executada a validação visual Linux nesta sessão.

O teste de governança distingue o registro histórico de fase 3 do estado canônico de fase 4; nenhuma decisão de negócio ou gate foi promovido. Consulte `../RELATORIO-CUME.md` e `../validacao-final.json` para o resultado atualizado.

O ZIP original foi preservado e validado antes das alterações. Seu manifesto descreve o original; não foi reescrito para disfarçar alterações locais. Consulte `../validacao-zip.json`, `../alteracoes-locais.json` e `../verificacao-local.json` para integridade, diferenças e resultados atuais.

As decisões de negócio e os gates de produção do pacote não foram aprovados automaticamente. O resultado local não substitui revisão independente, integração real de OIDC/API ou aceitação de produção.
