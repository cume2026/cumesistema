# MASTER INDEX — CUME structural reconciliation (Phase 3/4, 2026-10-02)

This index is a generated current-state view. Historical cycle READMEs/evidence remain lineage, not current truth.

## Current executable/static surface
- PostgreSQL migrations: **0001–0021** (21 files).
- Test files: **76** (`test_01` through `test_74`; historical numbering collisions are documented in `repo/tests/TEST_NUMBERING.md`).
- Canonical generated catalog: `blueprint/01_taxonomy/generated_catalog.yaml`.
- Canonical taxonomy assignment: `blueprint/01_taxonomy/taxonomy.yaml`.
- Generated ERD: `repo/docs/erd.mmd`.
- Generated ontology view: `blueprint/02_ontology/cume.ttl`.
- Generated state-machine view: `blueprint/03_state_machines/state_machines.mmd`.

## Directory map
| Path | Current role |
|---|---|
| `00_START_HERE/` | current entry point + historical candidate notes |
| `blueprint/01_taxonomy/` | bounded-context taxonomy + DDL-derived catalog |
| `blueprint/02_ontology/` | operational/epistemic ontology + generated RDF |
| `blueprint/03_state_machines/` | generated Mermaid view; source is `repo/spec/state_machines.yaml` |
| `blueprint/04_api_events/` | OpenAPI/event contracts |
| `blueprint/05_rules_terminology/` | rule and terminology contracts |
| `blueprint/06_integration/` | adapter pipeline specifications |
| `blueprint/07_security_privacy/` | threat/access/data inventory/privacy specs |
| `blueprint/08_observability/` | log/metric/dashboard contracts |
| `blueprint/09_quality/` | adversarial/conformance/benchmark specs |
| `blueprint/10_ai_ml/` | AI adoption/defer/reject matrix |
| `blueprint/11_infra_deploy/` | CI/deploy/runbook candidates |
| `blueprint/12_product_business/` | MVP/product hypotheses; market metrics remain UNKNOWN |
| `blueprint/13_governance/` | epistemic ledger/traceability |
| `blueprint/14_reconciliation/` | historical crosswalk/reconciliation |
| `repo/db/migrations/` | canonical DDL migrations 0001–0021 |
| `repo/tests/` | executable test suites; see `TEST_NUMBERING.md` |
| `repo/*_ref/` | pure/in-process reference contracts, not network services |
| `repo/governance/` | findings/gates/backlog/terminal registries |
| `repo/evidence/` | receipts/logs/mutants/patches by cycle |
| `lineage/manifests/` | historical manifests moved out of root; expected to diverge from current tree |

## Current epistemic boundary
Phase 1/4 reopened the previous terminal closure after the Claude audit. Phase 2/4 reconciled generated architectural views and lineage/hygiene. Phase 3/4 materializes reproducible CI inputs and complete technical column classification while PostgreSQL/CI/DPO execution remains pending. No gate is promoted by this index.
