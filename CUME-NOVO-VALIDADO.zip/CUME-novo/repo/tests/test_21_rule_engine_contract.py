import sys, json
from pathlib import Path
from decimal import Decimal
from datetime import datetime, timezone
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'domain_ref'))
from rule_engine import price_item
from pricing_hash import pricing_snapshot_hash
import json as _json

defn=json.loads((Path(__file__).resolve().parent.parent/'spec/rules/EXAMPLE_rule_ILLUSTRATIVE.json').read_text())
tariffs={'procedimentos':{'P1':'150.00','P0':'0'}}
ref=datetime(2026,3,1,12,0,tzinfo=timezone.utc)
base=dict(rule_version_id='rule-v1',contract_version_id='contract-v1',definition=defn,tariffs=tariffs,reference_time=ref)
checks=0
def ok(cond,msg):
 global checks
 assert cond,msg; checks+=1
r1=price_item(inputs={'procedure_code':'P1','participation_pct':'30','urgency':True,'quantity':1},**base)
r2=price_item(inputs={'quantity':1,'urgency':True,'participation_pct':'30','procedure_code':'P1'},**base)
ok(r1==r2,'determinismo independe da ordem do dict de entrada')
ok(r1['price_status']=='PRICED' and r1['expected_amount']=='58.50','caso ilustrativo determinístico')
ok(r1['snapshot_hash']==r2['snapshot_hash'],'hash determinístico')
oracle=pricing_snapshot_hash('rule-v1','contract-v1',r1['currency'],r1['expected_amount'],r1['price_status'],_json.dumps(r1['inputs'],ensure_ascii=False,sort_keys=True,separators=(',',':')),_json.dumps(r1['intermediate_values'],ensure_ascii=False,sort_keys=True,separators=(',',':')),r1['formula'],ref)
ok(r1['snapshot_hash']==oracle,'motor usa exatamente o hash canônico pricing_snapshot_hash')
ok(r1['rule_version_id']=='rule-v1' and r1['contract_version_id']=='contract-v1','snapshot fixa versões')
missing=price_item(inputs={'procedure_code':'PX','participation_pct':'100','urgency':False,'quantity':1},**base)
ok(missing['price_status']=='UNKNOWN' and missing['expected_amount'] is None,'tarifa ausente é UNKNOWN')
zero=price_item(inputs={'procedure_code':'P0','participation_pct':'100','urgency':False,'quantity':1},**base)
ok(zero['price_status']=='CONTRACTUAL_ZERO' and zero['expected_amount']=='0.00','zero contratual é explícito')
old=dict(r1); changed_tariffs={'procedimentos':{'P1':'999.00','P0':'0'}}
new=price_item(inputs={'procedure_code':'P1','participation_pct':'30','urgency':True,'quantity':1},**{**base,'tariffs':changed_tariffs,'contract_version_id':'contract-v2'})
ok(old==r1,'snapshot antigo não é recalculado por contrato novo')
ok(new['expected_amount']!='58.50' and new['contract_version_id']=='contract-v2','novo contrato produz novo snapshot')
ok(Decimal(r1['expected_amount'])>=0,'preço nunca negativo')
print(f'== 21 rule engine contract: {checks} ok, 0 falha(s)')
