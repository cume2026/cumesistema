from dataclasses import dataclass
@dataclass(frozen=True)
class ReportSnapshot: report_snapshot_id:str; tenant_id:str; report_type:str; artifact_hash:str
