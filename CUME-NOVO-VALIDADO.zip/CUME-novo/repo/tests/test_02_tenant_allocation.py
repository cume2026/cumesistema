import subprocess
from fixtures import *
r=Report('02 isolamento referencial + teto de alocação')
uri=fresh('t2');s=S(uri);tA,tB=u(),u();FA=build(s,tA);FB=build(s,tB)
I=lambda t,T=tA:s.ids[(t,T)]
def alloc(T,pay,amt,ci=None,pi=None): return s.ins('payment_allocation',T,over={'payment_id':pay,'claim_item_id':ci or I('claim_item'),'production_item_id':pi or I('production_item'),'allocated_amount':amt})[:2]
r.expect('encounter(B)->paciente(A) barrado por FK composto',sh(uri,f"insert into encounter(encounter_id,tenant_id,patient_id,idempotency_key,status,started_at) values('{u()}','{tB}','{I('patient_identity')}','k1','IN_PROGRESS',now())"),'fail','foreign key')
r.expect('encounter(A)->paciente(A) (controle +)',sh(uri,f"insert into encounter(encounter_id,tenant_id,patient_id,idempotency_key,status,started_at) values('{u()}','{tA}','{I('patient_identity')}','k3','IN_PROGRESS',now())"),'ok')
r.expect('idempotency_key duplicada no mesmo tenant',sh(uri,f"insert into encounter(encounter_id,tenant_id,patient_id,idempotency_key,status,started_at) values('{u()}','{tA}','{I('patient_identity')}','k3','IN_PROGRESS',now())"),'fail','encounter_tenant_id_idempotency_key_key')
r.expect('alocação tenant B -> payment A (profundo)',alloc(tB,I('payment'),10),'fail','foreign key')
pay=I('payment'); r.check('payment.remitted_amount=100',q(uri,f"select remitted_amount from payment where payment_id='{pay}'")[0]=='100.00')
r.expect('alocar 60 (controle +)',alloc(tA,pay,60),'ok')
r.expect('alocar +50 (110>100)',alloc(tA,pay,50),'fail','allocation cap exceeded')
r.expect('alocar +40 (=100, limite exato)',alloc(tA,pay,40),'ok')
r.expect('reduzir remitted p/ 90 com 100 alocado',sh(uri,f"update payment set remitted_amount=90 where payment_id='{pay}'"),'fail','allocation cap exceeded')
r.check('soma alocada=100',q(uri,f"select sum(allocated_amount) from payment_allocation where payment_id='{pay}'")[0]=='100.00')
rc,e,p2=s.ins('payment',tA,over={'remitted_amount':'100.00'}); r.check('payment2 criado',rc==0,e)
def sess():
    sql=f"BEGIN; insert into payment_allocation(allocation_id,tenant_id,payment_id,claim_item_id,production_item_id,allocated_amount,allocated_at) values('{u()}','{tA}','{p2}','{I('claim_item')}','{I('production_item')}',60,now()); select pg_sleep(2); COMMIT;"
    return subprocess.Popen([PSQL,'-v','ON_ERROR_STOP=1','-X','-q','-c',sql,uri],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,errors='replace')
ps=[sess(),sess()]; rcs=[]
for p in ps: p.communicate(); rcs.append(p.returncode)
r.check('concorrência: exatamente 1 de 2 sessões (60+60 sobre teto 100) vence',sorted(rcs)==[0,1],rcs)
r.check('soma do payment2 = 60',q(uri,f"select coalesce(sum(allocated_amount),0) from payment_allocation where payment_id='{p2}'")[0]=='60.00')
r.done()
