# ADR-0014 — Linguagem/stack de produção

**Status:** PROPOSED (rascunho; nenhuma decisão tomada)

Escolher UM stack (Python ou TypeScript) para domínio+API+worker. Hoje: referência Python (domain_ref) e TS no spine v0.3. Critérios: equipe, bibliotecas de Decimal/OIDC/OTel, testes de paridade de hash. Status: PROPOSED; decisão do dono.

**Consequências:** a preencher após decisão.
