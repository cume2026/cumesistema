# CUME — technical spine working repository

Current package phase: **2/4 audit repair**.

The previous terminal claim (`known_local_executable_gap_count = 0`) is superseded. See the current package entry point `../00_START_HERE/README.md` and Phase 1 evidence.

## Canonical technical sources
- DDL: `db/migrations/0001…0021`
- State machines: `spec/state_machines.yaml`
- Operational ontology: `../blueprint/02_ontology/onto_ops_cume.yaml`
- Generated catalog: `../blueprint/01_taxonomy/generated_catalog.yaml`
- Generated ERD: `docs/erd.mmd`
- Tests: `tests/test_*.py` (historical numbering debt documented in `tests/TEST_NUMBERING.md`)

## Drift check
```bash
python3 scripts/gen_blueprint_views.py --check
```

## Full verification
```bash
python3 tests/run_all.py
```
PostgreSQL-dependent suites are only `EXECUTED/OBSERVED` when their runtime actually ran. Missing dependencies never count as PASS.

All G0–G12 remain BLOCKED pending their explicit acceptance evidence and independent review.
