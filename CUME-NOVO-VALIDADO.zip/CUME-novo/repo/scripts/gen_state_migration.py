#!/usr/bin/env python3
"""Gera db/migrations/0009_state_machines.sql a partir de spec/state_machines.yaml (fonte única). 
Uso: python3 scripts/gen_state_migration.py [--check]   (--check: falha se o arquivo em disco divergir do gerado)"""
import sys,yaml
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
def generate():
    spec=yaml.safe_load((ROOT/'spec'/'state_machines.yaml').read_text())
    L=["-- CUME 0009 — máquinas de estado impostas no banco. GERADO por scripts/gen_state_migration.py a partir de spec/state_machines.yaml. NÃO EDITAR À MÃO.",
       "-- Transições são HIPÓTESE DE DOMÍNIO (DESIGNED) até validação por especialista; o banco só impõe o que a spec declara.",
       "BEGIN;",
       "CREATE TABLE state_initial_rule (table_name text NOT NULL, state_column text NOT NULL, state text NOT NULL, PRIMARY KEY (table_name, state_column, state));",
       "CREATE TABLE state_transition_rule (table_name text NOT NULL, state_column text NOT NULL, from_state text NOT NULL, to_state text NOT NULL, PRIMARY KEY (table_name, state_column, from_state, to_state));",
       "GRANT SELECT ON state_initial_rule, state_transition_rule TO cume_app, cume_auditor;",
       "CREATE FUNCTION enforce_state_machine() RETURNS trigger LANGUAGE plpgsql AS $$",
       "DECLARE col text := TG_ARGV[0]; nw text := to_jsonb(NEW)->>col; od text;",
       "BEGIN",
       "  IF TG_OP='INSERT' THEN",
       "    IF NOT EXISTS (SELECT 1 FROM state_initial_rule WHERE table_name=TG_TABLE_NAME AND state_column=col AND state=nw) THEN",
       "      RAISE EXCEPTION 'illegal initial state % for %.%', nw, TG_TABLE_NAME, col USING ERRCODE='check_violation'; END IF;",
       "    RETURN NEW;",
       "  END IF;",
       "  od := to_jsonb(OLD)->>col;",
       "  IF nw IS DISTINCT FROM od AND NOT EXISTS (SELECT 1 FROM state_transition_rule WHERE table_name=TG_TABLE_NAME AND state_column=col AND from_state=od AND to_state=nw) THEN",
       "    RAISE EXCEPTION 'illegal transition % -> % for %.%', od, nw, TG_TABLE_NAME, col USING ERRCODE='check_violation'; END IF;",
       "  RETURN NEW;",
       "END $$;"]
    for name,m in spec['machines'].items():
        if m.get('skip_generation'): continue
        t,c=m['table'],m['column']
        for s in m['initial']: L.append(f"INSERT INTO state_initial_rule VALUES ('{t}','{c}','{s}');")
        for a,bs in m['transitions'].items():
            for b in bs: L.append(f"INSERT INTO state_transition_rule VALUES ('{t}','{c}','{a}','{b}');")
        L.append(f"CREATE TRIGGER {t}_{c}_state_machine BEFORE INSERT OR UPDATE OF {c} ON {t} FOR EACH ROW EXECUTE FUNCTION enforce_state_machine('{c}');")
    L.append("COMMIT;")
    return "\n".join(L)+"\n"
if __name__=='__main__':
    out=ROOT/'db'/'migrations'/'0009_state_machines.sql'; g=generate()
    if '--check' in sys.argv:
        ok=out.exists() and out.read_text()==g; print('OK: 0009 em dia com a spec' if ok else 'DIVERGE: rode gen_state_migration.py'); sys.exit(0 if ok else 1)
    out.write_text(g); print('escrito',out)
