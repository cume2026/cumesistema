"""CUME temporal reference policy for typed competence and operational clock (B-24)."""
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

class TemporalPolicyError(ValueError):
    pass

@dataclass(frozen=True, order=True)
class Competence:
    year: int
    month: int
    def __post_init__(self):
        if self.year < 1900 or self.year > 9999 or self.month < 1 or self.month > 12:
            raise TemporalPolicyError('invalid competence')
    @classmethod
    def parse(cls, value: str):
        if not isinstance(value,str) or len(value)!=7 or value[4]!='-' or not (value[:4]+value[5:]).isdigit():
            raise TemporalPolicyError('competence must be YYYY-MM')
        return cls(int(value[:4]),int(value[5:]))
    def __str__(self):
        return f'{self.year:04d}-{self.month:02d}'
    @property
    def first_day(self):
        from datetime import date
        return date(self.year,self.month,1)


def _aware(value: datetime) -> bool:
    return isinstance(value,datetime) and value.tzinfo is not None and value.utcoffset() is not None


def _zone(name: str) -> ZoneInfo:
    if not isinstance(name,str) or not name:
        raise TemporalPolicyError('timezone name required')
    try:
        return ZoneInfo(name)
    except ZoneInfoNotFoundError as e:
        raise TemporalPolicyError('unknown timezone') from e


def derive_competence(instant: datetime, timezone_name: str) -> Competence:
    if not _aware(instant):
        raise TemporalPolicyError('instant must be timezone-aware')
    local=instant.astimezone(_zone(timezone_name))
    return Competence(local.year,local.month)


def deadline_after_calendar_days(start: datetime, days: int, timezone_name: str) -> datetime:
    """Calendar-day deadline preserving local wall time. Not a business-day calendar."""
    if not _aware(start):
        raise TemporalPolicyError('start must be timezone-aware')
    if not isinstance(days,int) or isinstance(days,bool) or days < 0:
        raise TemporalPolicyError('days must be a non-negative integer')
    z=_zone(timezone_name)
    local=start.astimezone(z)
    target_local=local + timedelta(days=days)
    return target_local


def deadline_after_business_days(start: datetime, days: int, timezone_name: str, is_business_date) -> datetime:
    """Business-day deadline using an injected authoritative calendar predicate.

    The function supplies mechanics only. It never invents holidays or contractual
    calendars; callers must provide ``is_business_date(date) -> bool``.
    """
    if not _aware(start):
        raise TemporalPolicyError('start must be timezone-aware')
    if not isinstance(days,int) or isinstance(days,bool) or days < 0:
        raise TemporalPolicyError('days must be a non-negative integer')
    if not callable(is_business_date):
        raise TemporalPolicyError('business calendar predicate required')
    local=start.astimezone(_zone(timezone_name))
    if days == 0:
        return local
    current=local
    counted=0
    scanned=0
    while counted < days:
        current=current + timedelta(days=1)
        scanned += 1
        verdict=is_business_date(current.date())
        if type(verdict) is not bool:
            raise TemporalPolicyError('business calendar predicate must return bool')
        if verdict:
            counted += 1
        if scanned > 36600:
            raise TemporalPolicyError('business calendar did not yield enough business dates')
    return current


class OperationalClock:
    def __init__(self, timezone_name: str, now_source):
        self.timezone_name=timezone_name
        self._zone=_zone(timezone_name)
        if not callable(now_source):
            raise TemporalPolicyError('now_source must be callable')
        self._now_source=now_source
    def now_utc(self):
        value=self._now_source()
        if not _aware(value):
            raise TemporalPolicyError('clock source must return timezone-aware datetime')
        return value.astimezone(timezone.utc)
    def current_competence(self):
        return derive_competence(self.now_utc(),self.timezone_name)
