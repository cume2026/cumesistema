#!/bin/bash
# Sabota migrações de propósito e exige que a suíte correspondente FALHE (exit!=0). Rodar na raiz do repo.
set -u; cd "$(dirname "$0")/.."; fail=0
mut(){ d=$(mktemp -d); cp -r db/migrations/. $d/; sed -i -E "$3" $d/$2
  if cmp -s db/migrations/$2 $d/$2; then echo "MUTAÇÃO $1 NÃO ALTEROU O ARQUIVO"; fail=1; return; fi
  CUME_MIG_DIR=$d timeout 250 python3 tests/$4 >/dev/null 2>&1; rc=$?
  if [ $rc -ne 0 ]; then echo "OK   mutante [$1] detectado por $4"; else echo "FALHA mutante [$1] SOBREVIVEU em $4"; fail=1; fi; }
mut audit_trigger 0002_append_only_and_tenant_fk.sql '/audit_event_append_only/d' test_03_audit_append_only.py
mut alloc_cap 0004_allocation_cap.sql '/CREATE CONSTRAINT TRIGGER payment_allocation_cap/,/EXECUTE FUNCTION check_allocation_cap\(\);/d' test_02_tenant_allocation.py
mut rls_policy 0005_roles_and_rls.sql '/CREATE POLICY payment_tenant_isolation/d' test_04_rls_roles.py
mut unknown_zero 0008_versioned_rules_and_pricing.sql 's/AND expected_amount IS NOT NULL//g' test_07_rules_pricing.py
mut approval_guard 0007_maker_checker_enforcement.sql "s/IF a.status IS DISTINCT FROM 'APPROVED' THEN RAISE/IF false THEN RAISE/" test_06_maker_checker.py
mut claim_machine 0009_state_machines.sql '/claim_status_state_machine/d' test_09_state_machines.py
mut transition_rule 0009_state_machines.sql "/VALUES \\('claim','status','SUBMITTED','ACKNOWLEDGED'\\)/d" test_09_state_machines.py
mut nan_check 0010_numeric_not_nan.sql '/payment_remitted_amount_not_nan/d' test_13_numeric_nan_hardening.py
mut nan_fin_adj 0010_numeric_not_nan.sql '/financial_adjustment_amount_not_nan/d' test_13_numeric_nan_hardening.py
# B-21: one DB mutant + one dependency-free content-addressing mutant.
mut b21_rule_payload_hash 0011_rule_contract_content.sql 's/definition_hash = cume_content\.sha256_text\(canonical_payload\)/definition_hash = definition_hash/' test_17_rule_contract_content.py
mut_py(){ d=$(mktemp -d); cp -a . "$d/repo"; sed -i -E "$2" "$d/repo/$1"
  if cmp -s "$1" "$d/repo/$1"; then echo "MUTAÇÃO $4 NÃO ALTEROU O ARQUIVO"; fail=1; return; fi
  (cd "$d/repo" && timeout 60 python3 "tests/$3") >/dev/null 2>&1; rc=$?
  if [ $rc -ne 0 ]; then echo "OK   mutante [$4] detectado por $3"; else echo "FALHA mutante [$4] SOBREVIVEU em $3"; fail=1; fi; }
mut_py domain_ref/content_address.py 's/return json\.dumps\(definition, sort_keys=True/return json.dumps(definition, sort_keys=False/' test_16_content_addressing_unit.py b21_rule_serialization

# QA harness: mutante independente de PostgreSQL; remove o blueprint da imagem declarada.
mut_pkg(){ d=$(mktemp -d); mkdir -p "$d/pkg"; cp -a . "$d/pkg/repo"; cp -a ../blueprint "$d/pkg/blueprint"; sed -i -E "$2" "$d/pkg/$1"
  if cmp -s "../$1" "$d/pkg/$1" 2>/dev/null; then echo "MUTAÇÃO $4 NÃO ALTEROU O ARQUIVO"; fail=1; return; fi
  (cd "$d/pkg/repo" && timeout 60 python3 "tests/$3") >/dev/null 2>&1; rc=$?
  if [ $rc -ne 0 ]; then echo "OK   mutante [$4] detectado por $3"; else echo "FALHA mutante [$4] SOBREVIVEU em $3"; fail=1; fi; }
mut_pkg blueprint/11_infra_deploy/Dockerfile.tests '/COPY blueprint\/ \/workspace\/blueprint\//d' test_19_qa_harness_contract.py qa_blueprint_copy
mut_py domain_ref/input_parse.py 's/if text\.startswith\("-"\):/if False and text.startswith("-"):/' test_20_input_parsing_ptbr.py b25_negative_guard
# Cycle 8 dependency-free mutants
mut_py evidence_ref/audit_chain.py "s/'action':e.action/'action':None/" test_32_b06_evidence_chain_contract.py b06_action_omitted_from_hash
mut_py iam_ref/approval.py "s/needed={'SECURITY_ADMIN'} if req.operation=='PERMISSION_CHANGE' else BILLING_CHECKER/needed={'BILLING_APPROVER'} if req.operation=='PERMISSION_CHANGE' else BILLING_CHECKER/" test_34_b07_approval_contract.py b07_wrong_permission_checker
exit $fail
