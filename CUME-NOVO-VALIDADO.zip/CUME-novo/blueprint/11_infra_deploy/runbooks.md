# Runbooks (RASCUNHOS — não executados; testar antes de confiar)

## 1. Migração de banco (expand/contract)
1. Revisão por par + `tests/run_all.py` + `mutation_check.sh` verdes. 2. Aplicar em staging com dump **sintético com dados prévios** (0007/0008 hoje exigem tabelas vazias: criar backfill/ADR antes). 3. Medir duração e locks. 4. Produção em janela; `BEGIN…COMMIT` por migração; credencial de migração **separada** do runtime. 5. Verificar invariantes pós-deploy (consultas de sentinela). 6. Rollback = migração reversa **preparada e testada** ou restore (preferir expand/contract para evitar rollback destrutivo).

## 2. Backup e restore (NÃO testado)
Backup físico/contínuo (PITR) + lógico periódico; cifrados; chaves fora do banco; retenção por política. **Exercício de restore trimestral**: restaurar em ambiente isolado, comparar contagens por tabela, somas por tenant, hashes de snapshots e a cadeia de auditoria; registrar RPO/RTO **medidos**.

## 3. Release e rollback
Artefato imutável assinado; deploy progressivo; smoke tests; rollback por redeploy do artefato anterior; migração compatível com a versão anterior da aplicação.

## 4. Incidente
Ver `07_security_privacy/incident_response_runbook.md`.

## 5. Falha de integração externa
Parar o publisher da outbox daquele destino; manter fila; reconciliar com a contraparte antes de reprocessar; nunca "reenviar tudo".

## 6. Rotação de segredos / revogação de acesso
Procedimento por tipo (JWKS, credenciais de DB, chaves de storage); revogar sessões; auditar uso.
