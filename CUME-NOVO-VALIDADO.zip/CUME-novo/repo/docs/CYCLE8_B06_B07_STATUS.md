# CUME Cycle 8 — B-06 + B-07 status

## B-06
- Chain reference: SPECIFIED → MATERIALIZED → EXECUTED → OBSERVED.
- PostgreSQL DDL 0014: SPECIFIED → MATERIALIZED; EXECUTION=BLOCKED; VERIFIED=NO.
- Auditor read role: MATERIALIZED; runtime authorization=BLOCKED/UNVERIFIED.
- Independent external checkpoint: BLOCKED/DISCONNECTED/UNAUTHORIZED/UNVERIFIED.

## B-07
- Approval reference: SPECIFIED → MATERIALIZED → EXECUTED → OBSERVED.
- DENIAL_ACCEPT/PERMISSION_CHANGE/SoD DDL 0015: MATERIALIZED; PostgreSQL execution=BLOCKED.
- PHYSICIAN_SETTLEMENT reference semantics: EXECUTED/OBSERVED.
- PHYSICIAN_SETTLEMENT database enforcement: BLOCKED_BY_B11.
- Real IdP/MFA and runtime authorization remain BLOCKED/UNVERIFIED.

No gate is promoted by this cycle. G7 and G8 remain BLOCKED.
