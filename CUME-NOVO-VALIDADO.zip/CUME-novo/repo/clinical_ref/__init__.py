"""CUME clinical reference contracts. Project scope: CUME_ONLY."""
