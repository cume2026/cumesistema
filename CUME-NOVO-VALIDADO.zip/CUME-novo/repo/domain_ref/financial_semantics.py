"""CUME reference semantics for nullable remittance monetary observations.

B-09 decision: NULL/absent means UNKNOWN, never zero. Zero is an explicit known amount.
Reference-only; persistence enforcement is materialized separately in migration 0016.
"""
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_HALF_EVEN

Q=Decimal('0.01')
FIELDS=('allowed_amount','denied_amount','contractual_adjustment','other_adjustment')

class AmountSemanticError(ValueError):
    pass

@dataclass(frozen=True)
class MoneyObservation:
    status: str
    amount: Decimal|None

def observe_amount(value):
    if value is None:
        return MoneyObservation('UNKNOWN',None)
    if not isinstance(value, Decimal):
        raise AmountSemanticError('amount must be Decimal or None')
    if not value.is_finite() or value < 0:
        raise AmountSemanticError('amount must be finite and non-negative')
    return MoneyObservation('KNOWN',value.quantize(Q,rounding=ROUND_HALF_EVEN))

def normalize_remittance_amounts(row):
    out={}
    for field in FIELDS:
        obs=observe_amount(row.get(field))
        out[field]=obs.amount
        out[field+'_status']=obs.status
    return out
