"""Transaction-local tenant context contract for CUME B-01.

Classification:
  epistemic_state: MATERIALIZED
  lifecycle_status: CANDIDATE_REFERENCE_ONLY
  project_scope: CUME_ONLY
  postgres_runtime_verification: BLOCKED

`set_config(name, value, true)` is PostgreSQL's transaction-local equivalent of
SET LOCAL and avoids carrying tenant context across a committed/rolled-back
transaction when used on a real PostgreSQL connection.
"""
from __future__ import annotations
from contextlib import contextmanager
from dataclasses import dataclass
import uuid

@dataclass(frozen=True)
class RuntimeDbPolicy:
    application_role: str='cume_app'
    migration_role: str='cume_migrator'
    tenant_guc: str='app.tenant_id'
    tenant_set_sql: str="SELECT set_config('app.tenant_id', %s, true)"

@contextmanager
def tenant_transaction(connection, tenant_id:str, *, policy:RuntimeDbPolicy|None=None):
    policy=policy or RuntimeDbPolicy()
    tenant_id=str(uuid.UUID(str(tenant_id)))
    login_role=getattr(connection,'login_role',None)
    if login_role is not None and login_role!=policy.application_role:
        raise PermissionError('runtime transaction must use cume_app role')
    connection.begin()
    try:
        connection.execute(policy.tenant_set_sql,(tenant_id,))
        yield connection
    except BaseException:
        connection.rollback()
        raise
    else:
        connection.commit()
