"""Dependency-free operational reference contracts for CUME."""
