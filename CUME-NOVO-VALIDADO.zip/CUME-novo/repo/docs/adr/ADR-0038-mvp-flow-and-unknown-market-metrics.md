# ADR-0038 — Canonical MVP flow and unknown market metrics

**Status:** ACCEPTED_FOR_REFERENCE  
**Classification:** SPECIFIED → MATERIALIZED → EXECUTED → OBSERVED_LOCAL

## Decision
The executable MVP flow is strictly:

`PRODUCTION → CONFERENCE → PENDING_OR_DIVERGENCE → RESOLUTION → RECEIPT → REPORT`.

Skipping stages is rejected by the reference state machine. Clinical record functionality is outside this MVP. Financial presentation in the UI is server-only.

Market size, price, CAC and LTV remain `UNKNOWN` until measured experiments provide source, population/denominator, period and method.

## Pilot boundary
Pilot remains `BLOCKED`; it requires the upstream gates, verified restore and independent review. No product hypothesis or local reference test promotes G11.
