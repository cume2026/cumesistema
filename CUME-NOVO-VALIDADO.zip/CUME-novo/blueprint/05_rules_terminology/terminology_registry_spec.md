# Registro de terminologias e versões — B-12

**Estado global:** `SPECIFIED → MATERIALIZED`; reference resolver/validator mechanism `EXECUTED → OBSERVED`; official binary ingestion `BLOCKED`; independent verification `UNVERIFIED`.

## Princípio canônico
Nunca fixar “a versão atual” como string global. Cada componente TISS/tabela/competência tem versão, vigência, fonte, `retrieved_at`, SHA-256 e estado de validação próprios.

## Estruturas
- `terminology_version`: existente desde 0001.
- `terminology_code`: materializada em 0019, append-only, código/display/vigência/hash.
- `terminology_crosswalk`: materializada em 0019, N:N, versionada, com `EXACT|BROADER|NARROWER|RELATED`; `EXACT` exige revisão humana.
- `performed_item.terminology_version_id`: resolve pela data do serviço; ambiguidade ou ausência falham fechadas.

## TISS observado em fonte oficial em 2026-10-02
Página ANS publicada em 30/09/2026: Organizacional 202609; Conteúdo/Estrutura 202511; Representação/TUSS 202609; Segurança/Privacidade 202511; Comunicação 04.03.00 e 01.06.00. A documentação organizacional determina uso da terminologia vigente na data do atendimento.

## TUSS
A ANS informa acesso por OCL, Excel, CSV, JSON e API. O CUME não promove os códigos demonstrativos do protótipo. Código real só pode alcançar `VERIFIED` após ingestão do payload oficial, hash, parser/versionamento e resolução de vigência.

## SIGTAP
A documentação oficial do Ministério da Saúde descreve versão por competência mensal. `current_competence` permanece `UNKNOWN_NOT_OBSERVED`; nenhuma competência é inferida.

## XML/XSD
`terminology_ref/xml_validation.py` exige SHA-256 do XSD, parser sem rede/DTD/entity e validação XSD. O mecanismo está observado com fixture sintética. **A validação contra XSD oficial da ANS está BLOCKED**, pois os bytes do pacote oficial não foram obtidos neste runtime.

## Crosswalk
TUSS↔SIGTAP é sempre N:N potencial. Não há equivalência 1:1 presumida. Mapping real exige provenance + human review; nenhum mapping real está `VERIFIED`.
