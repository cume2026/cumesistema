# CUME — Cycle 16 Phase 1/4: AUD-01..AUD-05

**State:** `MATERIALIZED_REPAIR_PENDING_POSTGRES_RERUN`

The former zero-local-gap closure is superseded. This phase repairs the concrete defects reported by the Claude audit: stale temporal fixtures/seed, brittle schema assertions and blueprint drift, missing RLS/policies/grants on the seven 0017 tenant tables, and missing FORCE-RLS / migration-runtime role hardening.

## Local evidence

- 56 non-PostgreSQL suites executed: 56 PASS / 0 FAIL.
- `test_70_aud01_aud05_repair_static.py`: PASS.
- 2/2 static mutants detected.
- Browser regressions 59/61 pass in this host.
- `test_01` and new `test_71` cannot execute here because `pgserver` is unavailable; pip installation fails in this host and no system PostgreSQL binary exists.

## PostgreSQL acceptance still required

A later runtime must install/use PostgreSQL and prove: all migrations 0001–0021 apply; database suites pass; every tenant-bearing canonical table has RLS + policy + FORCE RLS as intended; the seven repaired 0017 entities do not leak cross-tenant; runtime roles are NOBYPASSRLS and distinct from the migration role.

No gate is promoted by this phase.
