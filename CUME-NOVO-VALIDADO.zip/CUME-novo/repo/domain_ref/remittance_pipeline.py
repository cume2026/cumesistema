"""Pure staged remittance pipeline reference for CUME B-03.

No persistence and no external file-format assumptions. A caller injects an adapter
that validates, parses and normalizes one source document. The pipeline records the
canonical stage order and delegates deterministic matching/reconciliation to ledger.py.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Iterable
from ledger import ingest_remittance, LedgerError

class PipelineError(ValueError):
    pass

@dataclass(frozen=True)
class Adapter:
    validate: Callable[[bytes], bool]
    parse: Callable[[bytes], list[dict]]
    normalize: Callable[[list[dict]], list[dict]]

STAGES=('RECEIVE','QUARANTINE','VALIDATE','PARSE','NORMALIZE','STAGE','MATCH','REVIEW','COMMIT','RECEIPT')

def _callable_adapter(adapter: Adapter) -> None:
    if not isinstance(adapter,Adapter) or not callable(adapter.validate) or not callable(adapter.parse) or not callable(adapter.normalize):
        raise PipelineError('valid adapter required')

def process_remittance(source_bytes: bytes, adapter: Adapter, claim_expected: dict, *, reviewed_unmatched: set[str]|frozenset[str]=frozenset()) -> dict:
    _callable_adapter(adapter)
    if not isinstance(source_bytes,(bytes,bytearray)):
        raise PipelineError('source document must be bytes')
    raw=bytes(source_bytes)
    trace=['RECEIVE','QUARANTINE','VALIDATE']
    verdict=adapter.validate(raw)
    if type(verdict) is not bool:
        raise PipelineError('adapter validate() must return bool')
    if not verdict:
        return {'status':'QUARANTINED','trace':trace}

    trace.append('PARSE')
    rows=adapter.parse(raw)
    if not isinstance(rows,list) or not all(isinstance(r,dict) for r in rows):
        raise PipelineError('adapter parse() must return list[dict]')
    trace.append('NORMALIZE')
    normalized=adapter.normalize(rows)
    if not isinstance(normalized,list) or not all(isinstance(r,dict) for r in normalized):
        raise PipelineError('adapter normalize() must return list[dict]')

    trace.extend(['STAGE','MATCH'])
    try:
        rec=ingest_remittance(raw,normalized,claim_expected)
    except LedgerError as exc:
        raise PipelineError(str(exc)) from exc

    trace.append('REVIEW')
    unmatched={str(x['external_id']) for x in rec['items'] if x['match_status']=='UNMATCHED'}
    reviewed=set(reviewed_unmatched)
    if not unmatched <= reviewed:
        return {
            'status':'REVIEW_REQUIRED',
            'trace':trace,
            'source_sha256':rec['source_sha256'],
            'reconciliation':rec,
            'unreviewed_external_ids':sorted(unmatched-reviewed),
        }

    trace.extend(['COMMIT','RECEIPT'])
    return {
        'status':'RECEIPT',
        'trace':trace,
        'source_sha256':rec['source_sha256'],
        'receipt_id':rec['receipt_id'],
        'reconciliation':rec,
    }
