"""Testes baseados em PROPRIEDADES (Hypothesis): motor + fuzz de paridade de hash Python==PostgreSQL. Requer: pip install hypothesis"""
import sys,json
from pathlib import Path
from decimal import Decimal
from datetime import datetime,timezone
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'domain_ref'))
from hypothesis import given,settings,strategies as st,HealthCheck
from rule_eval import evaluate
from pricing_hash import pricing_snapshot_hash as py_hash
from base import *
r=Report('12 propriedades (Hypothesis) + fuzz de paridade de hash')
D={"rule_key":"P","version":"1","currency":"BRL","rounding":{"mode":"HALF_EVEN","scale":2},
   "steps":[{"id":"base","op":"tariff","table":"t","key":"code"},{"id":"f","op":"mul_pct","of":"base","pct_input":"pct"},{"id":"u","op":"mul","of":"f","by":"1.3","when":{"input":"urg","eq":True}},{"id":"tot","op":"round","of":"u"}],"result":"tot"}
money=st.decimals(min_value=Decimal('0'),max_value=Decimal('100000'),places=2)
pct=st.decimals(min_value=Decimal('0'),max_value=Decimal('200'),places=2)
S=dict(max_examples=300,deadline=None,suppress_health_check=[HealthCheck.too_slow])
def prop(label,fn):
    try: fn(); r.check(label,True)
    except AssertionError as e: r.check(label,False,str(e)[:200])
@settings(**S)
@given(money,pct,st.booleans())
def p_det(t,p,u_): 
    a=evaluate(D,{'code':'X','pct':str(p),'urg':u_},{'t':{'X':str(t)}});b=evaluate(D,{'code':'X','pct':str(p),'urg':u_},{'t':{'X':str(t)}});assert a==b
@settings(**S)
@given(money,pct,st.booleans())
def p_nonneg_scale(t,p,u_):
    x=evaluate(D,{'code':'X','pct':str(p),'urg':u_},{'t':{'X':str(t)}})
    assert x['price_status'] in('PRICED','CONTRACTUAL_ZERO') and Decimal(x['expected_amount'])>=0 and Decimal(x['expected_amount']).as_tuple().exponent==-2
    assert (x['price_status']=='CONTRACTUAL_ZERO')==(Decimal(x['expected_amount'])==0)
@settings(**S)
@given(pct,st.booleans(),st.text(max_size=8))
def p_unknown_absorbing(p,u_,code):
    x=evaluate(D,{'code':code,'pct':str(p),'urg':u_},{'t':{}});assert x['price_status']=='UNKNOWN' and x['expected_amount'] is None
@settings(**S)
@given(money,st.decimals(min_value=Decimal('0'),max_value=Decimal('100'),places=2))
def p_split_rounding(t,p1):
    """Divisão de um valor em duas partes (p e 100-p): a SOMA dos arredondados difere do arredondado do total em no máximo 1 centavo — logo o ledger precisa de POLÍTICA explícita de resto."""
    a=evaluate(D,{'code':'X','pct':str(p1),'urg':False},{'t':{'X':str(t)}});b=evaluate(D,{'code':'X','pct':str(Decimal(100)-p1),'urg':False},{'t':{'X':str(t)}});tot=evaluate(D,{'code':'X','pct':'100','urg':False},{'t':{'X':str(t)}})
    diff=abs(Decimal(a['expected_amount'])+Decimal(b['expected_amount'])-Decimal(tot['expected_amount']));assert diff<=Decimal('0.01'),diff
for label,fn in [('determinismo (300 exemplos)',p_det),('não-negatividade, escala 2 e CONTRACTUAL_ZERO<=>0 (300)',p_nonneg_scale),('UNKNOWN é absorvente: tarifa ausente nunca vira número (300)',p_unknown_absorbing),('divisão em partes: |Σ arredondados − arredondado do total| ≤ 0,01 (300)',p_split_rounding)]: prop(label,fn)
# fuzz de paridade de hash contra o PostgreSQL
uri=fresh('t12');R,C=u(),u()
jkey=st.text(alphabet=st.characters(blacklist_categories=('Cs',),blacklist_characters='\x00'),min_size=1,max_size=6)
jval=st.recursive(st.none()|st.booleans()|st.integers(min_value=-10**15,max_value=10**15)|st.decimals(min_value=Decimal('-1e6'),max_value=Decimal('1e6'),places=3,allow_nan=False,allow_infinity=False).map(lambda d:float(d) if False else d)|st.text(alphabet=st.characters(blacklist_categories=('Cs',),blacklist_characters='\x00'),max_size=8),
    lambda c:st.lists(c,max_size=3)|st.dictionaries(jkey,c,max_size=3),max_leaves=8)
class Enc(json.JSONEncoder):
    def default(self,o):
        if isinstance(o,Decimal): return json.loads(format(o,'f'),parse_float=Decimal) 
        return super().default(o)
def to_json(v):
    def conv(x):
        if isinstance(x,Decimal): return ('__DEC__',format(x,'f'))
        if isinstance(x,list): return [conv(i) for i in x]
        if isinstance(x,dict): return {k:conv(i) for k,i in x.items()}
        return x
    t=json.dumps(conv(v),ensure_ascii=False)
    import re; return re.sub(r'\["__DEC__", "([^"]+)"\]',r'\1',t)
bad=[]
@settings(max_examples=150,deadline=None,suppress_health_check=[HealthCheck.too_slow])
@given(jval,jval,money|st.none(),st.sampled_from(['PRICED','CONTRACTUAL_ZERO','UNKNOWN']))
def fuzz(inp,inter,amt,stt):
    ij,mj=to_json({'k':inp}),to_json({'m':inter});a=None if amt is None else str(amt)
    ref=datetime(2026,3,1,12,0,tzinfo=timezone.utc)
    rc,o=sh(uri,f"select pricing_snapshot_hash('{R}','{C}','BRL',{'NULL' if a is None else a},'{stt}','{ij.replace(chr(39),chr(39)*2)}'::jsonb,'{mj.replace(chr(39),chr(39)*2)}'::jsonb,'f','2026-03-01T12:00:00+00')",t=True)
    dbh=o.strip() if rc==0 else None
    pyh=py_hash(R,C,'BRL',a,stt,ij,mj,'f',ref)
    if dbh!=pyh: bad.append((ij[:60],mj[:60],a,dbh and dbh[:8],pyh[:8])); raise AssertionError('divergência')
prop('FUZZ: hash Python == PostgreSQL em 150 documentos JSON aleatórios (unicode, aninhamento, decimais)',fuzz)
if bad: print('  divergências:',bad[:3])
r.done()
