from __future__ import annotations
import hashlib
from lxml import etree

class SchemaIntegrityError(ValueError): pass
class XMLSchemaValidationError(ValueError): pass


def validate_xml_against_xsd(xml_bytes: bytes, xsd_bytes: bytes, expected_xsd_sha256: str) -> bool:
    """Validate XML against caller-supplied XSD bytes after mandatory SHA-256 integrity check.

    This function proves the validation mechanism only. It does not attest that supplied XSD bytes
    are official; provenance is a separate SourceDocument/terminology-version concern.
    """
    actual = hashlib.sha256(xsd_bytes).hexdigest()
    if actual.lower() != expected_xsd_sha256.lower():
        raise SchemaIntegrityError("XSD SHA-256 mismatch")
    upper = xml_bytes.upper()
    if b'<!DOCTYPE' in upper or b'<!ENTITY' in upper:
        raise XMLSchemaValidationError("DTD/entity declarations are forbidden")
    try:
        secure = etree.XMLParser(resolve_entities=False, load_dtd=False, no_network=True, huge_tree=False)
        schema_doc = etree.fromstring(xsd_bytes, parser=secure)
        schema = etree.XMLSchema(schema_doc)
        document = etree.fromstring(xml_bytes, parser=secure)
        schema.assertValid(document)
    except (etree.XMLSyntaxError, etree.DocumentInvalid, etree.XMLSchemaParseError) as exc:
        raise XMLSchemaValidationError(str(exc)) from exc
    return True
