import re
from base import *
r=Report('08 deriva ERD↔DDL + varredura de CHECK/NULL')
uri=fresh('t8')
schemas="('public','clinical','rcm')"
tabs=set(q(uri,f"select table_name from information_schema.tables where table_schema in {schemas} and table_type='BASE TABLE'"))
erd=(ROOT/'docs'/'erd.mmd').read_text()
ents={x.lower() for x in re.findall(r'^\s*([A-Z_]+)\s*\{',erd,re.M)}|{x.lower() for x in re.findall(r'^\s*([A-Z_]+)\s+[\|\}o]',erd,re.M)}|{x.lower() for x in re.findall(r'[\|\}o]\s*[\-\.]+[\|o\{]*\s+([A-Z_]+)\s*:',erd)}
designed_match=re.search(r'DESIGNED \(sem tabela ainda\): ([^\n]+)',erd)
designed=set(designed_match.group(1).replace(' ','').split(',')) if designed_match else set()
r.check('ERD sem tabela e não declarado DESIGNED = vazio',not (ents-tabs-designed),sorted(ents-tabs-designed))
r.check('tabela sem entidade no ERD = vazio',not (tabs-ents),sorted(tabs-ents))
r.check('entidade DESIGNED já materializada = vazio',not (designed&tabs),sorted(designed&tabs))
print('  (informativo) DESIGNED sem tabela:',sorted(designed))
# CHECKs cujo resultado pode ser NULL (passam!) em colunas anuláveis: lista conhecida e revisada
rows=q(uri,"""select c.conrelid::regclass::text||'.'||c.conname from pg_constraint c where c.contype='c' and c.connamespace in ('public'::regnamespace,'clinical'::regnamespace,'rcm'::regnamespace) and exists (select 1 from pg_attribute a where a.attrelid=c.conrelid and a.attnum=any(c.conkey) and not a.attnotnull) order by 1""")
print(f'  (informativo) {len(rows)} CHECKs tocam colunas anuláveis; revisados no ciclo 1f. Pendência: remittance_item.*_amount (NULL=desconhecido? decisão aberta).')
r.check('CHECK pricing_status_amount contém IS NOT NULL explícito',"IS NOT NULL" in ' '.join(q(uri,"select pg_get_constraintdef(oid) from pg_constraint where conname='pricing_status_amount'")))
r.done()
