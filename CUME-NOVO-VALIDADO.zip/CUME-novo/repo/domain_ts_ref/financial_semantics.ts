export type MoneyObservation = {status:'UNKNOWN', cents:null}|{status:'KNOWN', cents:bigint};
export function observeMoney(cents: bigint|null): MoneyObservation {
  if (cents === null) return {status:'UNKNOWN', cents:null};
  if (cents < 0n) throw new Error('negative money rejected');
  return {status:'KNOWN', cents};
}
export function parseStrictDecimal(text: string|null): MoneyObservation {
  if (text === null || text.trim()==='') return {status:'UNKNOWN', cents:null};
  if (!/^(0|[1-9]\d*)\.\d{2}$/.test(text)) throw new Error('strict decimal required');
  const [i,f]=text.split('.'); return observeMoney(BigInt(i)*100n+BigInt(f));
}
