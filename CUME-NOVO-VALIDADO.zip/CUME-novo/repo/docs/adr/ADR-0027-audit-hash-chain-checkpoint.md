# ADR-0027 — Audit hash-chain + checkpoint boundary

**Decision:** ACCEPTED_AS_CANDIDATE_DESIGN. **Runtime verification:** BLOCKED.

`audit_event` receives a per-tenant monotonic sequence, `prev_hash` and canonical SHA-256 `event_hash`. A verifier recomputes the chain. Deletion of the current tail is not detectable from the remaining chain alone; therefore authoritative tamper evidence requires a checkpoint (`event_count`, `head_sequence`, `head_hash`) preserved outside the mutable chain.

The local reference implementation and mutation tests are **EXECUTED/OBSERVED**. Migration `0014` is **MATERIALIZED** but not executed on PostgreSQL in this host. No external checkpoint/anchoring service is connected, authorized or verified. `audit_chain_head` inside the same database is concurrency state, not an independent trust anchor.
