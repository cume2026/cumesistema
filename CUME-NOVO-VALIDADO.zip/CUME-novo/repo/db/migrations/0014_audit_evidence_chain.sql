-- CUME 0014 — evidence plane / per-tenant audit hash-chain candidate.
-- Classification: MATERIALIZED only until executed against dedicated CUME PostgreSQL.
-- Precondition for this candidate migration: audit_event must be empty; backfill/migration with prior data belongs to B-08.
BEGIN;
DO $$ BEGIN
  IF EXISTS (SELECT 1 FROM audit_event LIMIT 1) THEN
    RAISE EXCEPTION '0014 requires empty audit_event; backfill strategy required';
  END IF;
END $$;

ALTER TABLE audit_event
  ADD COLUMN sequence_no bigint,
  ADD COLUMN prev_hash text,
  ADD COLUMN event_hash text;

CREATE TABLE audit_chain_head (
  tenant_id uuid PRIMARY KEY REFERENCES tenant(tenant_id),
  last_sequence bigint NOT NULL DEFAULT 0 CHECK (last_sequence >= 0),
  last_hash text NOT NULL DEFAULT repeat('0',64) CHECK (last_hash ~ '^[0-9a-f]{64}$'),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE FUNCTION audit_event_hash(e audit_event) RETURNS text LANGUAGE sql IMMUTABLE AS $$
 SELECT encode(sha256(convert_to(jsonb_build_object(
   'audit_event_id',e.audit_event_id,'tenant_id',e.tenant_id,'actor_id',e.actor_id,
   'action',e.action,'aggregate_type',e.aggregate_type,'aggregate_id',e.aggregate_id,
   'correlation_id',e.correlation_id,'before_state',e.before_state,'after_state',e.after_state,
   'reason_code',e.reason_code,'occurred_at',to_char(e.occurred_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),
   'sequence_no',e.sequence_no,'prev_hash',e.prev_hash
 )::text,'UTF8')),'hex')
$$;

CREATE FUNCTION audit_event_chain_assign() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public AS $$
DECLARE h audit_chain_head%ROWTYPE;
BEGIN
  INSERT INTO audit_chain_head(tenant_id) VALUES (NEW.tenant_id) ON CONFLICT (tenant_id) DO NOTHING;
  SELECT * INTO h FROM audit_chain_head WHERE tenant_id=NEW.tenant_id FOR UPDATE;
  NEW.sequence_no := h.last_sequence + 1;
  NEW.prev_hash := h.last_hash;
  NEW.event_hash := public.audit_event_hash(NEW);
  UPDATE audit_chain_head SET last_sequence=NEW.sequence_no,last_hash=NEW.event_hash,updated_at=now() WHERE tenant_id=NEW.tenant_id;
  RETURN NEW;
END $$;

CREATE TRIGGER audit_event_chain_assign_t BEFORE INSERT ON audit_event FOR EACH ROW EXECUTE FUNCTION audit_event_chain_assign();
ALTER TABLE audit_event ALTER COLUMN sequence_no SET NOT NULL, ALTER COLUMN prev_hash SET NOT NULL, ALTER COLUMN event_hash SET NOT NULL;
ALTER TABLE audit_event ADD CONSTRAINT audit_event_tenant_sequence_uq UNIQUE (tenant_id, sequence_no);
ALTER TABLE audit_event ADD CONSTRAINT audit_event_prev_hash_sha256 CHECK (prev_hash ~ '^[0-9a-f]{64}$');
ALTER TABLE audit_event ADD CONSTRAINT audit_event_event_hash_sha256 CHECK (event_hash ~ '^[0-9a-f]{64}$');
-- Existing append-only trigger audit_event_append_only remains authoritative for runtime UPDATE/DELETE rejection.

ALTER TABLE evidence ADD CONSTRAINT evidence_must_link_source CHECK (audit_event_id IS NOT NULL OR source_document_id IS NOT NULL);
ALTER TABLE evidence ADD CONSTRAINT evidence_artifact_hash_sha256 CHECK (artifact_hash IS NULL OR artifact_hash ~ '^[0-9a-f]{64}$');

ALTER TABLE audit_chain_head ENABLE ROW LEVEL SECURITY;
CREATE POLICY audit_chain_head_tenant_read ON audit_chain_head FOR SELECT TO cume_auditor
 USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);
GRANT SELECT ON audit_event, evidence, source_document, audit_chain_head TO cume_auditor;
REVOKE INSERT, UPDATE, DELETE, TRUNCATE ON audit_chain_head FROM cume_auditor;
COMMIT;
