-- CUME 0020 — privacy governance / consent / channel preference / retention candidate.
-- Runtime execution is BLOCKED until a dedicated CUME PostgreSQL is available and legal/privacy review adjudicates active policies.
BEGIN;
CREATE SCHEMA IF NOT EXISTS privacy;
GRANT USAGE ON SCHEMA privacy TO cume_app, cume_auditor;

CREATE TABLE privacy.processing_purpose (
  tenant_id uuid NOT NULL REFERENCES public.tenant(tenant_id),
  purpose_code text NOT NULL,
  description text NOT NULL,
  status text NOT NULL CHECK(status IN ('DRAFT','ACTIVE','RETIRED')),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id,purpose_code)
);

CREATE TABLE privacy.retention_policy_version (
  retention_policy_version_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES public.tenant(tenant_id),
  policy_code text NOT NULL,
  data_category text NOT NULL,
  trigger_event text NOT NULL,
  minimum_value integer NOT NULL CHECK(minimum_value>0),
  period_unit text NOT NULL CHECK(period_unit IN ('DAYS','YEARS')),
  basis_source text NOT NULL,
  legal_review_status text NOT NULL CHECK(legal_review_status IN ('PENDING_LEGAL_REVIEW','LEGAL_REVIEWED')),
  disposition_after_expiry text NOT NULL CHECK(disposition_after_expiry IN ('DELETE','ANONYMIZE','DELETE_OR_RETURN','MANUAL_REVIEW')),
  effective_from date NOT NULL,
  effective_to date,
  status text NOT NULL CHECK(status IN ('DRAFT','ACTIVE','RETIRED')),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK(effective_to IS NULL OR effective_to>=effective_from),
  CHECK(status<>'ACTIVE' OR legal_review_status='LEGAL_REVIEWED'),
  UNIQUE(tenant_id,retention_policy_version_id),
  UNIQUE(tenant_id,policy_code,effective_from)
);

CREATE TABLE privacy.processing_activity (
  processing_activity_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES public.tenant(tenant_id),
  purpose_code text NOT NULL,
  legal_basis_code text NOT NULL,
  sensitive_data boolean NOT NULL DEFAULT false,
  sensitive_basis_code text,
  retention_policy_version_id uuid,
  data_categories text[] NOT NULL CHECK(cardinality(data_categories)>0),
  recipient_categories text[] NOT NULL DEFAULT ARRAY[]::text[],
  operator_categories text[] NOT NULL DEFAULT ARRAY[]::text[],
  status text NOT NULL CHECK(status IN ('DRAFT','ACTIVE','RETIRED')),
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY(tenant_id,purpose_code) REFERENCES privacy.processing_purpose(tenant_id,purpose_code),
  FOREIGN KEY(tenant_id,retention_policy_version_id) REFERENCES privacy.retention_policy_version(tenant_id,retention_policy_version_id),
  CHECK(status<>'ACTIVE' OR (legal_basis_code <> 'UNKNOWN' AND retention_policy_version_id IS NOT NULL)),
  CHECK(NOT sensitive_data OR (sensitive_basis_code IS NOT NULL AND sensitive_basis_code <> 'UNKNOWN'))
);

CREATE TABLE privacy.operator_binding (
  operator_binding_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES public.tenant(tenant_id),
  controller_ref text NOT NULL,
  operator_ref text NOT NULL,
  purpose_code text NOT NULL,
  contract_ref text NOT NULL,
  status text NOT NULL CHECK(status IN ('ACTIVE','SUSPENDED','TERMINATED')),
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY(tenant_id,purpose_code) REFERENCES privacy.processing_purpose(tenant_id,purpose_code),
  CHECK(controller_ref<>operator_ref)
);

CREATE TABLE privacy.subject_identity_link (
  subject_ref uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES public.tenant(tenant_id),
  patient_id uuid,
  status text NOT NULL CHECK(status IN ('ACTIVE','DETACHED')),
  detached_at timestamptz,
  detached_reason_code text,
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY(tenant_id,patient_id) REFERENCES public.patient_identity(tenant_id,patient_id),
  UNIQUE(tenant_id,subject_ref),
  CHECK((status='ACTIVE' AND patient_id IS NOT NULL AND detached_at IS NULL) OR
        (status='DETACHED' AND patient_id IS NULL AND detached_at IS NOT NULL AND detached_reason_code IS NOT NULL))
);

CREATE TABLE privacy.consent_event (
  consent_event_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES public.tenant(tenant_id),
  subject_ref uuid NOT NULL,
  purpose_code text NOT NULL,
  notice_version text NOT NULL,
  action text NOT NULL CHECK(action IN ('GRANT','REVOKE')),
  source text NOT NULL,
  recorded_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY(tenant_id,subject_ref) REFERENCES privacy.subject_identity_link(tenant_id,subject_ref),
  FOREIGN KEY(tenant_id,purpose_code) REFERENCES privacy.processing_purpose(tenant_id,purpose_code)
);

CREATE TABLE privacy.channel_preference_event (
  channel_preference_event_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES public.tenant(tenant_id),
  subject_ref uuid NOT NULL,
  purpose_code text NOT NULL,
  channel text NOT NULL CHECK(channel IN ('WHATSAPP','SMS','EMAIL','VOICE_CALL','PUSH')),
  action text NOT NULL CHECK(action IN ('ALLOW','BLOCK')),
  recorded_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY(tenant_id,subject_ref) REFERENCES privacy.subject_identity_link(tenant_id,subject_ref),
  FOREIGN KEY(tenant_id,purpose_code) REFERENCES privacy.processing_purpose(tenant_id,purpose_code)
);

CREATE TABLE privacy.data_subject_request (
  data_subject_request_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES public.tenant(tenant_id),
  subject_ref uuid NOT NULL,
  request_type text NOT NULL CHECK(request_type IN ('ACCESS','CORRECTION','ERASURE','ANONYMIZATION','PORTABILITY','INFORMATION','REVOCATION')),
  status text NOT NULL CHECK(status IN ('RECEIVED','IDENTITY_VERIFICATION','IN_REVIEW','FULFILLED','PARTIAL','REFUSED')),
  received_at timestamptz NOT NULL DEFAULT now(),
  responded_at timestamptz,
  decision_reason text,
  decision_basis_source text,
  FOREIGN KEY(tenant_id,subject_ref) REFERENCES privacy.subject_identity_link(tenant_id,subject_ref),
  CHECK(status NOT IN ('PARTIAL','REFUSED') OR (decision_reason IS NOT NULL AND decision_basis_source IS NOT NULL))
);

CREATE TABLE privacy.retention_hold (
  retention_hold_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES public.tenant(tenant_id),
  resource_type text NOT NULL,
  resource_id uuid NOT NULL,
  reason_code text NOT NULL,
  basis_source text NOT NULL,
  starts_at timestamptz NOT NULL DEFAULT now(),
  ends_at timestamptz,
  status text NOT NULL CHECK(status IN ('ACTIVE','RELEASED')),
  CHECK(ends_at IS NULL OR ends_at>=starts_at)
);

CREATE TABLE privacy.privacy_incident (
  privacy_incident_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES public.tenant(tenant_id),
  discovered_at timestamptz NOT NULL,
  confirmed boolean NOT NULL DEFAULT false,
  involves_personal_data boolean NOT NULL DEFAULT false,
  relevant_risk_or_damage boolean NOT NULL DEFAULT false,
  assessment_at timestamptz,
  communication_state text NOT NULL CHECK(communication_state IN ('PENDING_ASSESSMENT','COMMUNICATION_REQUIRED','COMMUNICATION_NOT_REQUIRED','COMMUNICATED')),
  decision_basis_source text,
  retention_policy_version_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  FOREIGN KEY(tenant_id,retention_policy_version_id) REFERENCES privacy.retention_policy_version(tenant_id,retention_policy_version_id),
  CHECK(communication_state='PENDING_ASSESSMENT' OR decision_basis_source IS NOT NULL)
);

-- Consent and channel preference are append-only event streams. Revocation/blocking is a new event, never an UPDATE/DELETE.
CREATE TRIGGER consent_event_append_only BEFORE UPDATE OR DELETE ON privacy.consent_event FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();
CREATE TRIGGER channel_preference_event_append_only BEFORE UPDATE OR DELETE ON privacy.channel_preference_event FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();

-- Tenant isolation on all tenant-scoped privacy tables.
ALTER TABLE privacy.processing_purpose ENABLE ROW LEVEL SECURITY;
CREATE POLICY processing_purpose_tenant_isolation ON privacy.processing_purpose FOR ALL TO cume_app,cume_auditor USING (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid) WITH CHECK (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid);
ALTER TABLE privacy.retention_policy_version ENABLE ROW LEVEL SECURITY;
CREATE POLICY retention_policy_version_tenant_isolation ON privacy.retention_policy_version FOR ALL TO cume_app,cume_auditor USING (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid) WITH CHECK (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid);
ALTER TABLE privacy.processing_activity ENABLE ROW LEVEL SECURITY;
CREATE POLICY processing_activity_tenant_isolation ON privacy.processing_activity FOR ALL TO cume_app,cume_auditor USING (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid) WITH CHECK (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid);
ALTER TABLE privacy.operator_binding ENABLE ROW LEVEL SECURITY;
CREATE POLICY operator_binding_tenant_isolation ON privacy.operator_binding FOR ALL TO cume_app,cume_auditor USING (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid) WITH CHECK (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid);
ALTER TABLE privacy.subject_identity_link ENABLE ROW LEVEL SECURITY;
CREATE POLICY subject_identity_link_tenant_isolation ON privacy.subject_identity_link FOR ALL TO cume_app,cume_auditor USING (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid) WITH CHECK (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid);
ALTER TABLE privacy.consent_event ENABLE ROW LEVEL SECURITY;
CREATE POLICY consent_event_tenant_isolation ON privacy.consent_event FOR ALL TO cume_app,cume_auditor USING (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid) WITH CHECK (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid);
ALTER TABLE privacy.channel_preference_event ENABLE ROW LEVEL SECURITY;
CREATE POLICY channel_preference_event_tenant_isolation ON privacy.channel_preference_event FOR ALL TO cume_app,cume_auditor USING (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid) WITH CHECK (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid);
ALTER TABLE privacy.data_subject_request ENABLE ROW LEVEL SECURITY;
CREATE POLICY data_subject_request_tenant_isolation ON privacy.data_subject_request FOR ALL TO cume_app,cume_auditor USING (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid) WITH CHECK (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid);
ALTER TABLE privacy.retention_hold ENABLE ROW LEVEL SECURITY;
CREATE POLICY retention_hold_tenant_isolation ON privacy.retention_hold FOR ALL TO cume_app,cume_auditor USING (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid) WITH CHECK (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid);
ALTER TABLE privacy.privacy_incident ENABLE ROW LEVEL SECURITY;
CREATE POLICY privacy_incident_tenant_isolation ON privacy.privacy_incident FOR ALL TO cume_app,cume_auditor USING (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid) WITH CHECK (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid);

GRANT SELECT ON ALL TABLES IN SCHEMA privacy TO cume_app,cume_auditor;
GRANT INSERT,UPDATE ON privacy.processing_purpose,privacy.retention_policy_version,privacy.processing_activity,privacy.operator_binding,privacy.subject_identity_link,privacy.data_subject_request,privacy.retention_hold,privacy.privacy_incident TO cume_app;
GRANT INSERT ON privacy.consent_event,privacy.channel_preference_event TO cume_app;
COMMIT;
