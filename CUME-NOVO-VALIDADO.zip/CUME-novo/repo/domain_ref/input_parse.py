"""Reference input parsers for CUME B-25.

These functions define strict parsing semantics only. They are not an API layer and do
not imply that any application is wired to them. Money is Decimal, never float.
Blank/absent values remain UNKNOWN (None); zero is an explicit parsed value.
"""
from __future__ import annotations

from datetime import date
from decimal import Decimal
import re
from typing import Any

_MONEY_PTBR = re.compile(r"^(?:0|[1-9]\d*|[1-9]\d{0,2}(?:\.\d{3})+),\d{2}$")
_DATE_PTBR = re.compile(r"^\d{2}/\d{2}/\d{4}$")


class InputValidationError(ValueError):
    """Deterministic validation error with a machine-readable code."""

    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(message)


def parse_money_ptbr(value: Any) -> Decimal | None:
    """Parse a strict pt-BR money string into Decimal.

    Accepted examples: ``0,00``, ``1234,56``, ``1.234,56``.
    ``None`` or blank text means UNKNOWN and returns ``None``.
    Negative money is rejected here because reversals/adjustments are separate events.
    """
    if value is None:
        return None
    if not isinstance(value, str):
        raise InputValidationError("MONEY_TYPE", "money input must be text or null")
    text = value.strip()
    if text == "":
        return None
    if text.startswith("-"):
        raise InputValidationError("MONEY_NEGATIVE", "negative money is not accepted by the normal input parser")
    if not _MONEY_PTBR.fullmatch(text):
        raise InputValidationError("MONEY_FORMAT", "money must use strict pt-BR notation with two decimal digits")
    return Decimal(text.replace(".", "").replace(",", "."))


def parse_date_ptbr(value: Any) -> date | None:
    """Parse strict ``DD/MM/YYYY`` text and validate the real Gregorian calendar."""
    if value is None:
        return None
    if not isinstance(value, str):
        raise InputValidationError("DATE_TYPE", "date input must be text or null")
    text = value.strip()
    if text == "":
        return None
    if not _DATE_PTBR.fullmatch(text):
        raise InputValidationError("DATE_FORMAT", "date must use strict DD/MM/YYYY notation")
    day, month, year = (int(part) for part in text.split("/"))
    try:
        return date(year, month, day)
    except ValueError as exc:
        raise InputValidationError("DATE_CALENDAR", "date is not valid in the Gregorian calendar") from exc
