#!/usr/bin/env python3
import pathlib,sys,uuid
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from iam_ref.approval import Principal, ApprovalError, request_approval, decide_approval, authorize_commit, validate_role_set, authorize_role_grant

checks=[]
def ck(label,cond):
    checks.append((label,bool(cond))); print((' ✔ ' if cond else ' ✘ FALHA ')+label)
def blocked(fn):
    try: fn(); return False
    except ApprovalError: return True

def p(*roles): return Principal(str(uuid.uuid4()),frozenset(roles))
clerk=p('BILLING_CLERK'); approver=p('BILLING_APPROVER'); sec1=p('SECURITY_ADMIN'); sec2=p('SECURITY_ADMIN'); nobody=p('PHYSICIAN')

# DENIAL_ACCEPT
sid=str(uuid.uuid4()); req=request_approval('DENIAL_ACCEPT','denial',sid,clerk)
ck('DENIAL_ACCEPT maker billing aceito',req.status=='PENDING')
ck('DENIAL_ACCEPT checker sem BILLING_APPROVER barrado',blocked(lambda:decide_approval(req,nobody,True)))
ap=decide_approval(req,approver,True)
ck('DENIAL_ACCEPT aprovado pelo checker correto',ap.status=='APPROVED')
ck('DENIAL_ACCEPT commit coberto',authorize_commit('DENIAL_ACCEPT','denial',sid,ap))
ck('aprovação não cobre subject diferente',blocked(lambda:authorize_commit('DENIAL_ACCEPT','denial',str(uuid.uuid4()),ap)))

# PERMISSION_CHANGE
rid=str(uuid.uuid4()); pr=request_approval('PERMISSION_CHANGE','role_assignment',rid,sec1)
ck('PERMISSION_CHANGE maker SECURITY_ADMIN aceito',pr.status=='PENDING')
ck('PERMISSION_CHANGE checker BILLING_APPROVER barrado',blocked(lambda:decide_approval(pr,approver,True)))
pr2=decide_approval(pr,sec2,True)
ck('PERMISSION_CHANGE checker SECURITY_ADMIN distinto aceito',pr2.status=='APPROVED')
ck('role grant exige aprovação exata',authorize_role_grant(rid,target_user_id=str(uuid.uuid4()),role='PHYSICIAN',grantor=sec1,approval=pr2))
ck('role grant sem aprovação barrado',blocked(lambda:authorize_role_grant(rid,target_user_id=str(uuid.uuid4()),role='PHYSICIAN',grantor=sec1,approval=None)))

# maker != checker
same=p('SECURITY_ADMIN')
r=request_approval('PERMISSION_CHANGE','role_assignment',str(uuid.uuid4()),same)
ck('maker==checker barrado',blocked(lambda:decide_approval(r,same,True)))

# segregation
ck('SECURITY_ADMIN isolado é válido',validate_role_set({'SECURITY_ADMIN'}))
ck('BILLING_CLERK+BILLING_APPROVER é válido',validate_role_set({'BILLING_CLERK','BILLING_APPROVER'}))
ck('SECURITY_ADMIN + BILLING_CLERK é barrado',blocked(lambda:validate_role_set({'SECURITY_ADMIN','BILLING_CLERK'})))
ck('SECURITY_ADMIN + BILLING_APPROVER é barrado',blocked(lambda:validate_role_set({'SECURITY_ADMIN','BILLING_APPROVER'})))

# PHYSICIAN_SETTLEMENT reference contract, table not yet materialized
psid=str(uuid.uuid4()); ps=request_approval('PHYSICIAN_SETTLEMENT','physician_settlement',psid,clerk); ps2=decide_approval(ps,approver,True)
ck('PHYSICIAN_SETTLEMENT reference approval contract',authorize_commit('PHYSICIAN_SETTLEMENT','physician_settlement',psid,ps2))

# security admin cannot initiate billing operation
ck('SECURITY_ADMIN não atua como billing maker',blocked(lambda:request_approval('DENIAL_ACCEPT','denial',str(uuid.uuid4()),sec1)))
# approval immutable after decision
ck('aprovação decidida não pode ser decidida de novo',blocked(lambda:decide_approval(ap,approver,False)))

bad=[x for x in checks if not x[1]]
print(f'== 34 B-07 approval contract: {len(checks)-len(bad)} ok, {len(bad)} falha(s)')
sys.exit(1 if bad else 0)
