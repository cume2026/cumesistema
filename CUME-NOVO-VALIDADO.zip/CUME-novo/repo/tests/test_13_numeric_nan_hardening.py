"""CUME-DB-15: NaN em colunas numeric. (a) guiado pelo catálogo: TODA coluna numeric tem CHECK anti-NaN; (b) comportamento: NaN barrado e o teto de alocação não pode ser contornado."""
from fixtures import *
r=Report('13 numeric: NaN barrado (catálogo + comportamento)')
uri=fresh('t13');s=S(uri);tA=u();F=build(s,tA);I=lambda t:s.ids[(t,tA)]
cols=q(uri,"select table_schema||'.'||table_name||'.'||column_name from information_schema.columns where table_schema in ('public','clinical','rcm') and data_type='numeric' order by 1")
import re
def has_check(tc):
    sch,t,c=tc.split('.')
    ds=q(uri,f"select pg_get_constraintdef(oid) from pg_constraint where conrelid='{sch}.{t}'::regclass and contype='c'")
    return any(re.search(rf"(?<![A-Za-z_]){c} <> 'NaN'::numeric",d) for d in ds)
missing=[c for c in cols if not has_check(c)]
r.check(f'catálogo: as {len(cols)} colunas numeric têm CHECK anti-NaN',not missing,missing)
rc=lambda sql:sh(uri,sql)
r.expect('payment.remitted_amount = NaN (INSERT)',rc(f"insert into payment(payment_id,tenant_id,remittance_id,currency,remitted_amount,received_at) values('{u()}','{tA}','{I('remittance')}','BRL','NaN',now())"),'fail','payment_remitted_amount_not_nan')
r.expect('payment.remitted_amount = NaN (UPDATE)',rc(f"update payment set remitted_amount='NaN' where payment_id='{I('payment')}'"),'fail','payment_remitted_amount_not_nan')
r.expect('claim_item.claimed_amount = NaN',rc(f"update claim_item set claimed_amount='NaN' where claim_item_id='{I('claim_item')}'"),'fail','claim_item_claimed_amount_not_nan')
r.expect('payment_allocation.allocated_amount = NaN',rc(f"insert into payment_allocation(allocation_id,tenant_id,payment_id,claim_item_id,production_item_id,allocated_amount,allocated_at) values('{u()}','{tA}','{I('payment')}','{I('claim_item')}','{I('production_item')}','NaN',now())"),'fail')
r.expect('performed_item.quantity = NaN',rc(f"update performed_item set quantity='NaN' where performed_item_id='{I('performed_item')}'"),'fail','performed_item_quantity_not_nan')
r.expect('Infinity continua barrado (overflow de precisão)',rc(f"update claim_item set claimed_amount='Infinity' where claim_item_id='{I('claim_item')}'"),'fail')
r.expect('controle +: valor finito válido em claim_item',rc(f"update claim_item set claimed_amount=123.45 where claim_item_id='{I('claim_item')}'"),'ok')
settlement=u()
settlement_insert=lambda amount:f"insert into settlement(settlement_id,tenant_id,settlement_amount,period_start,period_end,status) values('{settlement}','{tA}',{amount},'2026-01-01','2026-01-31','DRAFT')"
r.expect('settlement_amount = NaN (INSERT)',rc(settlement_insert("'NaN'")),'fail','settlement_amount_not_nan')
r.expect('settlement finito (controle +)',rc(settlement_insert('100')),'ok')
r.expect('settlement_amount = NaN (UPDATE)',rc(f"update settlement set settlement_amount='NaN' where settlement_id='{settlement}'"),'fail','settlement_amount_not_nan')
physician=u()
approval=approve(uri,tA,F['clerk'],F['approver'],'PHYSICIAN_SETTLEMENT','physician_settlement',physician)
physician_insert=lambda amount:f"insert into physician_settlement(physician_settlement_id,tenant_id,settlement_id,practitioner_id,amount,approval_id) values('{physician}','{tA}','{settlement}','{I('practitioner')}',{amount},'{approval}')"
r.expect('physician_settlement.amount = NaN com aprovação válida',rc(physician_insert("'NaN'")),'fail','physician_settlement_amount_not_nan')
r.expect('repasse finito aprovado (controle +)',rc(physician_insert('50')),'ok')
r.expect('physician_settlement.amount = NaN (UPDATE)',rc(f"update physician_settlement set amount='NaN' where physician_settlement_id='{physician}'"),'fail','physician_settlement_amount_not_nan')
r.check('o contorno do teto (alocar contra pagamento NaN) não é mais alcançável: não existe payment NaN',q(uri,"select count(*) from payment where remitted_amount='NaN'::numeric")==['0'])
r.done()
