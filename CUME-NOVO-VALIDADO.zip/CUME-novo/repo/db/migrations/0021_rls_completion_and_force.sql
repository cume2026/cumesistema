-- CUME 0021 — AUD-04/AUD-05: complete tenant RLS for 0017 entities and harden owner bypass.
-- Classification: MATERIALIZED DDL CANDIDATE. Runtime verification requires PostgreSQL.
-- Migration/runtime separation contract: cume_migrator is BYPASSRLS and MUST NOT be granted to runtime roles.
BEGIN;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='cume_migrator') THEN
    CREATE ROLE cume_migrator NOLOGIN BYPASSRLS;
  END IF;
END $$;
REVOKE cume_migrator FROM cume_app, cume_auditor, cume_clinical, cume_billing;

-- Public RCM/support entities introduced in 0017.
ALTER TABLE batch ENABLE ROW LEVEL SECURITY;
ALTER TABLE batch FORCE ROW LEVEL SECURITY;
CREATE POLICY batch_tenant_isolation ON batch FOR ALL TO cume_app,cume_auditor
  USING (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid)
  WITH CHECK (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid);

ALTER TABLE settlement ENABLE ROW LEVEL SECURITY;
ALTER TABLE settlement FORCE ROW LEVEL SECURITY;
CREATE POLICY settlement_tenant_isolation ON settlement FOR ALL TO cume_app,cume_auditor
  USING (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid)
  WITH CHECK (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid);

ALTER TABLE physician_settlement ENABLE ROW LEVEL SECURITY;
ALTER TABLE physician_settlement FORCE ROW LEVEL SECURITY;
CREATE POLICY physician_settlement_tenant_isolation ON physician_settlement FOR ALL TO cume_app,cume_auditor
  USING (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid)
  WITH CHECK (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid);

ALTER TABLE report_snapshot ENABLE ROW LEVEL SECURITY;
ALTER TABLE report_snapshot FORCE ROW LEVEL SECURITY;
CREATE POLICY report_snapshot_tenant_isolation ON report_snapshot FOR ALL TO cume_app,cume_auditor
  USING (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid)
  WITH CHECK (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid);

GRANT SELECT ON batch,settlement,physician_settlement,report_snapshot TO cume_app,cume_auditor;
GRANT INSERT,UPDATE ON batch,settlement,physician_settlement,report_snapshot TO cume_app;

-- Clinical entities introduced after the clinical schema grants in 0012.
ALTER TABLE clinical.clinical_note ENABLE ROW LEVEL SECURITY;
ALTER TABLE clinical.clinical_note FORCE ROW LEVEL SECURITY;
CREATE POLICY clinical_note_tenant_isolation ON clinical.clinical_note FOR ALL TO cume_clinical,cume_auditor
  USING (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid)
  WITH CHECK (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid);

ALTER TABLE clinical.diagnostic_order ENABLE ROW LEVEL SECURITY;
ALTER TABLE clinical.diagnostic_order FORCE ROW LEVEL SECURITY;
CREATE POLICY diagnostic_order_tenant_isolation ON clinical.diagnostic_order FOR ALL TO cume_clinical,cume_auditor
  USING (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid)
  WITH CHECK (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid);

ALTER TABLE clinical.medication_order ENABLE ROW LEVEL SECURITY;
ALTER TABLE clinical.medication_order FORCE ROW LEVEL SECURITY;
CREATE POLICY medication_order_tenant_isolation ON clinical.medication_order FOR ALL TO cume_clinical,cume_auditor
  USING (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid)
  WITH CHECK (tenant_id=NULLIF(current_setting('app.tenant_id',true),'')::uuid);

REVOKE ALL ON clinical.clinical_note,clinical.diagnostic_order,clinical.medication_order FROM PUBLIC,cume_app,cume_billing;
GRANT SELECT,INSERT,UPDATE ON clinical.clinical_note,clinical.diagnostic_order,clinical.medication_order TO cume_clinical;
GRANT SELECT ON clinical.clinical_note,clinical.diagnostic_order,clinical.medication_order TO cume_auditor;

-- AUD-05: owner bypass is not accepted for tenant-bearing relations. A dedicated migration role
-- has BYPASSRLS; runtime roles are explicitly NOBYPASSRLS and are not members of cume_migrator.
DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT format('%I.%I',c.table_schema,c.table_name) AS fq
      FROM information_schema.columns c
     WHERE c.column_name='tenant_id'
       AND c.table_schema IN ('public','clinical','rcm','cume_content','privacy')
       AND EXISTS (
         SELECT 1 FROM information_schema.tables t
          WHERE t.table_schema=c.table_schema AND t.table_name=c.table_name
            AND t.table_type='BASE TABLE'
       )
     GROUP BY c.table_schema,c.table_name
  LOOP
    EXECUTE 'ALTER TABLE '||r.fq||' ENABLE ROW LEVEL SECURITY';
    EXECUTE 'ALTER TABLE '||r.fq||' FORCE ROW LEVEL SECURITY';
  END LOOP;
END $$;

ALTER ROLE cume_app NOBYPASSRLS;
ALTER ROLE cume_auditor NOBYPASSRLS;
ALTER ROLE cume_clinical NOBYPASSRLS;
ALTER ROLE cume_billing NOBYPASSRLS;

COMMIT;
