BEGIN;
CREATE TABLE payload_schema_registry (payload_kind text PRIMARY KEY, allowed_keys text[] NOT NULL, forbidden_keys text[] NOT NULL, schema_version text NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
INSERT INTO payload_schema_registry VALUES
('EVIDENCE_METADATA',ARRAY['source','parser_version','validation_status','schema_hash'],ARRAY['patient_name','patient_document','cpf','email','phone','clinical_note','diagnosis','medication','password','secret','token'],'1'),
('OUTBOX_EVENT',ARRAY['event_type','payment_id','claim_id','aggregate_id','correlation_id'],ARRAY['patient_name','patient_document','cpf','email','phone','clinical_note','diagnosis','medication','password','secret','token'],'1'),
('AUDIT_STATE',ARRAY['status','reason_code','amount','currency','version','hash'],ARRAY['patient_name','patient_document','cpf','email','phone','clinical_note','diagnosis','medication','password','secret','token'],'1');
CREATE FUNCTION validate_payload_keys(kind text, payload jsonb) RETURNS boolean LANGUAGE sql STABLE AS $$ SELECT EXISTS(SELECT 1 FROM payload_schema_registry r WHERE r.payload_kind=kind AND NOT EXISTS(SELECT 1 FROM jsonb_object_keys(payload) k WHERE NOT(k=ANY(r.allowed_keys)) OR k=ANY(r.forbidden_keys))) $$;
ALTER TABLE report_snapshot ADD CONSTRAINT report_snapshot_parameters_minimized CHECK (jsonb_typeof(parameters)='object' AND NOT (parameters ?| ARRAY['patient_name','patient_document','cpf','email','phone','clinical_note','diagnosis','medication','password','secret','token']));
COMMIT;
