# ADR-0028 — Critical approvals and SECURITY_ADMIN segregation

**Decision:** ACCEPTED_AS_CANDIDATE_DESIGN. **Runtime verification:** BLOCKED.

`DENIAL_ACCEPT` requires an approved request bound to the exact denial. Runtime role grants require `PERMISSION_CHANGE` bound to the exact role-assignment identifier; maker and checker are distinct SECURITY_ADMIN principals. SECURITY_ADMIN must not coexist with active BILLING_CLERK/BILLING_APPROVER assignments.

The reference contract also specifies `PHYSICIAN_SETTLEMENT`, but the settlement entity/table is not yet materialized; database enforcement for that operation is **BLOCKED_BY_B11**. Migration `0015` is therefore partial candidate DDL, not evidence of production enforcement. Owner/bootstrap role provisioning remains a separate B-08 deployment concern.
