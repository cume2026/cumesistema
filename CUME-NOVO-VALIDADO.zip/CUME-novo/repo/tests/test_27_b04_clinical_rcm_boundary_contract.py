#!/usr/bin/env python3
import pathlib, sys, uuid
from datetime import datetime, timezone
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from boundary_ref.clinical_rcm import (
    build_performed_item_event,
    complete_encounter,
    materialize_production_item,
    BoundaryError,
    MINIMIZED_EVENT_FIELDS,
)

checks=[]
def ck(label,cond):
    checks.append((label,bool(cond))); print((' ✔ ' if cond else ' ✘ FALHA ')+label)

tenant=str(uuid.uuid4()); encounter=str(uuid.uuid4()); item=str(uuid.uuid4()); practitioner=str(uuid.uuid4())
performed_at=datetime(2026,10,2,9,30,tzinfo=timezone.utc)
event=build_performed_item_event(
    tenant_id=tenant,
    encounter_id=encounter,
    performed_item_id=item,
    code_system='TUSS',
    code='TEST-CODE',
    quantity='1.000',
    performed_at=performed_at,
    participants=[{'practitioner_id':practitioner,'function_code':'PRIMARY'}],
)
ck('payload contém exatamente allowlist de minimização',set(event)==set(MINIMIZED_EVENT_FIELDS))
for forbidden in ('patient_name','clinical_text','diagnosis','medications','allergies','medical_report','document_body','expected_amount','tariff','price'):
    ck(f'payload não contém {forbidden}',forbidden not in event)
ck('participante contém somente identificador e função',set(event['participants'][0])=={'practitioner_id','function_code'})
ck('evento mantém tenant/encounter/performed item',event['tenant_id']==tenant and event['encounter_id']==encounter and event['performed_item_id']==item)

try:
    build_performed_item_event(
        tenant_id=tenant, encounter_id=encounter, performed_item_id=item,
        code_system='TUSS', code='TEST-CODE', quantity='1.000', performed_at=performed_at,
        participants=[], clinical_text='segredo clínico')
    extra_rejected=False
except TypeError:
    extra_rejected=True
ck('interface rejeita campo clínico extra em vez de propagá-lo',extra_rejected)

completion=complete_encounter(event)
ck('conclusão gera evento RCM',completion['rcm_events']==[event])
ck('conclusão NÃO cria production_item',completion['production_item'] is None)
ck('conclusão não contém preço/tarifa',all(k not in completion for k in ('expected_amount','tariff','price')))

try:
    materialize_production_item(event, {'pricing_snapshot_id':str(uuid.uuid4()),'price_status':'UNKNOWN'})
    unknown_blocked=False
except BoundaryError:
    unknown_blocked=True
ck('production_item com snapshot UNKNOWN é barrado',unknown_blocked)

snapshot_id=str(uuid.uuid4())
prod=materialize_production_item(event, {'pricing_snapshot_id':snapshot_id,'price_status':'PRICED'})
ck('snapshot PRICED permite materialização explícita',prod['pricing_snapshot_id']==snapshot_id and prod['performed_item_id']==item)
ck('production_item não recebe conteúdo clínico',set(prod)=={'production_item_id','tenant_id','performed_item_id','pricing_snapshot_id'})

bad=[x for x in checks if not x[1]]
print(f'== 27 B-04 clinical→RCM boundary contract: {len(checks)-len(bad)} ok, {len(bad)} falha(s)')
sys.exit(1 if bad else 0)
