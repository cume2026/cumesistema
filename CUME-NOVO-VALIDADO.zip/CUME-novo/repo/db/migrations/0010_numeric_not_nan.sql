-- CUME 0010 — NaN não é número válido em colunas numeric (CUME-DB-15). Em PostgreSQL NaN > 0 é VERDADEIRO: CHECK (x > 0) NÃO barra NaN,
-- e com remitted_amount = NaN o teto de alocação (used > cap) nunca dispara. Provado: R$ 6.000.000 alocados contra pagamento NaN (evidence/receipt_nan_bypass.txt).
-- Infinity já é barrado pela precisão numeric(p,s) (overflow). Esta lista é conferida contra o catálogo por tests/test_13.
BEGIN;
ALTER TABLE claim_item ADD CONSTRAINT claim_item_claimed_amount_not_nan CHECK (claimed_amount IS NULL OR claimed_amount <> 'NaN'::numeric);
ALTER TABLE denial ADD CONSTRAINT denial_denied_amount_not_nan CHECK (denied_amount IS NULL OR denied_amount <> 'NaN'::numeric);
ALTER TABLE financial_adjustment ADD CONSTRAINT financial_adjustment_amount_not_nan CHECK (amount IS NULL OR amount <> 'NaN'::numeric);
ALTER TABLE payment ADD CONSTRAINT payment_remitted_amount_not_nan CHECK (remitted_amount IS NULL OR remitted_amount <> 'NaN'::numeric);
ALTER TABLE payment_allocation ADD CONSTRAINT payment_allocation_allocated_amount_not_nan CHECK (allocated_amount IS NULL OR allocated_amount <> 'NaN'::numeric);
ALTER TABLE performed_item ADD CONSTRAINT performed_item_quantity_not_nan CHECK (quantity IS NULL OR quantity <> 'NaN'::numeric);
ALTER TABLE pricing_snapshot ADD CONSTRAINT pricing_snapshot_expected_amount_not_nan CHECK (expected_amount IS NULL OR expected_amount <> 'NaN'::numeric);
ALTER TABLE remittance_item ADD CONSTRAINT remittance_item_allowed_amount_not_nan CHECK (allowed_amount IS NULL OR allowed_amount <> 'NaN'::numeric);
ALTER TABLE remittance_item ADD CONSTRAINT remittance_item_contractual_adjustment_not_nan CHECK (contractual_adjustment IS NULL OR contractual_adjustment <> 'NaN'::numeric);
ALTER TABLE remittance_item ADD CONSTRAINT remittance_item_denied_amount_not_nan CHECK (denied_amount IS NULL OR denied_amount <> 'NaN'::numeric);
ALTER TABLE remittance_item ADD CONSTRAINT remittance_item_other_adjustment_not_nan CHECK (other_adjustment IS NULL OR other_adjustment <> 'NaN'::numeric);
COMMIT;
