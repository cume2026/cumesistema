"""Minimal CUME application/API reference boundary for B-01.

Classification:
  epistemic_state: MATERIALIZED
  lifecycle_status: CANDIDATE_REFERENCE_ONLY
  project_scope: CUME_ONLY
  network_deployment: NOT_EXECUTED
  real_oidc: BLOCKED
  real_database: BLOCKED
"""
from __future__ import annotations
from dataclasses import dataclass
import uuid
from .oidc import AuthenticationError, SyntheticOIDCVerifier, VerifiedIdentity
from domain_ref.input_parse import InputValidationError, parse_money_ptbr, parse_date_ptbr

ALLOWED_ROLES=frozenset({'BILLING_CLERK','BILLING_APPROVER','PHYSICIAN','CLINIC_ADMIN','AUDITOR','SECURITY_ADMIN'})

@dataclass(frozen=True)
class UserAccount:
    user_id: str
    issuer: str
    subject: str
    tenant_id: str
    roles: frozenset[str]

class IdentityDirectory:
    """Server-side reference for user_account + active role assignments.

    No role is trusted from the JWT. The JWT identifies the subject and carries
    a tenant claim; the server-owned directory must independently agree.
    """
    def __init__(self): self._by_subject={}
    def provision(self, *, issuer:str, subject:str, tenant_id:str, user_id:str, roles:set[str]|frozenset[str]):
        if not issuer or not subject: raise ValueError('issuer/subject required')
        tenant_id=str(uuid.UUID(tenant_id)); user_id=str(uuid.UUID(user_id))
        roles=frozenset(roles)
        if not roles <= ALLOWED_ROLES: raise ValueError('unknown role')
        key=(issuer,subject)
        existing=self._by_subject.get(key)
        if existing and existing.tenant_id!=tenant_id:
            raise ValueError('issuer/subject already provisioned in another tenant')
        account=UserAccount(user_id,issuer,subject,tenant_id,roles)
        self._by_subject[key]=account
        return account
    def resolve(self, issuer:str, subject:str): return self._by_subject.get((issuer,subject))

class TenantItemStore:
    """Synthetic tenant-scoped store for API contract tests only."""
    def __init__(self): self._items={}
    def add(self, tenant_id:str, payload:dict):
        tenant_id=str(uuid.UUID(tenant_id)); item_id=str(uuid.uuid4())
        self._items[item_id]=(tenant_id,dict(payload)); return item_id
    def get(self, tenant_id:str, item_id:str):
        row=self._items.get(item_id)
        if row is None or row[0]!=tenant_id: return None
        return dict(row[1])

@dataclass(frozen=True)
class Response:
    status: int
    body: dict

class CumeReferenceApi:
    def __init__(self, verifier:SyntheticOIDCVerifier, directory:IdentityDirectory, store:TenantItemStore):
        self.verifier=verifier; self.directory=directory; self.store=store

    def _principal(self, headers:dict, now:int):
        auth=(headers.get('authorization') or headers.get('Authorization') or '').strip()
        if not auth.startswith('Bearer ') or not auth[7:].strip():
            raise AuthenticationError('missing bearer token')
        identity=self.verifier.verify(auth[7:].strip(),now=now)
        account=self.directory.resolve(identity.issuer,identity.subject)
        if account is None:
            return identity,None,Response(403,{'error':'subject_not_provisioned'})
        if account.tenant_id!=identity.tenant_id:
            return identity,account,Response(403,{'error':'tenant_claim_mismatch'})
        return identity,account,None

    def handle(self, method:str, path:str, headers:dict|None=None, *, now:int, body:dict|None=None) -> Response:
        headers=headers or {}
        try:
            identity,account,denied=self._principal(headers,now)
        except AuthenticationError:
            return Response(401,{'error':'unauthenticated'})
        if denied is not None: return denied
        if method=='GET' and path.startswith('/v1/items/'):
            item_id=path.removeprefix('/v1/items/')
            row=self.store.get(account.tenant_id,item_id)
            return Response(404,{'error':'not_found'}) if row is None else Response(200,row)
        if method=='POST' and path=='/v1/reference/parse-input':
            if body is not None and not isinstance(body,dict):
                return Response(422,{'error':'invalid_input','code':'BODY_TYPE'})
            body=body or {}
            try:
                money=parse_money_ptbr(body.get('money'))
                parsed_date=parse_date_ptbr(body.get('date'))
            except InputValidationError as exc:
                return Response(422,{'error':'invalid_input','code':exc.code})
            return Response(200,{
                'money': None if money is None else format(money,'f'),
                'date': None if parsed_date is None else parsed_date.isoformat(),
            })
        if method=='POST' and path=='/v1/critical/approve':
            if 'BILLING_APPROVER' not in account.roles:
                return Response(403,{'error':'forbidden_role'})
            if identity.mfa is not True:
                return Response(403,{'error':'mfa_required'})
            return Response(200,{'status':'accepted_reference_only','user_id':account.user_id})
        return Response(404,{'error':'not_found'})
