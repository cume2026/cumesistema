# CUME — Cycle 3 B-25 Status — 2026-10-02

## Scope
Contrato de referência para parsing estrito de dinheiro e data pt-BR. Nenhuma API, importador ou frontend foi criado.

## TDD observado
- RED válido: `domain_ref/input_parse.py` ausente → exit 1.
- GREEN: `test_20_input_parsing_ptbr.py` → 22 ok / 0 falhas.
- Mutante `negative_guard`: detectado (21/22).
- Mutante `date_padding`: detectado (21/22).

## Contrato
- Money: `Decimal`, nunca float; `None`/blank = UNKNOWN; `0,00` = zero explícito.
- Aceitos: `1234,56`, `1.234,56`.
- Rejeitados: `1.23`, `10abc`, `NaN`, `Infinity`, negativo, en-US, tipos não textuais.
- Date: apenas `DD/MM/YYYY`, validado por calendário Gregoriano real; sem coerção de ISO ou objeto date.

## Estado epistêmico
`EXECUTED+OBSERVED_REFERENCE_ONLY`. F-03/F-08/F-15 e B-25 permanecem OPEN na camada de produto porque nenhuma API/importador real consome o contrato. Nenhum gate foi promovido.
