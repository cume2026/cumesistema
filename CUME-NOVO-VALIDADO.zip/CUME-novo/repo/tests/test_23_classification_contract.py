#!/usr/bin/env python3
import json, pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
policy_p = ROOT/'governance'/'classification_contract_v1.json'
surface_p = ROOT/'governance'/'surface_registry_v1.json'
errors=[]
if not policy_p.exists(): errors.append('classification_contract_v1.json missing')
if not surface_p.exists(): errors.append('surface_registry_v1.json missing')
if errors:
    print('\n'.join(errors)); sys.exit(1)
policy=json.loads(policy_p.read_text())
surfaces=json.loads(surface_p.read_text())
required_epistemic={'REQUESTED','SPECIFIED','DESIGNED','MATERIALIZED','EXECUTED','OBSERVED','VERIFIED','SETTLED','BLOCKED','FAILED','ABSTAIN','SUPERSEDED','DEPRECATED'}
actual=set(policy['epistemic_materialization_axis']['states'])
assert required_epistemic <= actual, sorted(required_epistemic-actual)
required_dims={'availability_state','documentation_state','connection_state','authorization_state','execution_state','verification_state'}
for s in surfaces['surfaces']:
    miss=required_dims-set(s)
    assert not miss, (s.get('id'), miss)
    assert s.get('project_scope') == 'CUME_ONLY', s.get('id')
    assert s.get('shares_runtime_with_human_omega') is False, s.get('id')
    # AVAILABLE cannot imply any stronger state by omission/default.
    if s['availability_state']=='AVAILABLE':
        assert s['connection_state'] in {'CONNECTED','DISCONNECTED','UNKNOWN','NOT_APPLICABLE'}
        assert s['authorization_state'] in {'AUTHORIZED','UNAUTHORIZED','ACTION_SPECIFIC','UNKNOWN','NOT_APPLICABLE'}
        assert s['execution_state'] in {'EXECUTABLE','BLOCKED','UNKNOWN','NOT_APPLICABLE'}
        assert s['verification_state'] in {'VERIFIED','UNVERIFIED','ABSTAIN','UNKNOWN'}
# Existing canonical registries already carry explicit status fields.
findings=json.loads((ROOT/'governance'/'findings_registry_v0_5.json').read_text())['findings']
assert findings and all('epistemic_state' in f and 'lifecycle_status' in f for f in findings)
# Isolation policy remains mandatory.
iso=json.loads((ROOT/'governance'/'project_isolation_policy_v1.json').read_text())
raw=json.dumps(iso).lower()
assert 'cume' in raw and 'human' in raw
print('== 23 classification contract: PASS ==')
print(f'epistemic_states={len(actual)} surfaces={len(surfaces["surfaces"])} findings={len(findings)}')
