SCHEMAS={
 'EVIDENCE_METADATA': {'source','parser_version','validation_status','schema_hash'},
 'OUTBOX_EVENT': {'event_type','payment_id','claim_id','aggregate_id','correlation_id'},
 'AUDIT_STATE': {'status','reason_code','amount','currency','version','hash'},
 'PRICING_INPUTS': {'procedure_code','participation_role','performed_at','quantity'},
 'PRICING_INTERMEDIATE': {'base_amount','factor','rounded_amount','remainder'},
}
FORBIDDEN={'patient_name','patient_document','cpf','email','phone','clinical_note','diagnosis','medication','password','secret','token'}
def validate_and_redact(kind,payload):
 if kind not in SCHEMAS or not isinstance(payload,dict): raise ValueError('UNKNOWN_OR_INVALID_PAYLOAD_KIND')
 keys=set(payload)
 if keys & FORBIDDEN: raise ValueError('FORBIDDEN_KEY')
 if not keys <= SCHEMAS[kind]: raise ValueError('UNDECLARED_KEY')
 return dict(payload)
