"""Consistência blueprint <-> banco <-> governança. Requer pip: pyyaml jsonschema openapi-spec-validator rdflib."""
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
BP = REPO_ROOT.parent / 'blueprint'
FAIL_CLOSED_BLUEPRINT = True
if not BP.exists():
    print('## 15 consistência blueprint ↔ banco ↔ governança', flush=True)
    print(' ✘ FALHA blueprint/ ausente: suíte não pode ser considerada executada', flush=True)
    print('== 15 consistência blueprint ↔ banco ↔ governança: 0 ok, 1 falha(s)', flush=True)
    sys.exit(1)

import yaml,json,csv,re,glob
from jsonschema import Draft202012Validator
from fixtures import *
ROOT = REPO_ROOT
r=Report('15 consistência blueprint ↔ banco ↔ governança')
uri=fresh('t15')
db_tables=set(q(uri,"select table_name from information_schema.tables where table_schema in ('public','clinical','rcm') and table_type='BASE TABLE'"))
Y=lambda p:yaml.safe_load((BP/p).read_text(encoding='utf-8'))
tax=Y('01_taxonomy/taxonomy.yaml')['bounded_contexts'];mapped=[t for c in tax.values() for t in c['tables']]
r.check('taxonomia: cada tabela do banco em exatamente um contexto',sorted(mapped)==sorted(db_tables),sorted(set(mapped)^db_tables))
onto=Y('02_ontology/onto_ops_cume.yaml');cls=onto['classes']
r.check('ontologia: tabelas das classes existem no banco',all(c['table'] in db_tables for c in cls.values()),[k for k,c in cls.items() if c['table'] not in db_tables])
r.check('ontologia: classes cobrem todas as tabelas de negócio (exclui 2 de configuração de estado)',len({c['table'] for c in cls.values()})==len(db_tables)-2,len(cls))
r.check('ontologia: extremos das relações são classes',all((s in cls or s=='*') and (o in cls or o=='*') for s,p,o,c,n in onto['relations']),[x for x in onto['relations'] if (x[0] not in cls and x[0]!='*') or (x[2] not in cls and x[2]!='*')][:2])
am=Y('07_security_privacy/access_matrix.yaml')
db_roles=set(re.findall(r"'([A-Z_]+)'",' '.join(l for l in q(uri,"select pg_get_constraintdef(oid) from pg_constraint where conrelid='role_assignment'::regclass and contype='c'") if 'role' in l)))
r.check('matriz de acesso: papéis == enum do banco',set(am['roles'])==db_roles,set(am['roles'])^db_roles)
from openapi_spec_validator import validate as oav
api=Y('04_api_events/openapi.yaml');oav(api);r.check('OpenAPI 3.1 válido',True)
scopes={s for p in api['paths'].values() for op in p.values() for sec in op.get('security',[]) for v in sec.values() for s in v}|{'cume.read'}
used={s for v in am['roles'].values() for s in v}
r.check('matriz de acesso: escopos ⊆ escopos da OpenAPI',used<=scopes,sorted(used-scopes))
r.check('OpenAPI: todo escopo exigido é concedido a algum papel',scopes<=used|{'cume.read'},sorted(scopes-used))
for f in glob.glob(str(BP/'04_api_events/event_schemas/*.json')): Draft202012Validator.check_schema(json.load(open(f)))
r.check('9 JSON Schemas de evento válidos',len(glob.glob(str(BP/'04_api_events/event_schemas/*.json')))==9)
import rdflib;g=rdflib.Graph();g.parse(str(BP/'02_ontology/cume.ttl'),format='turtle');r.check('TTL parseia',len(g)>100,len(g))
Draft202012Validator.check_schema(json.load(open(BP/'08_observability/log_schema.json')));r.check('schema de log válido',True)
m={x['name'] for x in Y('08_observability/metrics.yaml')['metrics']}
dash=Y('08_observability/dashboards_alerts.yaml')
r.check('dashboards só usam métricas definidas',{p['m'] for d in dash['dashboards'].values() for p in d['panels']}<=m)
cat=Y('09_quality/adversarial_catalog.yaml')['cases'];ids=[c['id'] for c in cat]
r.check('catálogo adversarial: ids únicos',len(ids)==len(set(ids)),len(ids))
def covered_by_exists(x):
    px=Path(x)
    if (ROOT/x).exists() or (ROOT/'tests'/x).exists(): return True
    pat=x if x.endswith('.py') else x+'*.py'
    return bool(glob.glob(str(ROOT/'tests'/pat)))
miss=[(c['id'],x) for c in cat for x in c['covered_by'] if not covered_by_exists(x)]
r.check('catálogo adversarial: todo "covered_by" aponta para arquivo existente',not miss,miss[:3])
r.check('catálogo: COVERED_DB ⇒ há suíte citada',all(c['covered_by'] for c in cat if c['status']=='COVERED_DB'))
reg=json.load(open(ROOT/'governance/findings_registry_v0_5.json'))['findings'];rid=[f['id'] for f in reg]
r.check('registro: ids únicos e nenhum finding fechado sem revisor',len(rid)==len(set(rid)) and all(f['lifecycle_status']!='CLOSED' for f in reg),len(rid))
r.check('registro: nenhum id CUME-N** residual (colisão com N01–N09 do ChatGPT)',not any(re.fullmatch(r'CUME-N\d\d',i) for i in rid))
gates=yaml.safe_load((ROOT/'governance/gates_G0_G12_v0_5.yaml').read_text())['gates']
r.check('13 gates, todos BLOCKED',len(gates)==13 and all(g['status']=='BLOCKED' for g in gates))
bl={i['id'] for i in yaml.safe_load((ROOT/'governance/backlog_v0_5.yaml').read_text())['items']}
refs=set(re.findall(r'\bB-\d\d\b',' '.join(p.read_text(encoding='utf-8') for p in list(BP.rglob('*.yaml'))+list(BP.rglob('*.md')))))
r.check('toda referência B-xx nos documentos existe no backlog',refs<=bl,sorted(refs-bl))
rows=list(csv.DictReader(open(BP/'14_reconciliation/chatgpt_crosswalk.csv',encoding='utf-8')))
r.check('crosswalk: 27 itens do ChatGPT, todos com correspondente existente',len(rows)==27 and all(i in rid for x in rows for i in x['registro_v0_5'].split(';')),[x['chatgpt_id'] for x in rows if x['registro_v0_5']=='SEM CORRESPONDENTE'])
inv=list(csv.DictReader(open(BP/'07_security_privacy/data_inventory.csv',encoding='utf-8')))
ncols=int(q(uri,"select count(*) from information_schema.columns where table_schema in ('public','clinical','rcm')")[0])
r.check('inventário de dados cobre todas as colunas do banco',len(inv)==ncols,(len(inv),ncols))
r.done()
