# B-08 backup/restore candidate runbook
State: SPECIFIED + MATERIALIZED; NOT_EXECUTED_POSTGRES.

Preconditions: dedicated CUME database, migration role distinct from runtime role, encrypted destination, operator authorization.
Backup: `pg_dump --format=custom --no-owner --file=cume.dump "$CUME_PG_MIGRATION_URI"` and object-store export. Record SHA-256, table counts, invariant sentinel counts and schema migration head in a CUME-BACKUP-MANIFEST-v1 receipt.
Restore verification: restore into an isolated CUME verification database, never production; compare dump/object hashes, row counts, migration head and invariant queries. A successful dump command alone is not a verified restore.
Credentials: migration URI may own/alter schema; runtime URI must not own schema and must not perform migrations. Do not store either credential in the repository or receipt.
Current host: psql/pg_dump/pg_restore unavailable, so backup/restore execution is BLOCKED_BY_ENVIRONMENT.
