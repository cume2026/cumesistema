"""Matriz EXAUSTIVA de transições, derivada de spec/state_machines.yaml. Para cada máquina: (a) conjunto de estados == CHECK do DDL;
(b) estado inicial ilegal barrado; (c) TODA aresta permitida aceita e TODA proibida barrada ('illegal transition'); (d) 0009 em disco == gerada."""
import yaml,subprocess,sys,re
from collections import deque
from fixtures import *
r=Report('09 máquinas de estado (matriz exaustiva spec -> banco)')
spec=yaml.safe_load((ROOT/'spec'/'state_machines.yaml').read_text())['machines']
r.check('0009 em disco == gerada pela spec (scripts/gen_state_migration.py --check)',subprocess.run([sys.executable,str(ROOT/'scripts'/'gen_state_migration.py'),'--check'],capture_output=True).returncode==0)
uri=fresh('t9');s=S(uri);tA=u();F=build(s,tA)
phys=lambda t: 'clinical.clinical_document' if t=='clinical_document' else t
for t in ['remittance_item','denial','appeal','outbox_event','clinical_document']:
    rc,e,_=s.ins(phys(t),tA); r.check(f'fixture {t} criado (estado inicial)',rc==0,e)
unapproved=s.ids[('denial',tA)]
r.expect('DENIAL_ACCEPT sem aprovação é barrado',sh(uri,f"update denial set status='ACCEPTED' where denial_id='{unapproved}'"),'fail','DENIAL_ACCEPT requires APPROVED')
r.check('negativa sem aprovação mantém OPEN',q(uri,f"select status from denial where denial_id='{unapproved}'")==['OPEN'])
def pkcol(t): return q(uri,f"select a.attname from pg_constraint c join pg_attribute a on a.attrelid=c.conrelid and a.attnum=c.conkey[1] where c.conrelid='{t}'::regclass and c.contype='p'")[0]
def check_enum(t,c):
    for l in q(uri,f"select pg_get_constraintdef(oid) from pg_constraint where conrelid='{t}'::regclass and contype='c'"):
        m=re.search(rf"\({c} = ANY \(ARRAY\[(.*?)\]\)\)",l)
        if m and len(re.findall(r"'([^']+)'::text",m.group(1)))>=3: return set(re.findall(r"'([^']+)'::text",m.group(1)))
    return set()
def path(m,a):
    """menor caminho de qualquer estado inicial até a (BFS)."""
    best=None
    for i in m['initial']:
        seen={i:[i]};dq=deque([i])
        while dq:
            x=dq.popleft()
            if x==a: 
                if best is None or len(seen[x])<len(best): best=seen[x]
                break
            for y in m['transitions'].get(x,[]):
                if y not in seen: seen[y]=seen[x]+[y];dq.append(y)
    return best
for name,m in spec.items():
    if m.get('skip_generation'): print(f'  (pulado: {name} — {m["enforced_by"]})'); continue
    t,c=m['table'],m['column']; pt=phys(t); pk=pkcol(pt)
    states=set(m['transitions'])|{y for v in m['transitions'].values() for y in v}|set(m['initial'])
    r.check(f'{name}: estados da spec == CHECK do DDL',states==check_enum(pt,c),sorted(states^check_enum(pt,c)) or '')
    for st in sorted(states-set(m['initial'])):
        r.expect(f'{name}: INSERT direto em estado não inicial {st}',s.ins(pt,tA,over={c:st})[:2],'fail','illegal initial state')
    for st in m['initial']:
        rc,e,_=s.ins(pt,tA,over={c:st}); r.check(f'{name}: INSERT em estado inicial {st}',rc==0,e)
    bad=[];n_ok=n_no=0
    for a in sorted(states):
        p=path(m,a)
        if p is None: bad.append(f'{a} inalcançável'); continue
        for b in sorted(states):
            if a==b: continue
            rc,e,row=s.ins(pt,tA,over={c:p[0]})
            if rc: bad.append(f'seed {p[0]}: {e}'); continue
            if t=='denial':
                approval=approve(uri,tA,F['clerk'],F['approver'],'DENIAL_ACCEPT','denial',row)
                rc,e=sh(uri,f"update denial set acceptance_approval_id='{approval}' where denial_id='{row}'")
                if rc: bad.append(f'denial approval fixture: {e}'); continue
            walk_ok=all(sh(uri,f"update {pt} set {c}='{x}' where {pk}='{row}'")[0]==0 for x in p[1:])
            if not walk_ok: bad.append(f'caminho até {a} falhou'); continue
            rc,e=sh(uri,f"update {pt} set {c}='{b}' where {pk}='{row}'")
            allowed=b in m['transitions'].get(a,[])
            if allowed and rc==0: n_ok+=1
            elif (not allowed) and rc!=0 and 'illegal transition' in e: n_no+=1
            else: bad.append(f'{a}->{b}: esperado {"ACEITO" if allowed else "BARRADO"}, obtido rc={rc} {e[:60]}')
    r.check(f'{name}: matriz {len(states)}x{len(states)-1}: {n_ok} permitidas aceitas, {n_no} proibidas barradas, 0 desvios',not bad and n_ok+n_no==len(states)*(len(states)-1),bad[:3] or '')
r.done()
