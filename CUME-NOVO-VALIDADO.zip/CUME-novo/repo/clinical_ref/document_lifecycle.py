"""B-05 reference-only clinical document lifecycle.

Classification: MATERIALIZED reference implementation; execution status is established by tests.
This module is not a cryptographic signature service and does not provide an independent trusted timestamp authority.
"""
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
import uuid
import yaml

class LifecycleError(ValueError):
    pass

_SPEC = Path(__file__).resolve().parents[1] / 'spec' / 'state_machines.yaml'


def allowed_transitions():
    data=yaml.safe_load(_SPEC.read_text(encoding='utf-8'))
    node=data['machines']['clinical_document']
    transitions={k:set(v or []) for k,v in node.get('transitions',{}).items()}
    for terminal in node.get('terminal',[]):
        transitions.setdefault(terminal,set())
    return transitions

@dataclass(frozen=True)
class AuthenticatedActor:
    user_id: str
    practitioner_id: str | None
    # tuples of (role, organization_id); organization_id is the practice scope.
    role_assignments: tuple[tuple[str,str|None], ...]

    def has_scoped_role(self, role: str, organization_id: str) -> bool:
        return any(r == role and org == organization_id for r,org in self.role_assignments)

@dataclass(frozen=True)
class DocumentVersion:
    document_version_id: str
    document_id: str
    version_number: int
    status: str
    author_user_id: str
    author_practitioner_id: str | None
    server_recorded_at: datetime
    supersedes_version_id: str | None


def transition_document(previous: DocumentVersion, target_status: str, actor: AuthenticatedActor,
                        *, practice_organization_id: str, server_now: datetime,
                        client_timestamp=None) -> DocumentVersion:
    if client_timestamp is not None:
        raise LifecycleError('client supplied timestamp is forbidden')
    if server_now.tzinfo is None or server_now.utcoffset() is None:
        raise LifecycleError('server_now must be timezone-aware')
    matrix=allowed_transitions()
    if previous.status not in matrix or target_status not in matrix.get(previous.status,set()):
        raise LifecycleError(f'invalid transition {previous.status}->{target_status}')
    if not actor.user_id:
        raise LifecycleError('authenticated user is required')
    if target_status == 'SIGNED':
        if not actor.practitioner_id:
            raise LifecycleError('SIGNED requires practitioner identity')
        if not actor.has_scoped_role('PHYSICIAN', practice_organization_id):
            raise LifecycleError('SIGNED requires PHYSICIAN role linked to document practice')
    # Every accepted state change creates an immutable new version. This is stricter than
    # the minimum B-05 rule and guarantees all post-FINAL changes supersede prior content.
    return DocumentVersion(
        document_version_id=str(uuid.uuid4()),
        document_id=previous.document_id,
        version_number=previous.version_number+1,
        status=target_status,
        author_user_id=actor.user_id,
        author_practitioner_id=actor.practitioner_id,
        server_recorded_at=server_now,
        supersedes_version_id=previous.document_version_id,
    )
