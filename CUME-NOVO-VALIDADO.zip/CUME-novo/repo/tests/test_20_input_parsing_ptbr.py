"""B-25: contrato executável para parser estrito de dinheiro/data pt-BR.

Sem I/O e sem PostgreSQL. O parser de referência nunca converte formato ambíguo,
texto parcial, negativo ou valor não textual em dinheiro/data válidos.
"""
from decimal import Decimal
from datetime import date
import sys
from pathlib import Path

DOMAIN_REF = Path(__file__).resolve().parent.parent / 'domain_ref'
sys.path.insert(0, str(DOMAIN_REF))
print('## 20 input parsing pt-BR', flush=True)
if not (DOMAIN_REF / 'input_parse.py').exists():
    print(' ✘ FALHA domain_ref/input_parse.py ausente: contrato B-25 não materializado', flush=True)
    print('== 20 input parsing pt-BR: 0 ok, 1 falha(s)', flush=True)
    sys.exit(1)

from input_parse import InputValidationError, parse_money_ptbr, parse_date_ptbr

ok=0; bad=[]
def check(label, cond, extra=''):
    global ok
    good=bool(cond)
    print(f" {'✔' if good else '✘ FALHA'} {label}" + (f' -> {extra}' if extra else ''), flush=True)
    if good: ok+=1
    else: bad.append(label)

def rejects(label, fn, value, code):
    try:
        fn(value)
    except InputValidationError as e:
        check(label, e.code==code, f'code={e.code!r}')
    except Exception as e:
        check(label, False, f'exception={type(e).__name__}: {e}')
    else:
        check(label, False, 'aceito indevidamente')

# dinheiro: Decimal, pt-BR explícito, UNKNOWN != ZERO
check('money 1.234,56 -> Decimal 1234.56', parse_money_ptbr('1.234,56') == Decimal('1234.56'))
check('money 1234,56 sem separador de milhar', parse_money_ptbr('1234,56') == Decimal('1234.56'))
check('money 0,00 é zero explícito', parse_money_ptbr('0,00') == Decimal('0.00'))
check('money vazio -> UNKNOWN/None', parse_money_ptbr('   ') is None)
check('money ausente -> UNKNOWN/None', parse_money_ptbr(None) is None)
rejects('money 1.23 é ambíguo e rejeitado', parse_money_ptbr, '1.23', 'MONEY_FORMAT')
rejects('money 10abc é rejeitado', parse_money_ptbr, '10abc', 'MONEY_FORMAT')
rejects('money NaN é rejeitado', parse_money_ptbr, 'NaN', 'MONEY_FORMAT')
rejects('money Infinity é rejeitado', parse_money_ptbr, 'Infinity', 'MONEY_FORMAT')
rejects('money negativo é rejeitado; reversão é evento separado', parse_money_ptbr, '-10,00', 'MONEY_NEGATIVE')
rejects('money formato en-US é rejeitado', parse_money_ptbr, '1,234.56', 'MONEY_FORMAT')
rejects('money float não é coercido', parse_money_ptbr, 1.23, 'MONEY_TYPE')

# data: somente DD/MM/AAAA estrito e calendário real
check('date 31/01/2026', parse_date_ptbr('31/01/2026') == date(2026,1,31))
check('date bissexta 29/02/2024', parse_date_ptbr('29/02/2024') == date(2024,2,29))
check('date vazio -> None', parse_date_ptbr('') is None)
check('date ausente -> None', parse_date_ptbr(None) is None)
rejects('date 99/99/2026 é rejeitada', parse_date_ptbr, '99/99/2026', 'DATE_CALENDAR')
rejects('date 29/02/2025 é rejeitada', parse_date_ptbr, '29/02/2025', 'DATE_CALENDAR')
rejects('date ISO não é aceita silenciosamente', parse_date_ptbr, '2026-10-02', 'DATE_FORMAT')
rejects('date sem zero-padding é rejeitada', parse_date_ptbr, '1/2/2026', 'DATE_FORMAT')
rejects('date com lixo final é rejeitada', parse_date_ptbr, '02/10/2026abc', 'DATE_FORMAT')
rejects('date object não é coercido', parse_date_ptbr, date(2026,10,2), 'DATE_TYPE')

print(f'== 20 input parsing pt-BR: {ok} ok, {len(bad)} falha(s)', flush=True)
sys.exit(1 if bad else 0)
