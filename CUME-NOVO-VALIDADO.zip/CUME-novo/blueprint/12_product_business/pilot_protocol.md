# Protocolo de piloto (DESIGNED)
**Pré-requisitos (bloqueantes):** gates G1–G11 atendidos; revisor independente; DPO decidiu base legal, retenção e papéis (controlador/operador); contrato de piloto; ambiente de produção isolado; backup/restore testado.
**Dados:** apenas o mínimo necessário; sem texto clínico; migração de histórico opcional e anonimizada.
**Medição (baseline antes):** tempo médio por conferência; % itens conciliados com evidência; valor em aberto identificado vs. **recebido** após ação; duplicações impedidas; erros críticos de vínculo (meta: zero).
**Duração/amostra:** UNKNOWN (definir com o parceiro e estatístico; mínimo para detectar efeito).
**Critérios de parada:** incidente de privacidade; erro crítico de vínculo; divergência de totais não explicada.
**Encerramento:** relatório com limitações; decisão go/no-go; destruição/retorno de dados conforme contrato.
