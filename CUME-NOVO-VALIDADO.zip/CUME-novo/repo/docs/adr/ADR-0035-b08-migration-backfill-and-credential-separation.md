# ADR-0035 — migration/backfill and credential separation
Status: CANDIDATE / MATERIALIZED / NOT_EXECUTED_POSTGRES

## Decision
CUME schema migration credentials are distinct from runtime credentials. Runtime credentials must not own schemas, create/alter/drop objects, or run migrations.

For legacy rows before migration 0007, approval-required columns are not populated by invented approvals. The migration must stage affected rows, create review work items, and block promotion until each row has an attributable approval or an explicit migration disposition approved by an accountable operator. For 0008 rule/contract/pricing rows, version/effectivity/content hashes are backfilled from source evidence; if source evidence is insufficient, the row is classified UNKNOWN/NEEDS_REVIEW rather than synthesized. For 0014 audit chains, historical events are anchored as a separately identified migrated segment with a migration receipt; the chain must never imply that pre-migration events were natively hash-chained at occurrence time.

`btree_gist`/EXCLUDE is preferred where the target PostgreSQL extension is approved and executable; otherwise the existing trigger/advisory-lock candidate remains. This host cannot execute either PostgreSQL path.
