# Governança
Fontes canônicas ficam em `repo/governance/` (findings_registry_v0_5.json, gates_G0_G12_v0_5.yaml, backlog_v0_5.yaml) e `repo/docs/adr/` (ADR-0013 aceito no ciclo 1; 0014–0022 PROPOSED). Aqui: `epistemic_status_ledger.yaml` (estado de cada artefato) e `traceability_matrix.csv` (finding→requisito→invariante→teste). Todos os 13 gates seguem BLOCKED.
## Isolamento do projeto
`REQ-ISO-001 / I-25` é normativo: CUME não compartilha recursos, credenciais, runtime, arquitetura operacional ou dependências obrigatórias com outro produto. Fonte canônica: `repo/governance/project_isolation_policy_v1.json`; decisão: `repo/docs/adr/ADR-0023-hard-project-isolation.md`; regressão: `repo/tests/test_18_project_isolation.py`.
## Integridade do harness de QA
`REQ-QA-001 / I-26` é normativo: ausência de artefato ou dependência obrigatória do harness deve produzir falha explícita e não pode ser convertida em PASS vazio/skip silencioso. A imagem de testes deve materializar o mesmo layout de fontes exigido pelas suítes. Regressão: `repo/tests/test_19_qa_harness_contract.py`; findings: `CUME-QA-01/02`; backlog: `B-30`.

## B-01 application/IAM reference boundary
`REQ-IAM-001 / I-09 / I-18` now has local reference evidence in `test_24` and `test_25`, with explicit classification in `test_26`. This is `OBSERVED_REFERENCE_ONLY`, not real OIDC or production authorization. G7 remains BLOCKED.
