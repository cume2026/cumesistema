-- CUME 0004 — INV: soma(payment_allocation) <= payment.remitted_amount (candidate, dados sintéticos)
-- Serializa por pagamento via FOR UPDATE; correções devem usar financial_adjustment/reversal, não UPDATE.
BEGIN;
CREATE FUNCTION check_allocation_cap() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE cap numeric; used numeric; pid uuid;
BEGIN
  IF TG_TABLE_NAME='payment' THEN pid:=NEW.payment_id; ELSE pid:=NEW.payment_id; END IF;
  SELECT remitted_amount INTO cap FROM payment WHERE payment_id=pid FOR UPDATE;
  SELECT COALESCE(SUM(allocated_amount),0) INTO used FROM payment_allocation WHERE payment_id=pid;
  IF used > cap THEN
    RAISE EXCEPTION 'allocation cap exceeded: payment % allocated % > remitted %', pid, used, cap USING ERRCODE='check_violation';
  END IF;
  RETURN NULL;
END $$;
CREATE CONSTRAINT TRIGGER payment_allocation_cap AFTER INSERT OR UPDATE ON payment_allocation
  DEFERRABLE INITIALLY IMMEDIATE FOR EACH ROW EXECUTE FUNCTION check_allocation_cap();
CREATE CONSTRAINT TRIGGER payment_remitted_cap AFTER UPDATE OF remitted_amount ON payment
  DEFERRABLE INITIALLY IMMEDIATE FOR EACH ROW EXECUTE FUNCTION check_allocation_cap();
COMMIT;
