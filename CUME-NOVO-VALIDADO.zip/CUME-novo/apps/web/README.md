# CUME web reference

Classification: **MATERIALIZED / EXECUTED_LOCAL / OBSERVED_LOCAL / NOT_PRODUCTION**.

Build with `python build_frontend.py`; type-check with `npm run typecheck`. The generated `dist/index.html` is self-contained and uses synthetic/local reference view models only. It must not be treated as a real API-connected application.
