-- CUME 0013 — Clinical document lifecycle, authenticated authorship and server-recorded time.
-- Classification: MATERIALIZED DDL CANDIDATE; NOT EXECUTED against PostgreSQL in this cycle.
-- Project scope: CUME_ONLY.
-- B-05 / REQ-CLIN-DOC-001 / REQ-TIME-001 / REQ-IAM-001 / I-17 / I-20.
-- IMPORTANT: server_recorded_at is database-server time. It is NOT an RFC3161 timestamp authority
-- and this migration does NOT implement or validate a cryptographic/digital signature.
BEGIN;

ALTER TABLE clinical.clinical_document
  ADD COLUMN practice_organization_id uuid;
ALTER TABLE clinical.clinical_document
  ADD CONSTRAINT clinical_document_practice_same_tenant_fk
  FOREIGN KEY (tenant_id, practice_organization_id)
  REFERENCES public.organization(tenant_id, organization_id);

ALTER TABLE clinical.document_version
  ADD COLUMN author_user_id uuid;
ALTER TABLE clinical.document_version
  ADD CONSTRAINT document_version_author_user_same_tenant_fk
  FOREIGN KEY (tenant_id, author_user_id)
  REFERENCES public.user_account(tenant_id, user_id);

-- A client must never supply this evidentiary timestamp. The trigger below sets it.
ALTER TABLE clinical.document_version
  ALTER COLUMN server_recorded_at DROP DEFAULT;

-- The clinical runtime needs narrowly scoped IAM facts to derive authorship and validate
-- the PHYSICIAN role for the document's practice. RLS remains tenant-scoped.
GRANT SELECT (tenant_id, user_id, practitioner_id, status)
  ON public.user_account TO cume_clinical;
GRANT SELECT (tenant_id, user_id, role, organization_id, revoked_at)
  ON public.role_assignment TO cume_clinical;
GRANT SELECT (tenant_id, organization_id)
  ON public.organization TO cume_clinical;
GRANT SELECT ON public.state_transition_rule TO cume_clinical;

CREATE POLICY user_account_clinical_service ON public.user_account
  FOR SELECT TO cume_clinical
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);
CREATE POLICY role_assignment_clinical_service ON public.role_assignment
  FOR SELECT TO cume_clinical
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);
CREATE POLICY organization_clinical_service ON public.organization
  FOR SELECT TO cume_clinical
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);

CREATE OR REPLACE FUNCTION clinical.enforce_document_version_context()
RETURNS trigger
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = pg_catalog, public, clinical
AS $$
DECLARE
  v_user uuid;
  v_practitioner uuid;
  v_current_status text;
  v_practice uuid;
  v_previous_version_id uuid;
  v_previous_version_number integer;
  v_has_physician_role boolean;
BEGIN
  -- server_recorded_at has no default after 0013; any non-null input is client-supplied.
  IF NEW.server_recorded_at IS NOT NULL THEN
    RAISE EXCEPTION 'client supplied server_recorded_at is forbidden';
  END IF;

  v_user := NULLIF(current_setting('app.user_id', true),'')::uuid;
  IF v_user IS NULL THEN
    RAISE EXCEPTION 'app.user_id is required for clinical document authorship';
  END IF;

  SELECT ua.practitioner_id
    INTO v_practitioner
  FROM public.user_account ua
  WHERE ua.tenant_id = NEW.tenant_id
    AND ua.user_id = v_user
    AND ua.status = 'ACTIVE';
  IF NOT FOUND THEN
    RAISE EXCEPTION 'authenticated active CUME user is required';
  END IF;

  IF NEW.author_user_id IS NOT NULL AND NEW.author_user_id <> v_user THEN
    RAISE EXCEPTION 'author_user_id must be derived from app.user_id';
  END IF;
  IF NEW.author_practitioner_id IS NOT NULL
     AND NEW.author_practitioner_id IS DISTINCT FROM v_practitioner THEN
    RAISE EXCEPTION 'author_practitioner_id must be derived from user_account';
  END IF;
  NEW.author_user_id := v_user;
  NEW.author_practitioner_id := v_practitioner;
  NEW.server_recorded_at := clock_timestamp();

  SELECT d.current_status, d.practice_organization_id
    INTO v_current_status, v_practice
  FROM clinical.clinical_document d
  WHERE d.tenant_id = NEW.tenant_id
    AND d.document_id = NEW.document_id
  FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'clinical document not found';
  END IF;

  SELECT dv.document_version_id, dv.version_number
    INTO v_previous_version_id, v_previous_version_number
  FROM clinical.document_version dv
  WHERE dv.tenant_id = NEW.tenant_id
    AND dv.document_id = NEW.document_id
  ORDER BY dv.version_number DESC
  LIMIT 1;

  IF v_previous_version_id IS NULL THEN
    IF NEW.version_number <> 1 OR NEW.status <> 'DRAFT' OR NEW.supersedes_version_id IS NOT NULL THEN
      RAISE EXCEPTION 'first document version must be DRAFT version 1 without supersedes';
    END IF;
    RETURN NEW;
  END IF;

  IF NEW.version_number <> v_previous_version_number + 1 THEN
    RAISE EXCEPTION 'document version number must increment by one';
  END IF;
  IF NEW.supersedes_version_id IS DISTINCT FROM v_previous_version_id THEN
    RAISE EXCEPTION 'post-final version must supersede prior version';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM public.state_transition_rule r
    WHERE r.table_name = 'clinical_document'
      AND r.state_column = 'current_status'
      AND r.from_state = v_current_status
      AND r.to_state = NEW.status
  ) THEN
    RAISE EXCEPTION 'invalid clinical document transition % -> %', v_current_status, NEW.status;
  END IF;

  IF NEW.status = 'SIGNED' THEN
    IF v_practitioner IS NULL THEN
      RAISE EXCEPTION 'SIGNED requires practitioner identity';
    END IF;
    IF v_practice IS NULL THEN
      RAISE EXCEPTION 'SIGNED requires practice_organization_id';
    END IF;
    SELECT EXISTS (
      SELECT 1
      FROM public.role_assignment ra
      WHERE ra.tenant_id = NEW.tenant_id
        AND ra.user_id = v_user
        AND ra.role = 'PHYSICIAN'
        AND ra.organization_id = v_practice
        AND ra.revoked_at IS NULL
    ) INTO v_has_physician_role;
    IF NOT v_has_physician_role THEN
      RAISE EXCEPTION 'SIGNED requires active PHYSICIAN role linked to document practice';
    END IF;
  END IF;

  -- This update is itself checked by the canonical state-machine trigger from 0009.
  UPDATE clinical.clinical_document
     SET current_status = NEW.status
   WHERE tenant_id = NEW.tenant_id
     AND document_id = NEW.document_id;
  RETURN NEW;
END $$;

CREATE TRIGGER document_version_authorship_lifecycle
  BEFORE INSERT ON clinical.document_version
  FOR EACH ROW EXECUTE FUNCTION clinical.enforce_document_version_context();

COMMIT;
