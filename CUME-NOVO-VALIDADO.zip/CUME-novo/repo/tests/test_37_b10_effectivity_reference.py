#!/usr/bin/env python3
import pathlib,sys
from dataclasses import dataclass
from datetime import datetime, timezone
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'domain_ref'))
from effectivity import EffectivityError, VersionWindow, select_effective, pricing_reference_at
checks=[]
def ck(label,cond): checks.append((label,bool(cond))); print((' ✔ ' if cond else ' ✘ FALHA ')+label)
def blocked(fn):
    try: fn(); return False
    except EffectivityError: return True

def dt(s): return datetime.fromisoformat(s.replace('Z','+00:00'))
windows=[
 VersionWindow('v1','K',dt('2026-01-01T00:00:00Z'),dt('2026-07-01T00:00:00Z')),
 VersionWindow('v2','K',dt('2026-07-01T00:00:00Z'),None),
]
ck('início inclusivo seleciona v1',select_effective(windows,dt('2026-01-01T00:00:00Z')).version_id=='v1')
ck('fim exclusivo seleciona v2',select_effective(windows,dt('2026-07-01T00:00:00Z')).version_id=='v2')
ck('data antiga sem versão é barrada',blocked(lambda:select_effective(windows,dt('2025-12-31T23:59:59Z'))))
overlap=windows+[VersionWindow('vx','K',dt('2026-06-01T00:00:00Z'),None)]
ck('sobreposição é barrada',blocked(lambda:select_effective(overlap,dt('2026-06-15T00:00:00Z'))))
performed=dt('2026-09-03T13:15:22Z')
ck('reference_at deriva do performed_at',pricing_reference_at(performed)==performed)
ck('caller não pode escolher reference_at divergente',blocked(lambda:pricing_reference_at(performed,dt('2026-09-04T13:15:22Z'))))
ck('caller pode repetir o mesmo instante',pricing_reference_at(performed,performed)==performed)
ck('datetime ingênuo é barrado',blocked(lambda:pricing_reference_at(datetime(2026,9,3,13,15,22))))
old=select_effective(windows,dt('2026-03-01T00:00:00Z')).version_id
new_windows=windows+[VersionWindow('v3','K2',dt('2026-10-01T00:00:00Z'),None)]
ck('adição futura não muda seleção histórica',select_effective(new_windows[:2],dt('2026-03-01T00:00:00Z')).version_id==old)
bad=[x for x in checks if not x[1]]
print(f'== 37 B-10 effectivity/reference_at: {len(checks)-len(bad)} ok, {len(bad)} falha(s)')
sys.exit(1 if bad else 0)
