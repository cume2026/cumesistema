from fixtures import *
r=Report('04 RLS + separação de roles (cume_app / cume_auditor)')
uri=fresh('t4');s=S(uri);tA,tB=u(),u();FA=build(s,tA);FB=build(s,tB)
def app(ctx,sql,role='cume_app',t=False):
    pre=f"set role {role};"+(f"select set_config('app.tenant_id','{ctx}',false);" if ctx else "")
    return sh(uri,pre+sql,t=t)
def cnt(ctx,sql,role='cume_app'):
    rc,o=app(ctx,sql,role,t=True); return o.strip().splitlines()[-1] if rc==0 and o.strip() else f'rc={rc}'
r.check('controle: owner (superuser) enxerga 2 payments',q(uri,"select count(*) from payment")[0]=='2')
r.check('app SEM contexto de tenant enxerga 0 payments (fail-closed)',cnt(None,"select count(*) from payment")=='0')
r.check('app ctx A enxerga 1 payment e 1 tenant',(cnt(tA,"select count(*) from payment"),cnt(tA,"select count(*) from tenant"))==('1','1'))
r.check('app ctx A não enxerga payment do tenant B',cnt(tA,f"select count(*) from payment where tenant_id='{tB}'")=='0')
r.expect('INSERT paciente tenant B com ctx A',app(tA,f"insert into patient_identity(patient_id,tenant_id,display_name) values('{u()}','{tB}','x')"),'fail','row-level security')
r.expect('INSERT paciente tenant A com ctx A (controle +)',app(tA,f"insert into patient_identity(patient_id,tenant_id,display_name) values('{u()}','{tA}','x')"),'ok')
rc,o=app(tB,f"update payment set remitted_amount=1 where tenant_id='{tA}' returning payment_id",t=True)
lines=[l for l in o.strip().splitlines() if l!=tB] if rc==0 else ['ERRO']
r.check('UPDATE cross-tenant afeta 0 linhas (eco do set_config excluído)',len(lines)==0,lines)
r.check('estado real do payment de A intacto (lido pelo owner)',q(uri,f"select remitted_amount from payment where tenant_id='{tA}'")[0]=='100.00')
r.expect('DELETE payment (sem privilégio)',app(tA,"delete from payment"),'fail','permission denied')
r.expect('TRUNCATE audit_event',app(tA,"truncate audit_event"),'fail','permission denied')
r.expect('UPDATE audit_event (sem privilégio)',app(tA,"update audit_event set action='x'"),'fail','permission denied')
r.expect('DISABLE TRIGGER (não é owner)',app(tA,"alter table audit_event disable trigger all"),'fail','must be owner')
r.expect('DROP TABLE (não é owner)',app(tA,"drop table payment"),'fail','must be owner')
r.expect('INSERT audit_event com ator real (controle +)',app(tA,f"insert into audit_event(audit_event_id,tenant_id,actor_id,action,aggregate_type,aggregate_id,correlation_id,occurred_at) values('{u()}','{tA}','{FA['admin']}','x','t','{u()}','c',now())"),'ok')
r.expect('cume_auditor não escreve',app(tA,f"insert into patient_identity(patient_id,tenant_id,display_name) values('{u()}','{tA}','x')",'cume_auditor'),'fail','permission denied')
r.check('cume_auditor lê (ctx A) 1 payment',cnt(tA,"select count(*) from payment",'cume_auditor')=='1')
pay=s.ids[('payment',tA)]
al=lambda a:app(tA,f"insert into payment_allocation(allocation_id,tenant_id,payment_id,claim_item_id,production_item_id,allocated_amount,allocated_at) values('{u()}','{tA}','{pay}','{s.ids[('claim_item',tA)]}','{s.ids[('production_item',tA)]}',{a},now())")
r.expect('teto sob RLS: alocar 60 (controle +)',al(60),'ok'); r.expect('teto sob RLS: +60 => 120>100',al(60),'fail','allocation cap exceeded')
r.done()
