from dataclasses import dataclass
from decimal import Decimal
@dataclass(frozen=True)
class Settlement: settlement_id:str; tenant_id:str; currency:str; amount:Decimal
@dataclass(frozen=True)
class PhysicianShare: practitioner_id:str; amount:Decimal
@dataclass(frozen=True)
class PhysicianSettlement: settlement_id:str; practitioner_id:str; amount:Decimal
def allocate_physician_settlement(s, shares):
 if s.amount < 0 or any(x.amount < 0 for x in shares): raise ValueError('NEGATIVE_AMOUNT')
 if sum((x.amount for x in shares),Decimal('0')) > s.amount: raise ValueError('OVER_ALLOCATION')
 return tuple(PhysicianSettlement(s.settlement_id,x.practitioner_id,x.amount) for x in shares)
