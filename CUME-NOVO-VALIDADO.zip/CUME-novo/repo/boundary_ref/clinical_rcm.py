"""CUME Clinical→RCM minimization boundary reference contract.

Classification:
  project_scope: CUME_ONLY
  epistemic_state: MATERIALIZED
  lifecycle_status: CANDIDATE_REFERENCE_ONLY
  physical_postgres_boundary: BLOCKED
  independent_verification: UNVERIFIED

This module is deliberately pure and has no I/O. It defines the minimum payload
that may cross from Clinical into Revenue Cycle and makes financial materialization
an explicit, separate operation.
"""
from __future__ import annotations
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
import uuid

class BoundaryError(ValueError):
    pass

MINIMIZED_EVENT_FIELDS=(
    'event_type','event_version','tenant_id','encounter_id','performed_item_id',
    'code_system','code','quantity','performed_at','participants'
)

def _uuid(value, field):
    try:
        return str(uuid.UUID(str(value)))
    except Exception as exc:
        raise BoundaryError(f'invalid {field}') from exc

def _quantity(value):
    try:
        q=Decimal(str(value))
    except (InvalidOperation, ValueError) as exc:
        raise BoundaryError('invalid quantity') from exc
    if not q.is_finite() or q <= 0:
        raise BoundaryError('quantity must be finite and > 0')
    return format(q.quantize(Decimal('0.001')),'f')

def _time(value):
    if not isinstance(value,datetime) or value.tzinfo is None or value.utcoffset() is None:
        raise BoundaryError('performed_at must be timezone-aware datetime')
    return value.astimezone(timezone.utc).isoformat().replace('+00:00','Z')

def _participants(items):
    if not isinstance(items,(list,tuple)):
        raise BoundaryError('participants must be a list')
    out=[]
    for item in items:
        if not isinstance(item,dict) or set(item)!={'practitioner_id','function_code'}:
            raise BoundaryError('participant must contain only practitioner_id/function_code')
        fn=item['function_code']
        if not isinstance(fn,str) or not fn.strip():
            raise BoundaryError('invalid function_code')
        out.append({'practitioner_id':_uuid(item['practitioner_id'],'practitioner_id'),'function_code':fn.strip()})
    return out

def build_performed_item_event(*, tenant_id, encounter_id, performed_item_id, code_system, code, quantity, performed_at, participants):
    if not isinstance(code_system,str) or not code_system.strip():
        raise BoundaryError('code_system required')
    if not isinstance(code,str) or not code.strip():
        raise BoundaryError('code required')
    event={
        'event_type':'PERFORMED_ITEM_RECORDED',
        'event_version':'1',
        'tenant_id':_uuid(tenant_id,'tenant_id'),
        'encounter_id':_uuid(encounter_id,'encounter_id'),
        'performed_item_id':_uuid(performed_item_id,'performed_item_id'),
        'code_system':code_system.strip(),
        'code':code.strip(),
        'quantity':_quantity(quantity),
        'performed_at':_time(performed_at),
        'participants':_participants(participants),
    }
    if tuple(event.keys()) != MINIMIZED_EVENT_FIELDS:
        raise AssertionError('boundary allowlist drift')
    return event

def complete_encounter(performed_item_event: dict):
    if not isinstance(performed_item_event,dict) or set(performed_item_event)!=set(MINIMIZED_EVENT_FIELDS):
        raise BoundaryError('invalid minimized event')
    return {
        'encounter_status':'COMPLETED',
        'rcm_events':[dict(performed_item_event)],
        'production_item':None,
    }

def materialize_production_item(performed_item_event: dict, pricing_snapshot: dict):
    if not isinstance(performed_item_event,dict) or set(performed_item_event)!=set(MINIMIZED_EVENT_FIELDS):
        raise BoundaryError('invalid minimized event')
    if not isinstance(pricing_snapshot,dict):
        raise BoundaryError('pricing_snapshot required')
    status=pricing_snapshot.get('price_status')
    if status not in {'PRICED','CONTRACTUAL_ZERO'}:
        raise BoundaryError('pricing snapshot must be PRICED or CONTRACTUAL_ZERO')
    snapshot_id=_uuid(pricing_snapshot.get('pricing_snapshot_id'),'pricing_snapshot_id')
    seed='|'.join((performed_item_event['tenant_id'],performed_item_event['performed_item_id'],snapshot_id))
    production_id=str(uuid.uuid5(uuid.NAMESPACE_URL,'cume:production:'+seed))
    return {
        'production_item_id':production_id,
        'tenant_id':performed_item_event['tenant_id'],
        'performed_item_id':performed_item_event['performed_item_id'],
        'pricing_snapshot_id':snapshot_id,
    }
