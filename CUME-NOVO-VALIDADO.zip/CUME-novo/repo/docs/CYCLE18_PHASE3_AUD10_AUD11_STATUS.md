# CUME — Cycle 18 Phase 3/4: AUD-10 / AUD-11

**State:** `CI_REPRODUCIBILITY_MATERIALIZED_AND_DATA_INVENTORY_TECHNICALLY_COMPLETE_WITH_EXTERNAL_EXECUTION_REVIEW_PENDING`

## AUD-10 — CI/dependency reproducibility
- Added `repo/requirements-ci.lock` with exact direct pins and provenance.
- CI is self-contained around embedded `pgserver`; it no longer depends on provider PostgreSQL secrets for the regression suite.
- CI pins Python 3.12.3, installs Chromium explicitly, runs `pip check`, verifies installed versions against the lock, checks generated blueprint/data-inventory drift, runs all tests, runs mutation checks, and uploads logs even on failure.
- `Dockerfile.tests` consumes the same lock and Python 3.12.3 candidate base.
- Current-host observation: PyYAML/jsonschema/rdflib/playwright match; hypothesis/pgserver/openapi-spec-validator are absent. Full CI and Docker build remain NOT_EXECUTED in this host.
- Exact direct pins are not a vendored/hash-complete transitive supply-chain lock.

Classification: `MATERIALIZED_STATIC_OBSERVED_CI_RUN_EXTERNAL_PENDING`.

## AUD-11 — data inventory
- Inventory remains migration-derived and fail-closed through `generate_data_inventory_from_migrations.py --check`.
- Technical classification coverage: 370/370 columns; `UNCLASSIFIED=0`; sensitivity risk `unknown=0`.
- Former undefined columns are now technically classified: `document_version.version_number`, `role_assignment.granted_by`, `source_document.sha256`.
- This is technical coverage only. DPO review: 0/370; legal basis and retention are still NOT_ADJUDICATED.

Classification: `TECHNICAL_CLASSIFICATION_100_PERCENT_DPO_REVIEW_BLOCKED`.

## Verification
- test_73: 17/17 PASS after observed RED (11 initial failures).
- Mutants: unpinned Hypothesis, inventory check removed from CI, UNCLASSIFIED reintroduced = 3/3 detected.
- No G0–G12 gate promoted.
