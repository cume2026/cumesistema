# SUPERSEDED_NON_OPERATIONAL — historical comparison only

> Superseded by ADR-0023 / CUME-ISO-001 on 2026-10-02. This file is retained only for provenance and MUST NOT be used as architecture, dependency, requirement, or runtime guidance for CUME.

# HUMAN-OMEGA × CUME — como se relacionam (para o outro modelo não confundir)
- **HUMAN-OMEGA é uma camada de GOVERNANÇA EPISTÊMICA para interações com modelos de linguagem** (status honesto, NCNS, rótulos Semmelweis, abstenção, TrustPath). **Não é parte do runtime do CUME.**
- O que o CUME **herda**: a escada de estados (REQUESTED…SETTLED), "sem self-attestation", separação de metas × medidas, rótulos FATO/INTERPRETAÇÃO/HIPÓTESE, gates com critérios objetivos.
- Elementos do bootstrap HUMAN-OMEGA (taxonomias SOF/HEXA/FALX, Graph-RAG, Neo4j, Qdrant, RAGAS, OPA…) são **arquitetura-alvo do KOS**, não requisitos do produto CUME. Aqui só entram se justificados por caso de uso (ver `ai_decision_matrix.yaml`: Graph-RAG = REJECT; embeddings/vetor/rerank = DEFER).
- Se um **copiloto do CUME** (AI-12) vier a existir, a camada HUMAN-OMEGA serve para governar *o prompt/comportamento do assistente* (guardrails, abstenção, citações), separada da lógica de negócio.
