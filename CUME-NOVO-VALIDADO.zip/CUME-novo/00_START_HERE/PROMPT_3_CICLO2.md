Papel: ENGENHEIRO. Execute SOMENTE o item B-21 de repo/governance/backlog_v0_5.yaml (tabelas de conteúdo de regra/contrato, finding CUME-DB-13).
Restrições: nova migração 0011 (não edite 0001–0010); diff mínimo; não altere testes existentes para passar; adicione testes novos (incluindo: recomputar o snapshot a partir do conteúdo no banco reproduz o hash; domain_ref/pricing_hash.py continua com paridade).
Antes de declarar pronto: rode `python3 repo/tests/run_all.py` e `bash repo/scripts/mutation_check.sh`; acrescente ao menos 1 mutante novo que o seu teste detecte.
Entregue: diff, saída completa dos comandos, e lista do que NÃO foi verificado. Estado máximo permitido: EXECUTED/OBSERVED. Não escreva "aprovado" nem "pronto para produção".
