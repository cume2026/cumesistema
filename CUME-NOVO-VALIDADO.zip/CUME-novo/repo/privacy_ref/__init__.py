"""CUME privacy reference contracts. Reference-only; not legal advice or runtime enforcement."""
