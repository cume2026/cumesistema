# ADR-0022 — Versionamento de terminologias e crosswalk

**Project scope:** `CUME_ONLY`  
**Decision state:** `SPECIFIED → MATERIALIZED`; reference behavior `EXECUTED → OBSERVED`; official binary ingestion/XSD validation `BLOCKED`.

## Decision

1. TISS is never represented by one global version string. Each of its five components is versioned independently with source, retrieval time, effective interval, hash and validation state.
2. TUSS codes resolve by `(code system, code, service date)`. Historical billing uses the code/version valid on the service date, not the latest release.
3. SIGTAP is stored by monthly competence; a current competence is never guessed.
4. `terminology_code` is append-only and belongs to an explicit `terminology_version`.
5. TUSS↔SIGTAP is an explicitly versioned N:N crosswalk. `EXACT` requires human review and provenance; 1:1 equivalence is never inferred.
6. XML validation requires official XSD bytes plus a registered SHA-256. The validator mechanism may be tested with synthetic schemas, but this cannot promote official TISS validation.

## Official-source observation — 2026-10-02

The ANS September/2026 page identifies the component versions as Organizational 202609, Content/Structure 202511, Representation/TUSS 202609, Security/Privacy 202511, and Communication 04.03.00 plus 01.06.00. The ANS also documents TUSS access through OCL and machine-readable formats. Ministry of Health SIGTAP documentation confirms monthly competence versioning.

## Current boundary

Official pages are observed. The current execution environment did not provide the official ZIP/XSD bytes, so their cryptographic hashes and real XML validation remain `BLOCKED/UNVERIFIED`. No code from the legacy prototype is treated as a validated TUSS or SIGTAP code.
