from fixtures import *
r=Report('03 append-only: audit_event / document_version')
uri=fresh('t3');s=S(uri);tA=u();F=build(s,tA)
aud=u()
r.expect('audit com ator real (controle +)',sh(uri,f"insert into audit_event(audit_event_id,tenant_id,actor_id,action,aggregate_type,aggregate_id,correlation_id,occurred_at) values('{aud}','{tA}','{F['admin']}','x','t','{u()}','c',now())"),'ok')
r.expect('audit com ator inexistente',sh(uri,f"insert into audit_event(audit_event_id,tenant_id,actor_id,action,aggregate_type,aggregate_id,correlation_id,occurred_at) values('{u()}','{tA}','{u()}','x','t','{u()}','c',now())"),'fail','audit_event_actor_fk')
r.expect('UPDATE audit_event',sh(uri,f"update audit_event set action='ADULTERADO' where audit_event_id='{aud}'"),'fail','append-only')
r.expect('DELETE audit_event',sh(uri,f"delete from audit_event where audit_event_id='{aud}'"),'fail','append-only')
rc,e,_=s.ins('clinical.clinical_document',tA); r.check('clinical_document criado',rc==0,e)
doc=s.ids[('clinical.clinical_document',tA)]; dv=u()
context=f"select set_config('app.user_id','{F['admin']}',false);"
insert=f"insert into clinical.document_version(document_version_id,tenant_id,document_id,version_number,status,body_sha256) values('{dv}','{tA}','{doc}',1,'DRAFT','{'a'*64}')"
rc,e=sh(uri,context+insert); r.check('document_version criado com autoria autenticada e horário do servidor',rc==0,e)
r.check('autoria e horário derivados pelo servidor',q(uri,f"select author_user_id='{F['admin']}'::uuid and server_recorded_at is not null from clinical.document_version where document_version_id='{dv}'")==['t'])
r.expect('horário evidenciário fornecido pelo cliente é barrado',sh(uri,context+f"insert into clinical.document_version(document_version_id,tenant_id,document_id,version_number,status,server_recorded_at) values('{u()}','{tA}','{doc}',2,'FINAL',now())"),'fail','client supplied server_recorded_at')
r.expect('UPDATE document_version',sh(uri,f"update clinical.document_version set body_sha256='{'0'*64}' where document_version_id='{dv}'"),'fail','append-only')
r.expect('DELETE document_version',sh(uri,f"delete from clinical.document_version where document_version_id='{dv}'"),'fail','append-only')
r.check('versão original permanece íntegra após tentativas de mutação',q(uri,f"select body_sha256 from clinical.document_version where document_version_id='{dv}'")==['a'*64])
r.done()
