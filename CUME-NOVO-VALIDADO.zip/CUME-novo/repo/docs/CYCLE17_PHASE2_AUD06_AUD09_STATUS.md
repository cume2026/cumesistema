# CUME — Cycle 17 Phase 2/4: AUD-06 / AUD-08 / AUD-09

**State:** `STRUCTURAL_RECONCILIATION_OBSERVED_WITH_EXTERNAL_TRUST_AND_POSTGRES_CAVEATS`

## AUD-06 — blueprint/current-state drift
`gen_blueprint_views.py` now has a real fail-closed `--check` mode and derives the current schema catalog from migrations 0001–0021. It generates/checks `generated_catalog.yaml`, `erd.mmd`, `cume.ttl`, state-machine Mermaid, and the current `MASTER_INDEX.md`. The taxonomy maps every DDL-derived public/clinical/rcm base table exactly once in the static model.

Classification: `LOCAL_STATIC_OBSERVED_LIVE_CATALOG_PENDING`. A live PostgreSQL catalog comparison after the Phase-1 patch is still pending because this host lacks pgserver/system PostgreSQL.

## AUD-08 — manifest lineage
All prior manifests were moved out of the package root into `lineage/manifests/`, with an explicit explanation that historical divergence is expected. Phase 2 enforces at most one current root manifest. The final ZIP is accompanied by a detached signature/public key outside the ZIP using a locally generated ephemeral signing identity.

Classification: `LOCAL_LINEAGE_REPAIRED_EXTERNAL_TRUST_PENDING`. Cryptographic verification of that local detached signature does not establish an independently trusted production identity.

## AUD-09 — hygiene
Hypothesis execution cache was removed and excluded; historical test-numbering anomalies are explicitly documented without breaking evidence links; skipped ADR identifiers 0030/0033/0034 are explicitly RESERVED rather than silently reused.

Classification: `LOCAL_HYGIENE_OBSERVED`.

## Verification
- `test_72`: PASS after observed RED.
- Mutants detected: stale MASTER_INDEX, historical root manifest, Hypothesis cache reintroduction = 3/3.
- Non-PostgreSQL regression: 57/57 PASS, 0 FAIL, 0 TIMEOUT (executed in chunks to respect host command timeout).
- DB/Hypothesis suites remain `NOT_EXECUTED_CURRENT_HOST_DEPENDENCY`; representative attempts fail with missing `pgserver`/`hypothesis`.
- No G0–G12 gate promoted.
