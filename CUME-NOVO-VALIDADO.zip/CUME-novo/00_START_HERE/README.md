# CUME — current package entry point (Phase 2/4 audit repair, 2026-10-02)

**Current state:** previous `LOCAL_SPINE_COMPLETE` closure is `SUPERSEDED/REOPENED` after the Claude audit. Phase 1/4 materialized AUD-01…AUD-05 repairs; PostgreSQL rerun remains pending in this host. Phase 2/4 reconciles AUD-06/AUD-08/AUD-09.

## Read first
1. `MASTER_INDEX.md` — generated current-state index.
2. `PHASE1_OF4_STATUS.md` — Phase 1 runtime limitation and repair status.
3. `repo/docs/CYCLE16_PHASE1_AUD01_AUD05_STATUS.md` — detailed Phase 1 receipt/status.
4. `lineage/manifests/README.md` — historical-manifest semantics.
5. `repo/tests/TEST_NUMBERING.md` — historical numbering anomalies and policy.

## Regenerate/check derived views
```bash
cd repo
python3 scripts/gen_blueprint_views.py
python3 scripts/gen_blueprint_views.py --check
```

## Test execution
```bash
cd repo
python3 tests/run_all.py
```
Database-dependent suites require PostgreSQL (`pgserver` or `CUME_PG_ADMIN_URI`). A missing dependency is not considered evidence that the database suites pass.

## Manifest rule
Historical manifests are under `lineage/manifests/`. At release freeze, exactly one current manifest is placed at package root. A same-package manifest proves internal consistency, not independent authenticity.

**No G0–G12 gate is promoted by this package.**
