# CUME — Classification and Surface State Model v1.0

**Project scope:** CUME_ONLY  
**Epistemic state:** MATERIALIZED  
**Verification state:** EXECUTED/OBSERVED locally by `tests/test_23_classification_contract.py`; independent review pending.

## 1. Non-equivalence principle

CUME uses two orthogonal axes and does not collapse them:

`REQUESTED → SPECIFIED → DESIGNED → MATERIALIZED → EXECUTED → OBSERVED → VERIFIED → SETTLED`

Side/terminal states: `BLOCKED`, `FAILED`, `ABSTAIN`, `SUPERSEDED`, `DEPRECATED`.

For work surfaces:

`AVAILABLE ≠ DOCUMENTED ≠ CONNECTED ≠ AUTHORIZED ≠ EXECUTABLE ≠ VERIFIED`.

Every dimension is declared independently. A visible connector is not automatically connected; a connected connector is not automatically authorized for a write; an executable operation is not automatically verified.

## 2. Mandatory classification

Every newly created CUME element—requirement, finding, invariant, ADR, schema, migration, table, API, service, job, pipeline, adapter, integration, dataset, test, receipt, UI surface, infrastructure resource or release artifact—must carry, directly or through its canonical registry entry:

- `project_scope=CUME_ONLY`;
- epistemic/materialization state;
- lifecycle status;
- evidence basis;
- explicit blockers where applicable.

Every integration/work surface additionally carries availability, documentation, connection, authorization, execution and verification states.

## 3. CUME independence

No HUMAN-OMEGA state, resource, credential, receipt, runtime, schema, database, repository or connector configuration can be reused as CUME evidence. Using the same vendor or technology is allowed only through CUME-dedicated resources.

## 4. Promotion discipline

No state is promoted by wording. `MATERIALIZED` requires an inspectable artifact/resource; `EXECUTED` requires an execution receipt; `OBSERVED` requires runtime/output observation; `VERIFIED` requires reproducible or independent verification against criteria; `SETTLED` requires the required adjudication/acceptance.
