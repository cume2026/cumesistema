# ADR-0017 — Política de resto de arredondamento

**Status:** CANDIDATE_POLICY — SPECIFIED + REFERENCE_EXECUTED/OBSERVED; finance/RCM approval BLOCKED; VERIFIED=NO; SETTLED=NO.

## Decisão candidata

Executar alocação proporcional com `Decimal` exato, truncar cada parte para a menor unidade monetária e distribuir os centavos residuais pelo método **largest remainder**. Empates usam a chave estável da participação em ordem lexical, tornando o resultado independente da ordem de entrada.

## Invariantes observados no reference engine

- `sum(parts) == total` exatamente;
- nenhum centavo é criado ou perdido;
- total e pesos negativos são rejeitados;
- float binário não é aceito;
- o mesmo conjunto de participantes produz o mesmo resultado independentemente da ordem de entrada.

## Limite epistemológico

A política é tecnicamente determinística, mas ainda **não é uma regra financeira/contratual aprovada**. Antes de virar política canônica de produção requer validação por responsável financeiro/RCM e casos contratuais reais. Até lá: `B23_FINANCE_SME_APPROVAL = BLOCKED`, `VERIFIED = NO`, `SETTLED = NO`.
