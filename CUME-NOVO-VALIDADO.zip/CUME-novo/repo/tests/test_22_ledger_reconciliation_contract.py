import sys
from pathlib import Path
from decimal import Decimal
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'domain_ref'))
from ledger import ingest_remittance, reconcile_payment, LedgerError
checks=0
def ok(cond,msg):
 global checks
 assert cond,msg; checks+=1
claims={'CI-1':Decimal('100.00'),'CI-2':Decimal('200.00')}
doc=b'REMESSA-SINTETICA-001'
rows=[{'external_id':'R1','claim_item_id':'CI-1','remitted_amount':'80.00'},
      {'external_id':'R2','claim_item_id':None,'remitted_amount':'20.00'}]
a=ingest_remittance(doc,rows,claims)
b=ingest_remittance(doc,rows,claims)
ok(a['source_sha256']==b['source_sha256'],'mesmo documento gera mesmo sha256')
ok(a['receipt_id']==b['receipt_id'],'reimport é idempotente/determinístico')
ok(a['items'][0]['match_status']=='MATCHED','claim conhecida é matched')
ok(a['items'][1]['match_status']=='UNMATCHED','sem match permanece visível')
ok(a['items'][1]['allocation'] is None,'unmatched nunca é alocado automaticamente')
ok(a['items'][0]['allocation']['allocated_amount']=='80.00','retorno parcial aloca somente valor recebido')
ok(a['items'][0]['outstanding_amount']=='20.00','outstanding derivado')
ok(a['summary']['matched_amount']=='80.00' and a['summary']['unmatched_amount']=='20.00','relatório separa matched/unmatched')
ok(a['summary']['settled_claim_items']==0,'retorno parcial não liquida item')
r=reconcile_payment('100.00',[{'allocated_amount':'80.00'}],adjustments=[{'amount':'10.00'}])
ok(r['unapplied_amount']=='10.00','allocated + adjustment + unapplied = payment')
try:
 reconcile_payment('100.00',[{'allocated_amount':'95.00'}],adjustments=[{'amount':'10.00'}])
 raise AssertionError('over-allocation deveria falhar')
except LedgerError: checks+=1
try:
 ingest_remittance(doc,[{'external_id':'R3','claim_item_id':'CI-1','remitted_amount':'-1.00'}],claims)
 raise AssertionError('negativo deveria falhar')
except LedgerError: checks+=1
print(f'== 22 ledger reconciliation contract: {checks} ok, 0 falha(s)')
