#!/usr/bin/env python3
import pathlib,json,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
checks=[]
def ck(label,cond): checks.append((label,bool(cond))); print((' ✔ ' if cond else ' ✘ FALHA ')+label)
mig=ROOT/'db/migrations/0015_critical_approval_enforcement.sql'; reg=ROOT/'governance/cycle8_b07_registry.json'
ck('migration 0015 existe',mig.exists()); ck('registry B-07 existe',reg.exists())
if mig.exists():
 s=mig.read_text().lower()
 ck('approval guard vira operation-aware',"new.operation='permission_change'" in s and "role='security_admin'" in s)
 ck('DENIAL_ACCEPT tem approval_id','acceptance_approval_id' in s)
 ck('DENIAL_ACCEPT exige APPROVED',"a.operation <> 'denial_accept'" in s and "a.status is distinct from 'approved'" in s)
 ck('role_assignment ganha approval_id','alter table role_assignment add column approval_id' in s)
 ck('role grant exige PERMISSION_CHANGE',"a.operation <> 'permission_change'" in s and "a.subject_type <> 'role_assignment'" in s)
 ck('SECURITY_ADMIN segregado de BILLING','security_admin must be segregated from billing roles' in s)
 ck('maker/checker distintos preservados','checker_id <> maker_id' in s or 'checker_id=maker_id' in s)
 ck('não inventa tabela physician_settlement','create table physician_settlement' not in s)
if reg.exists():
 r=json.loads(reg.read_text()); elems={e['id']:e for e in r['elements']}
 need={'B07_REFERENCE_APPROVAL','B07_DENIAL_DDL','B07_PERMISSION_DDL','B07_SECURITY_BILLING_SOD','B07_PHYSICIAN_SETTLEMENT_DDL'}
 ck('registry contém elementos mínimos',need<=set(elems))
 ck('reference executado/observado',elems['B07_REFERENCE_APPROVAL']['classification']['epistemic_state']=='OBSERVED')
 ck('DDL denial apenas materializado',elems['B07_DENIAL_DDL']['classification']['epistemic_state']=='MATERIALIZED')
 ck('physician settlement bloqueado por entidade ausente',elems['B07_PHYSICIAN_SETTLEMENT_DDL']['classification']['epistemic_state']=='BLOCKED')
bad=[x for x in checks if not x[1]]; print(f'== 35 B-07 DDL + classification static: {len(checks)-len(bad)} ok, {len(bad)} falha(s)'); sys.exit(1 if bad else 0)
