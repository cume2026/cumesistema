
> **TERMINAL RECONCILIATION — 2026-10-02:** this document began as an early-cycle handoff. Sections that describe missing B-01…B-18 capabilities are a **historical snapshot** unless a later cycle update or the terminal registry explicitly supersedes them. Current canonical local status is in `governance/terminal_local_spine_registry_v1.json` and `docs/FINAL_LOCAL_SPINE_STATUS.md`.

> **HARD INVARIANT CUME-ISO-001 (2026-10-02):** CUME é um projeto autônomo e independente. Nunca use banco, schema, projeto cloud, IAM, secrets, storage, fila, observabilidade, CI/CD, runtime, backup, DR ou dependência de código/runtime do HUMAN-OMEGA. Mesma tecnologia/provedor só é aceitável com recursos e credenciais próprios do CUME. ADR-0023; `tests/test_18_project_isolation.py`.

> **CICLO 2 / B-21 candidato (2026-10-02):** `0011_rule_contract_content.sql` + content addressing foram materializados; somente o teste unitário foi executado neste host. PostgreSQL/test_17 permanecem BLOCKED. `CUME-DB-13` segue OPEN; gates seguem BLOCKED. Ver `CYCLE2_B21_STATUS.md`.

> **ATUALIZAÇÃO v0.5 (2026-10-01) — leia primeiro.** Este documento nasceu na v0.4; o estado atual está em `../../00_START_HERE/README.md` e `../../blueprint/13_governance/epistemic_status_ledger.yaml`. Mudanças: migrações **0009** (máquinas de estado geradas de `spec/state_machines.yaml`) e **0010** (NaN em numeric, finding **CUME-DB-15**, P0); testes 09–15 (agora 15 suítes); `domain_ref/` (hash e motor de referência); `benchmarks/`; `evidence/prototype_v2_probe`; governança v0.5 (64 findings, 28 itens de backlog, ADRs 0014–0022 PROPOSED). **IDs:** `CUME-N01…N11` foram renomeados para `CUME-DB-01…DB-11` por colidirem com N01–N09 do ChatGPT. Onde este texto disser "31 tabelas", leia 33; "8 migrações", leia 10. Gates: todos BLOCKED.

# CUME — HANDOFF MASTER (v0.4) — leitura obrigatória antes de qualquer ação

> Escrito em 2026-10-01 pelo modelo que executou o "ciclo 1". Destinatário: outro modelo de IA (ex.: ChatGPT) + o humano dono do projeto (Arley).
> Regra de ouro: **tudo aqui está num estado epistêmico explícito. Não promova nada sem evidência reproduzível.**

## 0. Ordem de leitura e uso
1. Este arquivo inteiro. 2. `governance/backlog_v0_4.yaml` (o que fazer). 3. `governance/findings_registry_v0_4.json` e `governance/gates_G0_G12_v0_4.yaml`. 4. `db/migrations/*.sql` (fonte de verdade do banco). 5. `tests/` (executável; é a especificação viva). 6. `reference/` (artefatos herdados; **não** são verdade, são entrada).
Antes de escrever uma linha: rode `python3 tests/run_all.py` (§6). Se não conseguir rodar Postgres, **declare BLOCKED** e peça ao humano — não "simule" resultados.

## 1. O que é o CUME e em que estado está
Sistema de produção médica + faturamento/ciclo de receita (RCM: agenda, atendimento, produção, conferência, guias/lotes TISS, retorno, glosas, recursos, repasse) e, numa versão posterior do protótipo, módulo clínico (Meu Dia, prontuário, prescrições, pedidos de exames, relatórios).
- **Estado: `stage: PROTOTYPE`, `baseline: CANDIDATE`, `production_ready: false`, `pilot_ready: false`, decisão `NOT_READY`.**
- O que existe de "produto" é um **protótipo HTML** (`reference/CUME_Prototipo_Receitas_Exames_Relatorios.html`, 588 KB; sha256 `d3e97981…17a5`) sem backend, sem persistência, sem autenticação real, com efeitos externos simulados.
- O que existe de "engenharia real" é **só a camada de banco** (este pacote): 8 migrações PostgreSQL + 8 suítes de teste. **Não há API, worker, frontend novo, integração TISS/TUSS/SIGTAP, observabilidade, CI, deploy.**
- **Afirmações proibidas** (até haver evidência + revisor): production-ready, pilot-ready, prontuário/EHR validado, faturador TISS homologado, "LGPD compliant", financeiramente confiável, IAM real, ledger canônico verificado.

## 2. Disciplina epistêmica (vale para você, modelo, o tempo todo)
Classes de estado: `REQUESTED < SPECIFIED < DESIGNED < MATERIALIZED < EXECUTED < OBSERVED < VERIFIED < SETTLED` (+ `BLOCKED, FAILED, ABSTAIN, DEPRECATED, SUPERSEDED`). Nunca trate uma como a seguinte.
Ordem de força de evidência: resultado executado vivo > banco/runtime observados > teste automatizado com receipt > código aplicado > configuração > artefato estático > documento > relato > intenção.
**Nunca self-attestation.** Neste pacote, "VERIFIED (sandbox)" significa: *o próprio autor executou, 1 vez, em PostgreSQL 16.2 embutido, com dados sintéticos, sem revisão independente.* Isso **não** é "settled" e **não** fecha finding nem promove gate. Aprendizados concretos do ciclo 1 que você deve herdar:
- Um "PASS" por `grep` no DDL (`evidence/` do spine v0.3, dentro de `reference/CUME_Canonical_Spine_v0_3_2026-10-01.zip` → `evidence/ddl_static_checks.txt`) escondia que a migração **nem rodava** em Postgres real. Só execução real vale.
- Meu primeiro harness reportava "ACEITO" mesmo com erro (psql escreve erros em stderr e não lança exceção). Sempre use `ON_ERROR_STOP=1` e cheque o código de saída.
- Dois testes meus tinham rótulo que não isolava a regra (barrava por outro motivo). Por isso `Report.expect(..., contains='trecho do erro')` existe: **prove qual regra barrou**.
- `CHECK` cujo resultado é `NULL` **passa** em SQL (lógica de 3 valores): `NULL > 0` e `NULL = 0` não barram. Já gerou bug real (`CONTRACTUAL_ZERO` com valor NULL aceito).
- Teste sem **controle positivo** (caso válido que deve passar) pode estar passando por razões erradas. Toda regra tem pelo menos um.
- **Teste de mutação** (`scripts/mutation_check.sh`) sabota migrações e exige que a suíte falhe. Rode sempre que mexer em teste ou migração.

## 3. Princípios não negociáveis (A–T) e o quanto cada um é HOJE imposto
Legenda: **DB✔** imposto no banco e testado (sandbox) · **SCHEMA** só estrutura existe, comportamento não testado · **✘** não imposto.
| # | Princípio | Estado hoje |
|---|---|---|
| A | Um fato, uma fonte canônica | ✘ (protótipo ainda tem múltiplas fontes; banco ainda não é usado por nenhuma app) |
| B | Appointment ≠ Encounter | SCHEMA + DB✔ (`encounter` própria, `idempotency_key` única por tenant, FK composto) ; fluxo/serviço inexistente |
| C | Encounter ≠ linha financeira | SCHEMA (`performed_item`→`production_item`→`claim_item`) ; fluxo não testado |
| D | Procedimento realizado ≠ pagamento | SCHEMA |
| E | Guia apresentada ≠ pagamento | SCHEMA (`claim` vs `payment`) |
| F | Remittance ≠ settlement | SCHEMA (`remittance` existe; `settlement` é DESIGNED, **sem tabela**) |
| G | Matching de identidade não altera estado financeiro | ✘ |
| H | UNKNOWN ≠ ZERO | DB✔ para preço (`price_status`); **aberto** para `remittance_item.*_amount` (NULL sem status) |
| I | Zero contratual distinguível de desconhecido | DB✔ (`CONTRACTUAL_ZERO` vs `UNKNOWN`) |
| J | Regras com versão e vigência | DB✔ (aprovação, imutabilidade, não-sobreposição por trigger) |
| K | Histórico não recalculado em silêncio | DB✔ (versão fechada imutável; snapshot append-only) |
| L | `calculation_snapshot` em todo cálculo relevante | SCHEMA + DB✔ (hash recomputado); **não há motor** que calcule |
| M | Pagamento como evento/alocação | DB✔ parcial (teto de alocação, ajuste só com aprovação, append-only) ; ledger ponta a ponta ✘ |
| N | Audit trail append-only | DB✔ (trigger + privilégio) ; **ninguém grava audit automaticamente** nem há hash-chain |
| O | Conteúdo clínico não atravessa a fronteira financeira | ✘ (mesmo schema/roles) |
| P | Frontend nunca é autorização | DB✔ (RLS/roles) ; **sem autenticação real**, sem serviço |
| Q | Operação externa com confirmação observável | SCHEMA (`outbox_event`) ; não testado |
| R | Retry idempotente | DB✔ só para `encounter.idempotency_key`; `outbox_event` tem UNIQUE mas não testado |
| S | Simulação rotulada como simulação | ✘ (protótipo) |
| T | Sem dependência do relógio do cliente | SCHEMA (`server_recorded_at`) ; **não imposto** contra valor enviado pelo cliente |

## 4. O que foi feito, tecnicamente (migração por migração)
Todas rodam em ordem sobre banco vazio (`tests/test_01`). Stack: PostgreSQL 16.2, plpgsql, sem extensões (a `btree_gist` não existia no sandbox). Convenções: PK `uuid`; todo registro de negócio tem `tenant_id`; dinheiro `numeric`; tempo `timestamptz`.

**0001 `core_spine` (31 tabelas após 0006; 27 aqui).** Herdado do spine v0.3 e **corrigido**: a original falhava em Postgres real (`UNIQUE (…, COALESCE(competence,''))` é sintaxe inválida) → virou `CREATE UNIQUE INDEX` por expressão. (`reference/…ORIGINAL_v0_3_DEFEITUOSA.sql` fica como regressão; `test_01` exige que ela continue falhando.) Domínios: tenant, patient_identity, practitioner, appointment, encounter, terminology_version, performed_item, professional_participation, rule_version, contract_version, pricing_snapshot, production_item, claim, claim_item, source_document, remittance, remittance_item, payment, payment_allocation, denial, appeal, financial_adjustment, clinical_document, document_version, audit_event, evidence, outbox_event.

**0002 append-only + FK de tenant (encounter).** `forbid_mutation()` + triggers `BEFORE UPDATE OR DELETE` em `audit_event` e `document_version`; FK composto `(tenant_id, patient_id)` em `encounter`. *Defeito encontrado:* antes, UPDATE/DELETE de auditoria e referência cross-tenant eram aceitos.

**0003 FKs consistentes por tenant (33).** Gerada do catálogo: todo FK simples entre tabelas com `tenant_id` virou `(tenant_id, id)` + `UNIQUE (tenant_id, id)` no pai. Exceção: `performed_item.terminology_version_id` (terminologia pode ser global, `tenant_id` nulo). *Impede referenciar linha de outro tenant; não impede ler.*

**0004 teto de alocação.** Constraint trigger `DEFERRABLE INITIALLY IMMEDIATE`: `SUM(payment_allocation.allocated_amount) ≤ payment.remitted_amount`, com `SELECT … FOR UPDATE` no pagamento (serializa concorrência) e também ao reduzir `remitted_amount`. Testado: excesso barrado, limite exato aceito, 2 sessões concorrentes de 60 sobre teto 100 → exatamente 1 vence. *Defeito:* antes, 160 alocados sobre 100 eram aceitos.

**0005 roles + RLS.** `cume_app` (INSERT/UPDATE; **sem DELETE, TRUNCATE, DDL**; sem UPDATE em `audit_event`, `document_version`, `evidence`) e `cume_auditor` (só SELECT). RLS ligada nas 27 tabelas originais com policy `tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid` (fail-closed: sem contexto → 0 linhas). ADR: `docs/adr/ADR-0013`. **Limites:** `app.tenant_id` é GUC de sessão — app comprometido pode trocá-lo; owner/superusuário ignora RLS e triggers.

**0006 IAM core.** `organization`, `user_account` (autenticação é EXTERNA via OIDC: guarda só `(idp_issuer, idp_subject)`, nunca senha; `mfa_enrolled` é só flag), `role_assignment` (papéis BILLING_CLERK, BILLING_APPROVER, PHYSICIAN, CLINIC_ADMIN, AUDITOR, SECURITY_ADMIN; sem auto-concessão; no máximo 1 vínculo ativo por (usuário, papel, organização)), `approval_request` (maker ≠ checker por CHECK). `audit_event.actor_id` agora tem FK composto para `user_account`. RLS + grants nas 4 tabelas novas.

**0007 maker/checker executável.** `financial_adjustment` ganha `approval_id` NOT NULL (+FK composto, UNIQUE). Triggers: ajuste só com aprovação `APPROVED`, da operação certa (`WRITE_OFF` ou `FINANCIAL_ADJUSTMENT`) e com `subject_id = adjustment_id`; maker precisa de papel ativo CLERK/APPROVER; checker de APPROVER ativo no momento da decisão; aprovação decidida é imutável e não apagável; ajuste é append-only (correção = novo ajuste aprovado). **Pré-requisito:** `financial_adjustment` vazia.

**0008 regras/contratos versionados + preço verificável + UNKNOWN≠ZERO.** `rule_version`/`contract_version`: criação e **fechamento** exigem aprovação (`RULE_CHANGE`/`CONTRACT_CHANGE`) coberta; só `effective_to` pode mudar (uma vez, NULL→valor); não-sobreposição por trigger + advisory lock (intervalo semiaberto `[from,to)`). `pricing_snapshot`: `price_status ∈ {PRICED, CONTRACTUAL_ZERO, UNKNOWN}` com CHECK `PRICED⇒amount>0`, `CONTRACTUAL_ZERO⇒amount=0`, `UNKNOWN⇒amount IS NULL` (com `IS NOT NULL` explícito por causa da lógica de 3 valores); `reference_at` deve cair na vigência de regra **e** contrato; `snapshot_hash` é **recomputado no banco** (`pricing_snapshot_hash()`, sha256 de JSON canônico) e rejeitado se divergir; snapshot append-only; `claim_item` recusa item cujo preço é UNKNOWN. **Pré-requisito:** tabelas de regra/contrato/snapshot vazias.

## 5. Mapa de dados (por bounded context)
- **Núcleo:** tenant, organization, user_account, role_assignment, approval_request, practitioner, patient_identity, appointment, encounter, terminology_version.
- **Clínico:** clinical_document, document_version. (DESIGNED sem tabela: clinical_note, diagnostic_order, medication_order.)
- **RCM:** performed_item, professional_participation, rule_version, contract_version, pricing_snapshot, production_item, claim, claim_item, remittance, remittance_item, payment, payment_allocation, denial, appeal, financial_adjustment. (DESIGNED sem tabela: batch, settlement, physician_settlement.)
- **Fundação:** audit_event, evidence, source_document, outbox_event. (DESIGNED: report_snapshot.)
Padrões reutilizáveis: FK composto de tenant; trigger `forbid_mutation`; constraint trigger com `FOR UPDATE`; aprovação coberta (`approval_id` + `subject_id`); fechar-nunca-editar; hash recomputado no banco.

## 6. Como reproduzir (faça isto primeiro)
```bash
# opção A — sem Docker
pip install pgserver
python3 tests/run_all.py                 # esperado: 8 suítes PASS, 135 asserções ok
bash scripts/mutation_check.sh           # esperado: 5 mutantes detectados
# opção B — Postgres existente (SUPERUSER; cria 1 banco novo por suíte)
export CUME_PG_ADMIN_URI=postgresql://postgres:senha@localhost:5432/postgres
export CUME_PSQL=$(which psql)           # opcional
python3 tests/run_all.py
```
Esperado (observado em 2026-10-01): `01:11 · 02:13 · 03:8 · 04:18 · 05:19 · 06:22 · 07:40 · 08:4` = **135 ok, 0 falhas**; mutação 5/5. Recibos do autor: `evidence/`. Se **o seu ambiente** não conseguir rodar Postgres: registre `BLOCKED`, não declare nada como verificado e peça ao humano para rodar e colar a saída.
Nota: `scripts/` pode ter perdido o bit de execução ao descompactar; use `bash scripts/mutation_check.sh`.

## 7. Fragilidades conhecidas (honestas) → onde corrigir
| # | Fragilidade | Gravidade | Backlog |
|---|---|---|---|
| 1 | Nenhuma aplicação usa o banco; UI é o protótipo; **findings originais seguem OPEN** (as correções são só camada de banco) | P0 | B-01, B-13 |
| 2 | Autenticação inexistente; `app.tenant_id` é GUC de sessão alterável por app comprometido; pooler não testado | P0 | B-01 |
| 3 | Owner/superusuário ignora RLS e triggers; credencial de migração = runtime no sandbox | P0 | B-08 |
| 4 | Fronteira clínico↔RCM é só lógica (mesmo schema/roles) | P0 | B-04 |
| 5 | Não existe motor de regras; hash prova integridade, **não** correção da fórmula | P0 | B-02 |
| 6 | Ledger ponta a ponta e adapter de retorno inexistentes; só há teto de alocação | P0 | B-03 |
| 7 | `audit_event` é só tabela: nada grava eventos automaticamente; sem hash-chain | P1 | B-06 |
| 8 | Ciclo de vida do documento clínico (FINAL≠SIGNED, autoria, tempo) não imposto | P1 | B-05 |
| 9 | Aprovação só cobre ajuste/write-off e regras/contratos; `DENIAL_ACCEPT`, `PERMISSION_CHANGE`, `PHYSICIAN_SETTLEMENT` e concessão de papel não exigem | P1 | B-07 |
| 10 | 0007/0008 exigem tabelas vazias; sem estratégia de migração com dados | P1 | B-08 |
| 11 | Não-sobreposição por trigger (sem `btree_gist` no sandbox); EXCLUDE declarativo **não testado** | P2 | B-08 |
| 12 | `remittance_item.*_amount` anuláveis, CHECK deixa NULL passar; semântica indefinida | P1 | B-09 |
| 13 | `reference_at` informado pelo chamador, não ligado à data do serviço | P1 | B-10 |
| 14 | 7 entidades DESIGNED sem tabela | P1 | B-11 |
| 15 | TISS/TUSS/SIGTAP não pesquisados em fonte oficial; nenhuma terminologia real carregada | P1 | B-12 |
| 16 | Testes: n=1 execução, sandbox efêmero, PG 16.2 embutido (versão de produção desconhecida), concorrência testada com 2 sessões só; sem custo de RLS medido; sem property-based | P1 | B-18 |
| 17 | `seed.py` é gerador genérico a partir do catálogo: dados sintéticos pouco realistas; não substitui casos reais anonimizados | P2 | B-18 |
| 18 | `server_recorded_at` e similares: não impedem valor enviado pelo cliente | P1 | B-05 |
| 19 | Sem revisão independente (técnica, de faturamento, de privacidade) | P0 | B-19 |
| 20 | Nada de privacidade/LGPD/segurança formalizado; dados clínicos têm proteção reforçada | P1 | B-15 |
| 21 | Nada de produto/negócio foi desenvolvido; TODO número de mercado é UNKNOWN | P2 | B-17 |
**Limitações do meu trabalho (não confie além disto):** não reauditei o conteúdo do protótipo HTML nem dos PDFs periciais; os 46 findings originais são **herdados** (verifiquei só manifesto/hashes do spine v0.3 e reexecutei os testes de domínio TS dele, todos PASS). Os 11 findings novos (CUME-DB-01…DB-11) são meus e estão no registry v0.4.

## 7b. Descobertas do ciclo 1 (findings novos, resumo)
DB-01 migração 0001 inválida em PG real · DB-02 audit/document_version mutáveis · DB-03 referência cross-tenant (encounter) · DB-04 idem em 33 FKs · DB-05 sobre-alocação de pagamento · DB-06 deriva ERD↔DDL (31 tabelas reconciliadas; 7 DESIGNED) · DB-07 sem RLS/roles · DB-08 sem IAM/maker-checker; ator do audit sem FK · DB-09 ajuste/write-off sem aprovação · DB-10 regras mutáveis/sobrepostas, snapshot editável, UNKNOWN≈ZERO · DB-11 CHECK com NULL passa (3VL). Detalhes: `governance/findings_registry_v0_4.json`.

## 8. O que fazer a seguir (ordem sugerida; critérios de aceite em `governance/backlog_v0_4.yaml`)
1. **B-19** humano atribui revisor independente (sem isso nenhum gate sai de BLOCKED).
2. **B-01** serviço mínimo com OIDC + `SET LOCAL app.tenant_id` por transação.
3. **B-04** barreira física clínico↔RCM (schemas/roles/contrato de minimização).
4. **B-02** motor de regras (dados contratuais reais vêm do humano; sem eles → UNKNOWN).
5. **B-03** ledger + adapter de retorno (idempotente, nunca liquida lote inteiro).
6. **B-05, B-06, B-07** documento clínico, hash-chain, aprovação nas operações restantes.
7. **B-08, B-09, B-10, B-11, B-18** CI, migração com dados, decisões de NULL, reference_at, entidades DESIGNED, dívida de teste.
8. **B-12** TISS/TUSS/SIGTAP com fontes oficiais (exige acesso à web).
9. **B-13, B-14, B-15, B-16, B-17** frontend novo, observabilidade, privacidade, infra, produto/negócio.
MVP sugerido (hipótese a testar, não fato): Produção → Conferência → Pendência/Divergência → Resolução → Recebimento → Relatório. Agenda completa, mensageria, prontuário completo, repasse e TISS extensivo ficam para fases posteriores.

## 9. Como você, modelo, deve trabalhar
1. **Um ciclo = um conjunto pequeno de backlog items.** Formato de resposta por ciclo (do Master Prompt): resumo executivo · estado observado · evidências · gaps · causas-raiz · decisões · arquitetura · implementação · testes · segurança/compliance · observabilidade · produto/negócio · artefatos · findings atualizados · gates · bloqueios · próximas ações.
2. **Nunca edite migração já aplicada** (0001–0008). Crie `0009_*.sql`, `0010_*.sql`…; a única exceção é correção de defeito, documentada como finding e com teste de regressão.
3. **Todo item novo = teste vermelho → implementação → teste verde → mutante.** Use `Report.expect(label, res, 'ok'|'fail', contains=...)` e sempre inclua controle positivo.
4. **Atualize os registros:** `findings_registry` (novo finding ou `v0_4_db_layer`), `gates` (só progresso; **status só muda com receipt + revisor**), `CHANGELOG`, recibos em `evidence/`.
5. **Nunca** invente: dados contratuais, tabelas TUSS/SIGTAP, versões TISS, números de mercado, resultados de teste, homologações, SLOs. Use `UNKNOWN` e proponha o experimento que obtém o dado.
6. **Dados sempre sintéticos.** Não aceite dados reais de pacientes/convênios sem decisão explícita do humano sobre base legal, anonimização e ambiente.
7. **Sem ações destrutivas/externas** (enviar mensagens, pagar, publicar, tocar produção) sem autorização explícita.
8. **Não adicione complexidade sem necessidade comprovada** (sem microserviços, Kubernetes, blockchain, event sourcing completo, IA decorativa). Preferência: monólito modular + PostgreSQL + outbox transacional + fila de jobs + API versionada.
9. IA no produto só onde regra determinística não serve (extração de documento, matching assistido, classificação de glosa), sempre com confiança, evidência, revisão humana, abstenção, auditoria e fallback.
10. Se uma instrução do humano conflitar com uma regra daqui, **diga o conflito** e peça decisão — não resolva em silêncio.

## 10. Decisões que só o humano pode tomar (pergunte cedo)
- Escopo: só RCM, ou RCM + clínico (EHR)? (O prompt original manda separar CUME Core/RCM de CUME Clinical e **não** virar EHR sem decisão.)
- ICP/primeiro cliente: consultório, clínica, hospital, faturista? Quais convênios/contratos reais entram no piloto e **quem fornece** as tabelas contratuais (fonte, formato, permissão de uso)?
- Quem é o revisor independente (técnico, faturamento/auditoria médica, privacidade/LGPD)? Orçamento e prazo?
- Hospedagem/nuvem/jurisdição dos dados, provedor de identidade (OIDC) e política de MFA.
- Canais: web responsiva (principal), PWA, app nativo, portal médico, e-mail/WhatsApp/SMS — cada um exige base jurídica e consentimento; WhatsApp ≠ SMS.
- Semântica de `NULL` em `remittance_item` (desconhecido vs obrigatório) — B-09.
- Política de retenção/descarte de dados e de logs.

## 11. Glossário mínimo
Appointment (agendamento) · Encounter (atendimento efetivo, id canônico) · PerformedItem (procedimento realizado) · ProfessionalParticipation (função do profissional) · PricingSnapshot (cálculo congelado com regra+contrato+entrada+fórmula+hash) · ProductionItem (item de produção) · Claim/ClaimItem (guia/item apresentado) · Remittance/RemittanceItem (retorno do pagador) · Payment/PaymentAllocation (valor recebido e sua alocação a itens) · Denial/Appeal (glosa/recurso) · FinancialAdjustment (reversão/ajuste/write-off, sempre aprovado e imutável) · Settlement/PhysicianSettlement (repasse; DESIGNED) · UNKNOWN (preço/valor desconhecido; **≠ zero**) · CONTRACTUAL_ZERO (zero previsto em contrato) · RLS (row-level security) · GUC (variável de configuração de sessão do PG) · 3VL (lógica de três valores do SQL).

## 12. Inventário deste pacote
`db/migrations/` 8 migrações · `tests/` base, seed, fixtures, 8 suítes, run_all · `scripts/mutation_check.sh` · `governance/` registry v0.4 (57 findings: 46 herdados + 11 novos), gates v0.4, backlog v0.4 (19 itens) · `docs/` este arquivo, ERD, ADR-0013 · `evidence/` recibos do sandbox do autor (originais do ciclo e da consolidação) · `reference/` insumos herdados (protótipos v1/v2, spine v0.3, auditoria diferencial v0.2, migração original defeituosa, relatórios periciais em texto).
**Anexe também (arquivos que o humano já possui, não duplicados aqui por tamanho):** o seu *Master Execution Prompt v1.0*; os PDFs `CUME — Relatório Pericial Integral` (1 e 2), `Baseline Canônico Auditável e Manual de Correção`, `vistoria-completa` (v1 e v2) e as duas capturas de tela; `CUME_iPhone_PWA.zip` / `CUME_iPhone_Standalone.html` (variante PWA do protótipo; não analisada em profundidade por mim).

## Atualização Cycle 9 — 2026-10-02 (supersedes apenas os gaps B-09/B-10/B-23/B-24 acima)

- B-09: decisão candidata `NULL/ausente = UNKNOWN`, zero = `KNOWN` explícito. Reference `EXECUTED+OBSERVED`; DDL 0016 `MATERIALIZED`; PostgreSQL/revisão independente `BLOCKED`.
- B-10: `pricing_snapshot.reference_at = performed_item.performed_at`; seleção temporal usa janela `[effective_from,effective_to)`. Reference `EXECUTED+OBSERVED`; trigger 0016 `MATERIALIZED`; PostgreSQL `BLOCKED`.
- B-23: ADR-0017 atualizado com largest-remainder determinístico. Reference `EXECUTED+OBSERVED`; aprovação de faturamento/RCM `BLOCKED`; `SETTLED=NO`.
- B-24: competência tipada por ano-mês no timezone IANA operacional. Reference `EXECUTED+OBSERVED`; DDL 0016 `MATERIALIZED`; backfill histórico sem timezone autoritativo e calendário de dias úteis continuam `BLOCKED`.
- As linhas históricas deste handoff que dizem “semântica indefinida”, “reference_at não ligado” ou “competência não modelada” devem ser lidas como snapshot anterior a este ciclo, não como estado atual.
