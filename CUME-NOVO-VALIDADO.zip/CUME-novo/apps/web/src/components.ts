import type { EvidenceItemView } from "./contracts";

const esc = (value: string): string => value
  .replaceAll("&", "&amp;")
  .replaceAll("<", "&lt;")
  .replaceAll(">", "&gt;")
  .replaceAll('"', "&quot;")
  .replaceAll("'", "&#39;");

export const statusCard = (item: EvidenceItemView): string => `
<article class="status-card" aria-labelledby="item-${esc(item.id)}">
  <div class="status-card__head">
    <h2 id="item-${esc(item.id)}">${esc(item.label)}</h2>
    <span class="state" data-state="${esc(item.state)}">${esc(item.state)}</span>
  </div>
  <p class="value" aria-label="Valor apresentado pelo servidor">${esc(item.displayValue)}</p>
  <dl class="metadata">
    <div><dt>Estado</dt><dd>${esc(item.state)}</dd></div>
    <div><dt>Origem</dt><dd>${esc(item.source)}</dd></div>
    <div><dt>Evidência</dt><dd>${esc(item.evidence)}</dd></div>
    <div><dt>Última atualização</dt><dd><time datetime="${esc(item.lastUpdated)}">${esc(item.lastUpdated)}</time></dd></div>
    <div><dt>Responsável</dt><dd>${esc(item.responsible)}</dd></div>
    <div><dt>Próxima ação</dt><dd>${esc(item.nextAction)}</dd></div>
  </dl>
  <button type="button" aria-label="Ver evidência de ${esc(item.label)}">Ver evidência</button>
</article>`;
