# CUME v0.5+B21+ISO candidate — status 2026-10-02

- `CUME-ISO-001 / REQ-ISO-001 / I-25`: hard project isolation MATERIALIZED.
- `test_18_project_isolation.py`: red→green observado; mutante de acoplamento detectado; restauração byte-identical.
- Active blueprint: nenhuma dependência/herança HUMAN-OMEGA permitida. Histórico antigo preservado somente em `repo/reference/historical_context/` como `SUPERSEDED_NON_OPERATIONAL`.
- CUME-ISO-01: OPEN; isolamento físico/runtime ainda não observado.
- Supabase: criação de projeto CUME bloqueada pelo limite do plano; nenhum projeto existente alterado.
- Railway: criação de projeto CUME bloqueada pelo limite de recursos; nenhum projeto existente alterado.
- Neon: conector desta sessão não oferece criação de projeto; nenhum projeto existente reutilizado.
- Host local: sem PostgreSQL/Docker/Podman.
- B-21 continua MATERIALIZED; test_17 PostgreSQL continua BLOCKED.
- G0–G12 continuam BLOCKED.
