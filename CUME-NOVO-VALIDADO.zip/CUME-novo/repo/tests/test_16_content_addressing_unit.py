"""B-21 unit contract: deterministic content addressing must preserve existing hash semantics."""
import hashlib, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'domain_ref'))
from content_address import (
    RULE_PROFILE, CONTRACT_PROFILE,
    rule_definition_payload, rule_definition_hash,
    contract_content_payload, contract_content_hash,
)
from rule_eval import canonical_definition_hash

root = Path(__file__).resolve().parent.parent
rule = json.loads((root/'spec'/'rules'/'EXAMPLE_rule_ILLUSTRATIVE.json').read_text())
contract = {'procedimentos': {'P1': '150.00', 'P0': '0', 'PZ': '100.00'}}

assert RULE_PROFILE == 'CUME-RULE-JSON-v1'
assert CONTRACT_PROFILE == 'CUME-CONTRACT-JSON-v1'
# Do not fork the established rule hash semantics.
assert rule_definition_hash(rule) == canonical_definition_hash(rule)
assert rule_definition_hash(rule) == hashlib.sha256(rule_definition_payload(rule).encode('utf-8')).hexdigest()
# Preserve test_11 / contract_version.source_hash semantics exactly.
legacy_contract_hash = hashlib.sha256(json.dumps(contract, sort_keys=True).encode()).hexdigest()
assert contract_content_hash(contract) == legacy_contract_hash
assert contract_content_hash(contract) == hashlib.sha256(contract_content_payload(contract).encode('utf-8')).hexdigest()
# Address is content-derived, not insertion-order-derived.
assert contract_content_hash({'b': {'2': '20'}, 'a': {'1': '10'}}) == contract_content_hash({'a': {'1': '10'}, 'b': {'2': '20'}})
print('== 16 content addressing unit: 7 ok, 0 falha(s)')
