"""MEDIÇÃO (não meta): custo do RLS sobre consultas tenant-escopadas. Sandbox, PostgreSQL embutido, 1 conexão por consulta (psql), dados sintéticos.
Método: 5 tenants x 20.000 pagamentos (100k linhas). Para cada consulta: 1 aquecimento + 9 execuções; reporta mediana, mín e máx do 'Execution Time' do EXPLAIN ANALYZE.
Limites: sem concorrência; sem rede; hardware/PG do sandbox; não generaliza para produção."""
import sys,re,statistics,json
sys.path.insert(0,str(__import__('pathlib').Path(__file__).resolve().parent.parent/'tests'))
from fixtures import *
N=20000;T=5
uri=fresh('bench');s=S(uri);tenants=[u() for _ in range(T)];Fs={t:build(s,t) for t in tenants}
for t in tenants:
    rid=s.ids[('remittance',t)]
    assert sh(uri,f"insert into payment(payment_id,tenant_id,remittance_id,currency,remitted_amount,received_at) select gen_random_uuid(),'{t}','{rid}','BRL',(random()*1000+1)::numeric(19,2),now() from generate_series(1,{N})")[0]==0
sh(uri,"analyze")
total=q(uri,"select count(*) from payment")[0];print('linhas em payment:',total)
tx=tenants[0]
def timeit(sql,ctx=None,role=None,n=9):
    pre=(f"set role {role};select set_config('app.tenant_id','{ctx}',false);" if role else '')
    xs=[]
    for i in range(n+1):
        rc,o=sh(uri,pre+"explain (analyze, timing off) "+sql,t=True)
        m=re.search(r'Execution Time: ([\d.]+) ms',o)
        if i>0 and m: xs.append(float(m.group(1)))
    return xs
Q={'SUM por tenant':"select sum(remitted_amount) from payment",'COUNT por tenant':"select count(*) from payment",'top-100 por valor':"select payment_id from payment order by remitted_amount desc limit 100"}
res={}
for name,base in Q.items():
    owner=timeit(base+(" where tenant_id='%s'"%tx) if 'order' not in base else base.replace("from payment","from payment where tenant_id='%s'"%tx))
    rls=timeit(base,ctx=tx,role='cume_app')
    res[name]={'owner_com_WHERE_ms':[round(statistics.median(owner),2),min(owner),max(owner)],'cume_app_RLS_ms':[round(statistics.median(rls),2),min(rls),max(rls)]}
    print(f"{name:20s} owner+WHERE mediana {statistics.median(owner):8.2f} ms | cume_app+RLS mediana {statistics.median(rls):8.2f} ms | razão {statistics.median(rls)/statistics.median(owner):.2f}x")
json.dump({'rows':int(total),'tenants':T,'rows_per_tenant':N,'results_ms[mediana,min,max]':res,'caveat':'sandbox; 1 conexão; sem concorrência; não é SLO'},open(str(__import__('pathlib').Path(__file__).resolve().parent/'bench_rls_overhead_result.json'),'w'),indent=1)
