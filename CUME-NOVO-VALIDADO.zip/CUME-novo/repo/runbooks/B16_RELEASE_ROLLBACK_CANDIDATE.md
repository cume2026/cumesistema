# B-16 immutable release / rollback candidate
State: SPECIFIED + MATERIALIZED; production execution NOT_EXECUTED.

Release identity is a SHA-256 content manifest. Mutable tags such as `latest` are not release identity. Generate CycloneDX inventory before promotion. Production signing requires an external protected signing identity; the local OpenSSL exercise is synthetic evidence only. Secrets are injected at runtime and never embedded in artifacts. TLS termination and certificate policy require the deployment platform. Database rollback defaults to forward-fix; restore is permitted only from a backup that has a verified restore receipt.
