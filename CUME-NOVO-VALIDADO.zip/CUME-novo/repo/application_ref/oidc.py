"""Synthetic OIDC/JWT verifier used only to exercise the B-01 contract locally.

Classification:
  epistemic_state: MATERIALIZED
  lifecycle_status: CANDIDATE_REFERENCE_ONLY
  project_scope: CUME_ONLY
  production_oidc: BLOCKED

This module deliberately implements only HS256 for a synthetic test IdP. It is
not a production OIDC client and does not select the provider in ADR-0016.
"""
from __future__ import annotations
from dataclasses import dataclass
import base64, hashlib, hmac, json, uuid

class AuthenticationError(ValueError):
    pass

@dataclass(frozen=True)
class VerifiedIdentity:
    issuer: str
    subject: str
    tenant_id: str
    mfa: bool
    expires_at: int


def _decode_segment(segment: str) -> bytes:
    try:
        pad='='*((4-len(segment)%4)%4)
        return base64.urlsafe_b64decode((segment+pad).encode())
    except Exception as exc:
        raise AuthenticationError('malformed jwt encoding') from exc

class SyntheticOIDCVerifier:
    """Strict verifier for synthetic HS256 test tokens only."""
    def __init__(self, *, issuer: str, audience: str, secret: bytes):
        if not issuer or not audience or not isinstance(secret,(bytes,bytearray)) or len(secret)<16:
            raise ValueError('issuer, audience and >=16-byte synthetic secret are required')
        self.issuer=issuer; self.audience=audience; self.secret=bytes(secret)

    def verify(self, token: str, *, now: int) -> VerifiedIdentity:
        if not isinstance(token,str) or token.count('.')!=2:
            raise AuthenticationError('malformed jwt')
        hseg,pseg,sseg=token.split('.')
        try:
            header=json.loads(_decode_segment(hseg))
            payload=json.loads(_decode_segment(pseg))
        except (json.JSONDecodeError,UnicodeDecodeError) as exc:
            raise AuthenticationError('malformed jwt json') from exc
        if header.get('alg')!='HS256' or header.get('typ')!='JWT':
            raise AuthenticationError('unsupported synthetic jwt header')
        expected=hmac.new(self.secret,f'{hseg}.{pseg}'.encode(),hashlib.sha256).digest()
        supplied=_decode_segment(sseg)
        if not hmac.compare_digest(expected,supplied):
            raise AuthenticationError('invalid signature')
        if payload.get('iss')!=self.issuer:
            raise AuthenticationError('invalid issuer')
        aud=payload.get('aud')
        aud_ok=(aud==self.audience) or (isinstance(aud,list) and self.audience in aud)
        if not aud_ok:
            raise AuthenticationError('invalid audience')
        sub=payload.get('sub')
        if not isinstance(sub,str) or not sub:
            raise AuthenticationError('missing subject')
        exp=payload.get('exp')
        if isinstance(exp,bool) or not isinstance(exp,(int,float)) or exp<=now:
            raise AuthenticationError('expired or invalid exp')
        nbf=payload.get('nbf')
        if nbf is not None and (isinstance(nbf,bool) or not isinstance(nbf,(int,float)) or nbf>now):
            raise AuthenticationError('token not active')
        tenant=payload.get('tenant_id')
        try:
            tenant=str(uuid.UUID(str(tenant)))
        except Exception as exc:
            raise AuthenticationError('invalid tenant claim') from exc
        # MFA is deliberately fail-closed: only JSON boolean true means true.
        mfa=payload.get('mfa') is True
        return VerifiedIdentity(self.issuer,sub,tenant,mfa,int(exp))
