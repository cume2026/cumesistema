# Motor de regras — especificação (DESIGNED; referência executável em `repo/domain_ref/`)

## Objetivo
Transformar *(item realizado + participações + contrato vigente na data do serviço)* em **PricingSnapshot** verificável, sem lógica financeira na UI. Cobre F-04, F-09, F-11, F-12, F-23, F-24 e CLIN-04.

## Contrato do motor (pure function)
`evaluate(rule_definition, inputs, contract_tariffs) -> {price_status, expected_amount|null, inputs, intermediate_values, formula, unknown_reason}`
- **Sem I/O, sem relógio, sem aleatoriedade**: a vigência é resolvida *antes* (o chamador escolhe RuleVersion/ContractVersion pela data do serviço).
- **UNKNOWN é absorvente** (propriedade testada em 300 exemplos): tarifa/percentual ausente ⇒ `UNKNOWN`, `expected_amount=null`; o banco impede faturar item `UNKNOWN`.
- **Zero**: só vira `CONTRACTUAL_ZERO` se TODOS os insumos existirem e o resultado for 0 (ex.: tarifa explicitamente `0`).
- **Negativo é erro**: estorno é `FinancialAdjustment` aprovado, nunca preço.
- **Dinheiro**: `Decimal`; arredondamento/escala vêm da própria regra (`HALF_EVEN|HALF_UP|DOWN`, escala 0–6).
- **Determinismo**: mesma entrada ⇒ mesma saída (testado).

## DSL (fechada, sem código arbitrário) — `repo/spec/rules/rule_definition.schema.json`
Operações: `tariff` (lookup), `mul_pct`, `mul` (condicional `when`), `mul_qty`, `round`. Nova operação = mudança de schema + ADR + teste. O JSON canônico é endereçado por hash (`rule_version.definition_hash`); o conteúdo tarifário do contrato por `contract_version.source_hash`.
**B-21 / CUME-DB-13 — candidato materializado em 02/10/2026:** `repo/db/migrations/0011_rule_contract_content.sql` cria o supporting store `cume_content` (`rule_definition`, `contract_content`, `tariff_line`) endereçado por hash e append-only. `test_17` especifica a reprodução DB→motor→snapshot→hash. **Limite atual:** a migração/teste PostgreSQL não foram executados neste host; portanto o finding permanece OPEN e o estado máximo desta mudança é MATERIALIZED.

## Hash do snapshot (paridade provada)
`snapshot_hash = sha256(JSON canônico do jsonb do PostgreSQL de [rule_id, contract_id, moeda, trim_scale(valor), status, inputs, intermediários, fórmula, referência UTC µs])`. Implementação Python: `domain_ref/pricing_hash.py`. Prova: `tests/test_10` (11 casos de borda) e `tests/test_12` (fuzz, 150 documentos). **Outras linguagens (TS/Java) precisam do mesmo teste de paridade** antes de produzirem snapshots.

## Arredondamento e rateio (achado de propriedade)
Dividir um valor em partes arredondadas separadamente pode diferir do total em até R$ 0,01 (testado). O ledger precisa de **política explícita de resto** (ex.: resto alocado à maior parte, ou à última), definida por contrato e coberta por teste — **decisão aberta (ADR-0017)**.

## Regras do protótipo que NÃO são regras contratuais
Auxiliar 30%/20%, via 100/50/70%, urgência ×1,3, anestesia por porte (150…1300): **ilustrativas** (vistoria v1/v2 §7/§9). O exemplo em `spec/rules/EXAMPLE_rule_ILLUSTRATIVE.json` usa esses números **apenas** para teste. Contratos reais são entregues pelo cliente/faturista; sem eles ⇒ `UNKNOWN`.

## O que falta para o motor ser de produção (backlog B-02)
Execução/verificação independente do content store B-21; seleção de vigência por data do serviço (B-10); regras de múltiplos procedimentos/vias/anestesia validadas por faturista; homologação por contrato (testes de aceitação com casos reais anonimizados); revisor independente.
