"""Fixture builder VÁLIDO sobre 0001–0008: cria tenant -> usuários/papéis -> aprovações -> regra/contrato/snapshot (hash via função do banco) -> cadeia clínico-financeira até payment."""
from seed import *
def approve(uri,tenant,maker,checker,op,typ,subj):
    a=u()
    rc,e=sh(uri,f"insert into approval_request(approval_id,tenant_id,operation,subject_type,subject_id,maker_id) values('{a}','{tenant}','{op}','{typ}','{subj}','{maker}')")
    assert rc==0,e
    rc,e=sh(uri,f"update approval_request set status='APPROVED',checker_id='{checker}',decided_at=now() where approval_id='{a}'")
    assert rc==0,e
    return a
def add_user(uri,tenant,email,kind='HUMAN'):
    i=u(); rc,e=sh(uri,f"insert into user_account(user_id,tenant_id,kind,idp_issuer,idp_subject,email) values('{i}','{tenant}','{kind}','idp-sintetico','{i}','{email}')"); assert rc==0,e; return i
def grant(uri,tenant,uid,role,by):
    rc,e=sh(uri,f"insert into role_assignment(assignment_id,tenant_id,user_id,role,granted_by) values('{u()}','{tenant}','{uid}','{role}','{by}')"); assert rc==0,e
def snapshot_hash(uri,rule,contract,cur,amt,st,inputs,inter,formula,ref):
    amt='NULL' if amt is None else amt
    return q(uri,f"select pricing_snapshot_hash('{rule}','{contract}','{cur}',{amt},'{st}','{inputs}'::jsonb,'{inter}'::jsonb,'{formula}','{ref}')")[0]
def insert_snapshot(uri,tenant,rule,contract,amt,st,ref='2026-03-01T12:00:00Z',inputs='{"q":1}',inter='{}',formula='base*q',hash_=None,sid=None):
    sid=sid or u(); h=hash_ or snapshot_hash(uri,rule,contract,'BRL',amt,st,inputs,inter,formula,ref)
    return sid,sh(uri,f"insert into pricing_snapshot(pricing_snapshot_id,tenant_id,rule_version_id,contract_version_id,currency,expected_amount,price_status,reference_at,inputs,intermediate_values,formula,snapshot_hash,calculated_at) values('{sid}','{tenant}','{rule}','{contract}','BRL',{'NULL' if amt is None else amt},'{st}','{ref}','{inputs}','{inter}','{formula}','{h}',now())")
def build(s,tenant,with_tenant_row=True,chain_to='payment'):
    """Retorna dict com ids. s = seed.S. Cria o tenant se with_tenant_row."""
    uri=s.uri
    if with_tenant_row:
        rc,e=sh(uri,f"insert into tenant(tenant_id,legal_name,operational_timezone) values('{tenant}','Tenant sintético','America/Sao_Paulo')"); assert rc==0,e
    adm=add_user(uri,tenant,f'adm-{tenant[:6]}@sint.test'); clerk=add_user(uri,tenant,f'clerk-{tenant[:6]}@sint.test'); appr=add_user(uri,tenant,f'appr-{tenant[:6]}@sint.test')
    grant(uri,tenant,clerk,'BILLING_CLERK',adm); grant(uri,tenant,appr,'BILLING_APPROVER',adm)
    s.ids[('user_account',tenant)]=adm
    for t in ['patient_identity','practitioner','appointment','encounter','performed_item','professional_participation']:
        rc,e,_=s.ins(t,tenant); assert rc==0,(t,e)
    rid,cid=u(),u()
    ra=approve(uri,tenant,clerk,appr,'RULE_CHANGE','rule_version',rid); ca=approve(uri,tenant,clerk,appr,'CONTRACT_CHANGE','contract_version',cid)
    rc,e=sh(uri,f"insert into rule_version(rule_version_id,tenant_id,rule_key,version,effective_from,definition_hash,approval_id) values('{rid}','{tenant}','R','1','2026-01-01','{'a'*64}','{ra}')"); assert rc==0,e
    rc,e=sh(uri,f"insert into contract_version(contract_version_id,tenant_id,contract_key,version,effective_from,source_hash,approval_id) values('{cid}','{tenant}','C','1','2026-01-01','{'b'*64}','{ca}')"); assert rc==0,e
    sid,(rc,e)=insert_snapshot(uri,tenant,rid,cid,'100.00','PRICED'); assert rc==0,e
    s.ids[('pricing_snapshot',tenant)]=sid
    for t in ['production_item','claim','claim_item','source_document','remittance','payment']:
        rc,e,_=s.ins(t,tenant); assert rc==0,(t,e)
        if t==chain_to: break
    return dict(tenant=tenant,admin=adm,clerk=clerk,approver=appr,rule=rid,contract=cid,snapshot=sid,approvals=dict(rule=ra,contract=ca))
