"""CUME reference reconciliation ledger. Pure and deterministic; no persistence or external effects."""
import hashlib,json
from decimal import Decimal,InvalidOperation,ROUND_HALF_EVEN
class LedgerError(ValueError): pass
Q=Decimal('0.01')
def _money(v):
    try: d=Decimal(str(v))
    except (InvalidOperation,ValueError): raise LedgerError('invalid money')
    if not d.is_finite() or d<0: raise LedgerError('money must be finite and non-negative')
    return d.quantize(Q,rounding=ROUND_HALF_EVEN)
def _txt(d): return format(d,'.2f')
def reconcile_payment(payment_amount,allocations,adjustments=()):
    payment=_money(payment_amount)
    allocated=sum((_money(x['allocated_amount']) for x in allocations),Decimal('0.00'))
    adjusted=sum((_money(x['amount']) for x in adjustments),Decimal('0.00'))
    used=allocated+adjusted
    if used>payment: raise LedgerError('allocations + adjustments exceed payment')
    return {'payment_amount':_txt(payment),'allocated_amount':_txt(allocated),'adjustment_amount':_txt(adjusted),'unapplied_amount':_txt(payment-used)}
def ingest_remittance(source_bytes,rows,claim_expected):
    if not isinstance(source_bytes,(bytes,bytearray)): raise LedgerError('source document must be bytes')
    sha=hashlib.sha256(bytes(source_bytes)).hexdigest()
    out=[];matched=Decimal('0');unmatched=Decimal('0');settled=0
    for row in rows:
        amt=_money(row['remitted_amount']); cid=row.get('claim_item_id')
        if cid is not None and cid in claim_expected:
            exp=_money(claim_expected[cid]); alloc=min(amt,exp); outstanding=exp-alloc
            item={'external_id':row['external_id'],'claim_item_id':cid,'match_status':'MATCHED','remitted_amount':_txt(amt),'allocation':{'allocated_amount':_txt(alloc)},'outstanding_amount':_txt(outstanding)}
            matched+=amt
            if outstanding==0: settled+=1
        else:
            item={'external_id':row['external_id'],'claim_item_id':cid,'match_status':'UNMATCHED','remitted_amount':_txt(amt),'allocation':None,'outstanding_amount':None}
            unmatched+=amt
        out.append(item)
    canonical=json.dumps(out,sort_keys=True,separators=(',',':'),ensure_ascii=False)
    receipt=hashlib.sha256((sha+'|'+canonical).encode()).hexdigest()
    return {'source_sha256':sha,'receipt_id':receipt,'items':out,'summary':{'matched_amount':_txt(matched),'unmatched_amount':_txt(unmatched),'settled_claim_items':settled}}
