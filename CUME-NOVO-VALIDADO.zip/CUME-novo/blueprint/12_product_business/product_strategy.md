# Produto e estratégia — hipóteses, não fatos (nenhum dado de mercado foi pesquisado ou inventado)

## O que as vistorias estabelecem (FATO sobre o protótipo)
O diferencial mais nítido do protótipo é a **conferência explicável**: explicar por que um atendimento não virou recebimento e recuperar pendências. A expansão para agenda/prontuário/mensageria/fiscal dilui o MVP e multiplica responsabilidades (v1 §6; v2 §8).

## Decisão estratégica pendente (do dono do produto — não minha)
| Opção | Prós | Contras | Evidência que falta |
|---|---|---|---|
| A. Especialista em conferência/recebimento (RCM) | foco; ciclo de venda claro; risco regulatório menor | menos "wow" de demo | dor mensurável do cliente-alvo |
| B. Plataforma clínica completa | proposta ampla | prontuário/prescrição = regulação, responsabilidade técnica, equipe; escopo enorme | capacidade regulatória/técnica |
| C. Camada de integração sobre prontuários existentes | menor risco clínico | dependência de terceiros | APIs/contratos disponíveis |
**Recomendação [RECOMENDAÇÃO, consistente com v1/v2 e com o prompt-mestre]:** A como MVP; clínico só como pesquisa de experiência até decisão e responsável clínico. **Confiança: moderada** (falta validação de mercado).

## ICP e JTBD (hipóteses a validar com entrevistas)
- ICP candidato 1: clínicas/grupos médicos com faturamento TISS e retornos de várias operadoras. ICP candidato 2: médicos autônomos com produção em hospitais (honorários por função). **Tamanho de mercado, disposição a pagar e concorrência: UNKNOWN** (pesquisar; não inventar).
- JTBD faturista: "Quando recebo o retorno, quero saber o que foi pago, o que divergiu e o que está em glosa, para recuperar o que me devem sem planilha". JTBD médico: "Quero saber quanto produzi, quanto recebi e por que falta".

## MVP (escopo mínimo) — `mvp_scope.yaml`
Produção → Conferência (matching com evidência) → Pendência/Divergência → Resolução → Recebimento (alocação) → Relatório real. **Fora do MVP:** agenda, prontuário/documentos, mensageria, fiscal/IR, repasse automático, app nativo, IA.

## Métricas de sucesso do produto (a medir; ver KPI tree)
Itens conciliados com evidência; duplicações impedidas; tempo por pendência; saldo recuperado **confirmado** (recebido, não contestado).

## O que não prometer
Automação de recuperação de receita, conformidade LGPD/CFM/TISS, "integração com operadoras" — nenhuma está demonstrada.
