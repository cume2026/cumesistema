"""Seeder genérico: lê NOT NULL, FKs e CHECK ... = ANY(ARRAY[...]) do catálogo e preenche uma linha válida. NÃO sabe montar regra/contrato/snapshot (use fixtures.py)."""
import re
from base import *
def split_table(t):
    return tuple(t.split('.',1)) if '.' in t else ('public',t)
class S:
    def __init__(s,uri): s.uri=uri; s.ids={}; s._catalog={}
    def catalog(s,key,query):
        # A seeder is constructed after migrations. Cache this stable catalog
        # rather than launching psql repeatedly for every state-machine edge.
        if key not in s._catalog: s._catalog[key]=q(s.uri,query)
        return s._catalog[key]
    def clear_catalog_cache(s): s._catalog.clear()
    def cols(s,t):
        sch,tab=split_table(t)
        return [l.split('|') for l in s.catalog(('cols',t),f"select column_name,data_type,is_nullable,column_default is not null from information_schema.columns where table_name='{tab}' and table_schema='{sch}' order by ordinal_position")]
    def checks(s,t): return s.catalog(('checks',t),f"select pg_get_constraintdef(oid) from pg_constraint where conrelid='{t}'::regclass and contype='c'")
    def fks(s,t): return {l.split('|')[0]:l.split('|')[1] for l in s.catalog(('fks',t),f"select a.attname,c.confrelid::regclass::text from pg_constraint c join pg_attribute a on a.attrelid=c.conrelid and a.attnum=c.conkey[1] where c.conrelid='{t}'::regclass and c.contype='f' and array_length(c.conkey,1)=1 and a.attname<>'tenant_id'")}
    def ins(s,t,tenant,over=None):
        pkc=s.catalog(('pk',t),f"select a.attname from pg_constraint c join pg_attribute a on a.attrelid=c.conrelid and a.attnum=c.conkey[1] where c.conrelid='{t}'::regclass and c.contype='p'")[0]
        over=over or {}; fk=s.fks(t); ch=" ".join(s.checks(t)); names=[];vals=[];pk=None
        for n,ty,nul,dflt in s.cols(t):
            if n in over: v=over[n]
            elif t=='remittance_item' and n in {'allowed_amount_status','denied_amount_status','contractual_adjustment_status','other_adjustment_status'}:
                v='KNOWN' if over.get(n.removesuffix('_status')) is not None else 'UNKNOWN'
            elif n=='tenant_id': v=tenant
            elif n in fk: v=s.ids.get((fk[n],tenant))
            elif n==pkc: v=u()
            elif nul=='YES' or dflt=='t': continue
            elif ty=='uuid': v=u()
            elif ty=='numeric': v='100.00'
            elif ty=='integer': v='1'
            elif ty=='boolean': v='false'
            elif n=='performed_at': v='2026-03-01T12:00:00Z'
            elif ty.startswith('timestamp'): v='now()'
            elif ty=='date': v='2026-01-01'
            elif ty=='jsonb': v="{}"
            elif ty=='text':
                m=re.search(rf"{n} = ANY \(ARRAY\[\'([^']+)'",ch)
                v=m.group(1) if m else ('a'*64 if n.endswith(('sha256','hash')) else n+'-'+u()[:6])
            else: v=None
            if v is None and nul=='YES': continue
            names.append(n);vals.append(v)
            if n==pkc: pk=v
        lit=lambda v:'now()' if v=='now()' else ("'%s'"%v if isinstance(v,str) else str(v))
        rc,e=sh(s.uri,f"insert into {t}({','.join(names)}) values({','.join(lit(v) for v in vals)})")
        if rc==0 and pk: s.ids[(t,tenant)]=pk
        return rc,e,pk
