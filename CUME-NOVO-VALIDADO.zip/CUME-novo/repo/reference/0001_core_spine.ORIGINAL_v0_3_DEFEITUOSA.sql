-- CUME 0001_core_spine.sql
-- State: MATERIALIZED DDL DRAFT; NOT EXECUTED against PostgreSQL in this cycle.
-- IDs are application-generated UUIDv7/ULID-equivalent UUIDs; no array-length/name-derived IDs.

BEGIN;

CREATE TABLE tenant (
  tenant_id uuid PRIMARY KEY,
  legal_name text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE patient_identity (
  patient_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  display_name text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, patient_id)
);

CREATE TABLE practitioner (
  practitioner_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  display_name text NOT NULL,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE appointment (
  appointment_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  patient_id uuid NOT NULL REFERENCES patient_identity(patient_id),
  practitioner_id uuid REFERENCES practitioner(practitioner_id),
  scheduled_start timestamptz NOT NULL,
  scheduled_end timestamptz,
  status text NOT NULL CHECK (status IN ('SCHEDULED','CONFIRMED','CHECKED_IN','FULFILLED','NO_SHOW','CANCELLED')),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (scheduled_end IS NULL OR scheduled_end > scheduled_start)
);

CREATE TABLE encounter (
  encounter_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  patient_id uuid NOT NULL REFERENCES patient_identity(patient_id),
  appointment_id uuid REFERENCES appointment(appointment_id),
  idempotency_key text NOT NULL,
  started_at timestamptz NOT NULL,
  ended_at timestamptz,
  status text NOT NULL CHECK (status IN ('PLANNED','IN_PROGRESS','COMPLETED','CANCELLED','ENTERED_IN_ERROR')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, idempotency_key),
  CHECK (ended_at IS NULL OR ended_at >= started_at)
);

CREATE TABLE terminology_version (
  terminology_version_id uuid PRIMARY KEY,
  tenant_id uuid REFERENCES tenant(tenant_id),
  code_system text NOT NULL,
  version text NOT NULL,
  competence text,
  effective_from date,
  effective_to date,
  source_url text NOT NULL,
  source_hash text,
  retrieved_at timestamptz NOT NULL,
  validation_status text NOT NULL,
  UNIQUE (code_system, version, COALESCE(competence,''))
);

CREATE TABLE performed_item (
  performed_item_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  encounter_id uuid NOT NULL REFERENCES encounter(encounter_id),
  terminology_version_id uuid REFERENCES terminology_version(terminology_version_id),
  code_system text NOT NULL,
  code text NOT NULL,
  quantity numeric(12,3) NOT NULL CHECK (quantity > 0),
  performed_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE professional_participation (
  participation_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  performed_item_id uuid NOT NULL REFERENCES performed_item(performed_item_id),
  practitioner_id uuid NOT NULL REFERENCES practitioner(practitioner_id),
  function_code text NOT NULL,
  UNIQUE (performed_item_id, practitioner_id, function_code)
);

CREATE TABLE rule_version (
  rule_version_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  rule_key text NOT NULL,
  version text NOT NULL,
  effective_from timestamptz NOT NULL,
  effective_to timestamptz,
  source_document_id uuid,
  definition_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, rule_key, version),
  CHECK (effective_to IS NULL OR effective_to > effective_from)
);

CREATE TABLE contract_version (
  contract_version_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  contract_key text NOT NULL,
  version text NOT NULL,
  effective_from timestamptz NOT NULL,
  effective_to timestamptz,
  source_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, contract_key, version),
  CHECK (effective_to IS NULL OR effective_to > effective_from)
);

CREATE TABLE pricing_snapshot (
  pricing_snapshot_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  rule_version_id uuid NOT NULL REFERENCES rule_version(rule_version_id),
  contract_version_id uuid NOT NULL REFERENCES contract_version(contract_version_id),
  currency char(3) NOT NULL DEFAULT 'BRL',
  expected_amount numeric(19,2) NOT NULL CHECK (expected_amount >= 0),
  inputs jsonb NOT NULL,
  intermediate_values jsonb NOT NULL,
  formula text NOT NULL,
  snapshot_hash text NOT NULL,
  calculated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE production_item (
  production_item_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  performed_item_id uuid NOT NULL REFERENCES performed_item(performed_item_id),
  participation_id uuid REFERENCES professional_participation(participation_id),
  pricing_snapshot_id uuid NOT NULL REFERENCES pricing_snapshot(pricing_snapshot_id),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (performed_item_id, participation_id, pricing_snapshot_id)
);

CREATE TABLE claim (
  claim_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  external_claim_id text,
  status text NOT NULL CHECK (status IN ('DRAFT','VALIDATED','SUBMITTED','ACKNOWLEDGED','ADJUDICATED','REJECTED','CORRECTED','CLOSED')),
  submitted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE claim_item (
  claim_item_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  claim_id uuid NOT NULL REFERENCES claim(claim_id),
  production_item_id uuid NOT NULL REFERENCES production_item(production_item_id),
  currency char(3) NOT NULL DEFAULT 'BRL',
  claimed_amount numeric(19,2) NOT NULL CHECK (claimed_amount >= 0),
  UNIQUE (claim_id, production_item_id)
);

CREATE TABLE source_document (
  source_document_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  object_key text NOT NULL,
  sha256 text NOT NULL,
  media_type text NOT NULL,
  parser_version text,
  source_system text,
  received_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, sha256)
);

CREATE TABLE remittance (
  remittance_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  source_document_id uuid NOT NULL REFERENCES source_document(source_document_id),
  external_remittance_id text,
  received_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE remittance_item (
  remittance_item_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  remittance_id uuid NOT NULL REFERENCES remittance(remittance_id),
  claim_item_id uuid REFERENCES claim_item(claim_item_id),
  currency char(3) NOT NULL DEFAULT 'BRL',
  allowed_amount numeric(19,2) CHECK (allowed_amount >= 0),
  denied_amount numeric(19,2) CHECK (denied_amount >= 0),
  contractual_adjustment numeric(19,2) CHECK (contractual_adjustment >= 0),
  other_adjustment numeric(19,2) CHECK (other_adjustment >= 0),
  match_status text NOT NULL CHECK (match_status IN ('UNMATCHED','CANDIDATE','REVIEW_REQUIRED','MATCHED')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE payment (
  payment_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  remittance_id uuid REFERENCES remittance(remittance_id),
  source_document_id uuid REFERENCES source_document(source_document_id),
  currency char(3) NOT NULL DEFAULT 'BRL',
  remitted_amount numeric(19,2) NOT NULL CHECK (remitted_amount > 0),
  received_at timestamptz NOT NULL,
  external_payment_id text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE payment_allocation (
  allocation_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  payment_id uuid NOT NULL REFERENCES payment(payment_id),
  claim_item_id uuid REFERENCES claim_item(claim_item_id),
  production_item_id uuid REFERENCES production_item(production_item_id),
  allocated_amount numeric(19,2) NOT NULL CHECK (allocated_amount > 0),
  allocated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (claim_item_id IS NOT NULL OR production_item_id IS NOT NULL)
);

CREATE TABLE denial (
  denial_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  remittance_item_id uuid NOT NULL REFERENCES remittance_item(remittance_item_id),
  denied_amount numeric(19,2) NOT NULL CHECK (denied_amount > 0),
  reason_code text,
  status text NOT NULL CHECK (status IN ('OPEN','ACCEPTED','APPEAL_PREPARED','APPEAL_SUBMITTED','RESOLVED')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE appeal (
  appeal_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  denial_id uuid NOT NULL REFERENCES denial(denial_id),
  status text NOT NULL CHECK (status IN ('PREPARED','SUBMITTED','UPHELD','OVERTURNED','PARTIAL','CANCELLED')),
  submitted_at timestamptz,
  decided_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE financial_adjustment (
  adjustment_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  payment_id uuid REFERENCES payment(payment_id),
  allocation_id uuid REFERENCES payment_allocation(allocation_id),
  kind text NOT NULL CHECK (kind IN ('REVERSAL','CONTRACTUAL','OTHER','WRITE_OFF')),
  amount numeric(19,2) NOT NULL CHECK (amount <> 0),
  reason_code text NOT NULL,
  reason_text text,
  reversal_of_adjustment_id uuid REFERENCES financial_adjustment(adjustment_id),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (payment_id IS NOT NULL OR allocation_id IS NOT NULL)
);

CREATE TABLE clinical_document (
  document_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  patient_id uuid NOT NULL REFERENCES patient_identity(patient_id),
  encounter_id uuid REFERENCES encounter(encounter_id),
  document_type text NOT NULL,
  current_status text NOT NULL CHECK (current_status IN ('DRAFT','FINAL','SIGNED','AMENDED','CANCELLED','SUPERSEDED','ENTERED_IN_ERROR')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE document_version (
  document_version_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  document_id uuid NOT NULL REFERENCES clinical_document(document_id),
  version_number integer NOT NULL CHECK (version_number > 0),
  status text NOT NULL CHECK (status IN ('DRAFT','FINAL','SIGNED','AMENDED','CANCELLED','SUPERSEDED','ENTERED_IN_ERROR')),
  author_practitioner_id uuid REFERENCES practitioner(practitioner_id),
  body_object_key text,
  body_sha256 text,
  server_recorded_at timestamptz NOT NULL DEFAULT now(),
  supersedes_version_id uuid REFERENCES document_version(document_version_id),
  UNIQUE (document_id, version_number)
);

CREATE TABLE audit_event (
  audit_event_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  actor_id uuid,
  action text NOT NULL,
  aggregate_type text NOT NULL,
  aggregate_id uuid,
  correlation_id text NOT NULL,
  before_state jsonb,
  after_state jsonb,
  reason_code text,
  occurred_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE evidence (
  evidence_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  audit_event_id uuid REFERENCES audit_event(audit_event_id),
  source_document_id uuid REFERENCES source_document(source_document_id),
  evidence_type text NOT NULL,
  artifact_hash text,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE outbox_event (
  outbox_event_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  aggregate_type text NOT NULL,
  aggregate_id uuid NOT NULL,
  event_type text NOT NULL,
  payload jsonb NOT NULL,
  idempotency_key text NOT NULL,
  correlation_id text NOT NULL,
  status text NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING','PROCESSING','DELIVERED','FAILED')),
  attempts integer NOT NULL DEFAULT 0 CHECK (attempts >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  delivered_at timestamptz,
  UNIQUE (tenant_id, idempotency_key)
);

COMMIT;
