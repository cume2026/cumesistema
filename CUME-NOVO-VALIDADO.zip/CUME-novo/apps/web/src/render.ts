import type { AppViewModel } from "./contracts";
import { statusCard } from "./components";

const esc = (value: string): string => value
  .replaceAll("&", "&amp;")
  .replaceAll("<", "&lt;")
  .replaceAll(">", "&gt;")
  .replaceAll('"', "&quot;")
  .replaceAll("'", "&#39;");

export function renderApp(model: AppViewModel): string {
  const cards = model.items.map(statusCard).join("\n");
  return `<a class="skip-link" href="#conteudo">Pular para o conteúdo</a>
<header class="app-header">
  <div><p class="eyebrow">CUME · spine view</p><h1>${esc(model.title)}</h1></div>
  <span class="environment" aria-label="Ambiente demonstrativo">LOCAL · SYNTHETIC</span>
</header>
<nav aria-label="Fluxo principal" class="flow-nav">
  <ol>
    <li>Produção</li><li>Conferência</li><li>Divergência</li><li>Resolução</li><li>Recebimento</li><li>Relatório</li>
  </ol>
</nav>
<main id="conteudo" tabindex="-1">
  <section aria-labelledby="painel-title">
    <div class="section-title"><div><p class="eyebrow">Evidência antes de status</p><h2 id="painel-title">Painel operacional</h2></div><p class="note">Valores financeiros são apenas apresentados; nenhum cálculo é feito no cliente.</p></div>
    <div class="grid">${cards}</div>
  </section>
</main>
<footer><p>CUME · interface local de referência · não representa ambiente de produção.</p></footer>`;
}
