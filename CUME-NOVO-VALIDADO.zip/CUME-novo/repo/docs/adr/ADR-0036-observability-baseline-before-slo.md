# ADR-0036 — baseline before SLO
Status: ACCEPTED_FOR_REFERENCE / EXECUTED_LOCALLY

CUME may define SLIs before deployment, but quantitative SLOs and non-invariant alert thresholds remain UNKNOWN until measured against a representative workload with documented population, interval and method. Synthetic dashboard data proves wiring/contracts only; it is never product telemetry. Application logs are diagnostic and must not contain personal/clinical payloads; audit_event remains the evidence trail.
