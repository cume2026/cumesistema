from fixtures import *
r=Report('05 IAM core (user_account / role_assignment / approval_request)')
uri=fresh('t5');tA,tB=u(),u()
r.expect('dois tenants válidos com fuso operacional',sh(uri,f"insert into tenant(tenant_id,legal_name,operational_timezone) values('{tA}','A','America/Sao_Paulo'),('{tB}','B','America/Sao_Paulo')"),'ok')
ua,ub,us,uB=u(),u(),u(),u()
ins=lambda i,t,k,e,sub=None:f"insert into user_account(user_id,tenant_id,kind,idp_issuer,idp_subject,email) values('{i}','{t}','{k}','idp','{sub or i}',{'NULL' if e is None else repr(e)})"
r.expect('humano A1',sh(uri,ins(ua,tA,'HUMAN','a1@x.com')),'ok'); r.expect('humano A2',sh(uri,ins(ub,tA,'HUMAN','a2@x.com')),'ok')
r.expect('serviço sem e-mail',sh(uri,ins(us,tA,'SERVICE',None)),'ok')
r.expect('HUMANO sem e-mail',sh(uri,ins(u(),tA,'HUMAN',None)),'fail','user_account_check')
r.expect('e-mail duplicado com caixa diferente (mesmo tenant)',sh(uri,ins(u(),tA,'HUMAN','A1@X.COM')),'fail','user_account_email_uq')
r.expect('mesmo e-mail em outro tenant (controle +)',sh(uri,ins(uB,tB,'HUMAN','a1@x.com')),'ok')
r.expect('(issuer,subject) repetido',sh(uri,ins(u(),tA,'HUMAN','z@x.com',sub=ua)),'fail','idp_issuer')
ra=lambda uu,role,g:f"insert into role_assignment(assignment_id,tenant_id,user_id,role,granted_by) values('{u()}','{tA}','{uu}','{role}','{g}')"
r.expect('papel concedido por outro (controle +)',sh(uri,ra(ua,'BILLING_CLERK',ub)),'ok')
r.expect('auto-concessão',sh(uri,ra(ua,'BILLING_APPROVER',ua)),'fail','role_assignment_check')
r.expect('papel ativo duplicado',sh(uri,ra(ua,'BILLING_CLERK',ub)),'fail','role_assignment_active_uq')
r.expect('conceder a usuário de outro tenant',sh(uri,ra(uB,'AUDITOR',ub)),'fail','foreign key')
mk=lambda st,ch,dec:f"insert into approval_request(approval_id,tenant_id,operation,subject_type,subject_id,maker_id,checker_id,status,decided_at) values('{u()}','{tA}','WRITE_OFF','claim_item','{u()}','{ua}',{ch},'{st}',{dec})"
r.expect('pedido PENDING por quem tem papel (controle +)',sh(uri,mk('PENDING','NULL','NULL')),'ok')
r.expect('criar pedido já APPROVED',sh(uri,mk('APPROVED',f"'{ub}'",'now()')),'fail','created PENDING')
aud=lambda a,T=tA:f"insert into audit_event(audit_event_id,tenant_id,actor_id,action,aggregate_type,aggregate_id,correlation_id,occurred_at) values('{u()}','{T}','{a}','x','t','{u()}','c',now())"
r.expect('audit com ator inexistente',sh(uri,aud(u())),'fail','audit_event_actor_fk'); r.expect('audit com ator real (controle +)',sh(uri,aud(ua)),'ok'); r.expect('audit com ator de outro tenant',sh(uri,aud(uB)),'fail','audit_event_actor_fk')
def app(ctx,sql): return sh(uri,f"set role cume_app;select set_config('app.tenant_id','{ctx}',false);"+sql,t=True)[1].strip().splitlines()[-1]
r.check('app ctx A vê 3 user_account',app(tA,"select count(*) from user_account")=='3'); r.check('app ctx B vê 1',app(tB,"select count(*) from user_account")=='1')
r.check('app sem contexto vê 0 role_assignment',sh(uri,"set role cume_app;select count(*) from role_assignment",t=True)[1].strip().splitlines()[-1]=='0')
r.done()
