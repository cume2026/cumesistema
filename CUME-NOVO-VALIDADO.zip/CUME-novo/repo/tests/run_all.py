"""Uso parcial: python3 tests/run_all.py 'test_0[1-4]*.py'.  Executa todas as migrações+suítes. Saída !=0 se qualquer suíte falhar. Uso: python3 tests/run_all.py   (cd na raiz do repo)"""
import subprocess,sys,time,glob,os
here=os.path.dirname(os.path.abspath(__file__)); res=[]
pats=sys.argv[1:] or ['test_*.py']
files=sorted({f for p in pats for f in glob.glob(os.path.join(here,p))})
for f in files:
    t=time.time(); p=subprocess.run([sys.executable,f],capture_output=True,text=True,cwd=here)
    last=[l for l in p.stdout.splitlines() if l.startswith('==')]
    print(f"{'PASS' if p.returncode==0 else 'FAIL'}  {os.path.basename(f):42s} {last[-1] if last else p.stderr[-200:]}  ({time.time()-t:.0f}s)",flush=True)
    if p.returncode: print(p.stdout[-2500:],p.stderr[-800:])
    res.append(p.returncode)
print('RESULTADO:','TODAS AS SUÍTES PASSARAM' if not any(res) else f'{sum(1 for x in res if x)} SUÍTE(S) FALHARAM'); sys.exit(1 if any(res) else 0)
