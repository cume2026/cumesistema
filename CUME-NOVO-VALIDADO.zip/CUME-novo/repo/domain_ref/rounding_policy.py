"""CUME deterministic rounding remainder policy (B-23).

Reference policy: allocate integer minor units using largest remainder; ties are
resolved by stable lexical participant key. This guarantees sum(parts)==total.
Business/RCM approval is still required before SETTLED/VERIFIED promotion.
"""
from decimal import Decimal, ROUND_DOWN

Q=Decimal('0.01')

class RoundingPolicyError(ValueError):
    pass


def _decimal(v, label):
    if not isinstance(v, Decimal):
        raise RoundingPolicyError(f'{label} must be Decimal')
    if not v.is_finite():
        raise RoundingPolicyError(f'{label} must be finite')
    return v


def allocate_minor_units(total, weights):
    total=_decimal(total,'total')
    if total < 0:
        raise RoundingPolicyError('total must be non-negative')
    if total.quantize(Q) != total:
        raise RoundingPolicyError('total must already be in minor-unit precision')
    if not weights:
        raise RoundingPolicyError('at least one allocation key is required')
    clean={}
    for key,weight in weights.items():
        w=_decimal(weight,f'weight[{key}]')
        if w < 0:
            raise RoundingPolicyError('weights must be non-negative')
        clean[str(key)]=w
    denominator=sum(clean.values(),Decimal('0'))
    if denominator <= 0:
        raise RoundingPolicyError('sum of weights must be positive')
    exact={k:(total*w/denominator) for k,w in clean.items()}
    floor={k:v.quantize(Q,rounding=ROUND_DOWN) for k,v in exact.items()}
    remaining_cents=int(((total-sum(floor.values(),Decimal('0')))/Q).to_integral_value())
    order=sorted(clean, key=lambda k: (-(exact[k]-floor[k]), k))
    out=dict(floor)
    for key in order[:remaining_cents]:
        out[key]+=Q
    if sum(out.values(),Decimal('0')) != total:
        raise RoundingPolicyError('allocation conservation failure')
    return {k:out[k] for k in sorted(out)}
