# CUME — v0.5+B21 candidate — 2026-10-02

Este diretório é um **delta derivado** do pacote v0.5 recebido. O baseline v0.5 continua sendo a origem; B-21 não promove nenhum gate.

## O que mudou
- `repo/db/migrations/0011_rule_contract_content.sql`: supporting store `cume_content`.
- `repo/domain_ref/content_address.py`: perfis de serialização/hashing compatíveis com v0.5.
- `repo/tests/test_16_content_addressing_unit.py`: TDD unitário observado (7/7).
- `repo/tests/test_17_rule_contract_content.py`: integração DB→motor→snapshot→hash, **MATERIALIZED mas não executada neste host**.
- `repo/docs/content_store_erd.mmd`: ERD do supporting store.
- governança/traceability atualizadas sem fechar `CUME-DB-13`.

## Estado
- `CUME-DB-13`: OPEN / MATERIALIZED.
- G0–G12: BLOCKED.
- PostgreSQL: indisponível neste host; `run_all.py` termina BLOCKED por dependências (`pgserver`, e Hypothesis em test_12).
- Dados: apenas sintéticos/ilustrativos; nenhuma tarifa real foi inventada.

Leia `repo/docs/CYCLE2_B21_STATUS.md` e `repo/evidence/cycle2_b21/receipt.json` antes de qualquer promoção de estado.
