"""Infra de teste portável do CUME. Dois modos:
 (a) padrão: PostgreSQL embutido via `pip install pgserver` (sem Docker);
 (b) CUME_PG_ADMIN_URI=postgresql://user:pw@host:5432/postgres -> cria um banco novo por suíte (usuário precisa ser SUPERUSER: usa SET ROLE/CREATE ROLE).
Opcional: CUME_PSQL=/caminho/psql. Dados SEMPRE sintéticos."""
import os,sys,shutil,subprocess,uuid,tempfile,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
MIG=Path(os.environ.get('CUME_MIG_DIR') or ROOT/'db'/'migrations')
def migrations(): return sorted(MIG.glob('0*.sql'))
def psql_bin():
    if os.environ.get('CUME_PSQL'): return os.environ['CUME_PSQL']
    w=shutil.which('psql')
    if w: return w
    import pgserver; return str(Path(pgserver.__file__).parent/'pginstall'/'bin'/('psql.exe' if os.name=='nt' else 'psql'))
PSQL=psql_bin()
def start(label):
    adm=os.environ.get('CUME_PG_ADMIN_URI')
    if adm:
        name=f"cume_{label}_{uuid.uuid4().hex[:8]}"
        r=subprocess.run([PSQL,'-X','-q','-v','ON_ERROR_STOP=1','-c',f'create database {name}',adm],capture_output=True,text=True,errors='replace')
        if r.returncode: sys.exit('não consegui criar banco: '+r.stderr)
        return re.sub(r'/[^/?]*(\?|$)',f'/{name}\\1',adm,count=1)
    import pgserver
    d=tempfile.mkdtemp(prefix=f'cume_{label}_')
    return pgserver.get_server(d,cleanup_mode='stop').get_uri()
def sh(uri,sql=None,f=None,t=False,timeout=90):
    # Windows psql converts command-line SQL through the ANSI code page.
    # UTF-8 stdin avoids corrupting accented SQL literals; one transaction
    # retains the atomic batch behavior of a single -c command.
    stdin_sql=sql is not None and os.name=='nt'
    action=['-1','-f','-'] if stdin_sql else (['-c',sql] if sql is not None else ['-f',str(f)])
    a=[PSQL,'-v','ON_ERROR_STOP=1','-X','-q']+(['-t','-A','-F','|'] if t else [])+action+[uri]
    r=subprocess.run(a,input=sql if stdin_sql else None,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=timeout)
    lines=r.stderr.strip().splitlines()
    return r.returncode,(r.stdout if t and r.returncode==0 else '\n'.join(lines).replace('ERROR:  ','')[:2000])
def q(uri,sql):
    rc,o=sh(uri,sql,t=True)
    return [l for l in o.strip().splitlines()] if rc==0 else []
def apply_all(uri,upto=None):
    for f in migrations():
        if upto and f.name>upto: break
        rc,e=sh(uri,f=f)
        if rc: sys.exit(f'MIGRAÇÃO FALHOU {f.name}: {e}')
def fresh(label,upto=None):
    uri=start(label); apply_all(uri,upto); return uri
u=lambda:str(uuid.uuid4())
class Report:
    def __init__(s,name): s.name=name; s.ok=0; s.bad=[]; print(f'## {name}',flush=True)
    def expect(s,label,res,exp,contains=None):
        """exp='ok' exige rc==0. exp='fail' exige rc!=0 e, se `contains`, que a mensagem contenha o trecho (isola QUAL regra barrou)."""
        rc,msg=res; good=(rc==0) if exp=='ok' else (rc!=0 and (contains is None or contains.lower() in msg.lower()))
        s._p(good,f"{label}: {'ACEITO' if rc==0 else 'BARRADO -> '+msg[:90]}"+('' if good or exp=='ok' or contains is None else f"  [esperava conter: {contains!r}]"))
    def check(s,label,cond,extra=''): s._p(bool(cond),f'{label}'+(f' -> {extra}' if extra!='' else ''))
    def _p(s,good,txt):
        print(f" {'✔' if good else '✘ FALHA'} {txt}",flush=True)
        if good: s.ok+=1
        else: s.bad.append(txt)
    def done(s):
        print(f'== {s.name}: {s.ok} ok, {len(s.bad)} falha(s)',flush=True); sys.exit(1 if s.bad else 0)
