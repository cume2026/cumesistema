# ADR-0029 — Semântica de NULL em remittance_item

**Status:** SPECIFIED + REFERENCE_EXECUTED; PostgreSQL enforcement MATERIALIZED/NOT_EXECUTED; independent verification NOT_EXECUTED.

Decision: each nullable remittance monetary field has an explicit `KNOWN|UNKNOWN` state. `UNKNOWN` requires SQL NULL; `KNOWN` requires a numeric value and may legitimately be exactly zero. No layer may coerce absent/NULL to zero.

Fields: `allowed_amount`, `denied_amount`, `contractual_adjustment`, `other_adjustment`.

Rationale: SQL three-valued logic permits NULL through `CHECK amount >= 0`; financial meaning must therefore be explicit. This ADR does not infer payer intent from an absent field; absent remains UNKNOWN.
