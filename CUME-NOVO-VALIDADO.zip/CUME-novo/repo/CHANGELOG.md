# Changelog
## 2026-10-02 — Cycle 15 terminal local-spine audit
- Terminal verdict: `LOCAL_SPINE_COMPLETE_EXTERNAL_BLOCKERS_ONLY`; known local executable gaps = 0.
- Corrected unexecuted migration 0017 approval fields and tenant-consistent FKs; B-07/B-11 terminal static contract passes.
- Integrated B-25 strict parser into authenticated reference API; added B-24 injected business-calendar mechanics and B-03 staged remittance pipeline.
- Reconciled stale governance/CI descriptions without gate promotion.
- Terminal matrix: 71 tests = 55 PASS + 16 BLOCKED_BY_ENVIRONMENT + 0 FAIL; 4/4 terminal mutants detected.
- All G0–G12 remain BLOCKED; whole_product_complete=false; pilot_ready=false; production_ready=false; settled=false.

## 2026-10-02 — v0.5+B05 clinical-document candidate
- B-05 lifecycle reference `EXECUTED+OBSERVED`: consumes the canonical state machine; full 7×7 matrix, immutable new versions, authenticated authorship, PHYSICIAN+practice rule and client-time rejection tested.
- `0013_clinical_document_lifecycle.sql` `MATERIALIZED`: derives author from `app.user_id`, adds practice scope and server-recorded time guard; PostgreSQL execution remains BLOCKED.
- Real cryptographic signature validation and independent trusted timestamp/TSA remain separate `BLOCKED/UNVERIFIED` capabilities.
- CLIN-02/06/11 stay OPEN; G5/G8 not promoted.

## v0.5+B21+ISO+QA+B25-candidate — 2026-10-02
- CUME-QA-01/02 materializados: `test_15` fail-closed quando blueprint está ausente; `Dockerfile.tests` agora preserva layout repo+blueprint e inclui dependências `openapi-spec-validator`/`rdflib`.
- TDD do meta-harness: `test_19_qa_harness_contract.py` RED 8 falhas → GREEN 13/13; mutante removendo `COPY blueprint/` detectado e restauração byte-identical.
- Docker build/CI real permanecem BLOCKED neste host; findings continuam OPEN e nenhum gate foi promovido.
- B-25 referência executável: `input_parse.py` + `test_20` (22/22) com `Decimal`, UNKNOWN≠ZERO e data DD/MM/YYYY validada por calendário; integração com API/importador continua ausente.

## v0.5+B21+ISO-candidate — 2026-10-02
- Owner decision formalized as `CUME-ISO-001` / `REQ-ISO-001` / `I-25`: CUME is architecturally and operationally independent from HUMAN-OMEGA and any other product.
- ADR-0023 and `test_18_project_isolation.py` materialized; active conceptual inheritance from HUMAN-OMEGA removed from the blueprint and historical mapping moved to `reference/` as `SUPERSEDED_NON_OPERATIONAL`.
- Dedicated cloud/database runtime remains BLOCKED: Supabase and Railway rejected new resources due account-plan limits; no existing HUMAN-OMEGA resource was reused.
- No gate promoted; CUME-ISO-01 remains OPEN until dedicated runtime isolation is observed and independently reviewed.

## v0.5+B21-candidate — 2026-10-02
- B-21 MATERIALIZED: nova migração `0011_rule_contract_content.sql`, schema `cume_content`, objetos `rule_definition`, `contract_content`, `tariff_line`.
- Hashes preservam os perfis v0.5 existentes (`CUME-RULE-JSON-v1`, `CUME-CONTRACT-JSON-v1`); conteúdo e projeções são append-only, tenant-scoped e RLS.
- TDD unitário observado: `test_16_content_addressing_unit.py` red→green, 7 asserções.
- Integração PostgreSQL `test_17_rule_contract_content.py` e mutante DB adicionados, mas execução está BLOCKED neste host por ausência de PostgreSQL/pgserver.
- Nenhum gate promovido; `CUME-DB-13` permanece OPEN em estado MATERIALIZED.

## v0.5 — 2026-10-01
- NOVO: 0009 máquinas de estado (gerada da spec; matriz exaustiva: 60 transições permitidas aceitas, 162 proibidas barradas). Finding CUME-DB-12.
- NOVO (P0): 0010 CHECK anti-NaN em 11 colunas numeric. Finding CUME-DB-15: NaN contornava o teto de alocação (R$ 6.000.000 alocados contra pagamento NaN; evidence/receipt_nan_bypass.txt).
- NOVO: domain_ref (hash de snapshot em Python com paridade provada, avaliador de regras), spec/rules (DSL fechada), benchmarks/bench_rls_overhead, evidence/prototype_v2_probe.
- NOVO: tests 09–15; mutation_check com 9 mutantes.
- GOVERNANÇA: findings v0.5 (64), gates v0.5 (13 BLOCKED), backlog v0.5 (B-20…B-28), ADRs 0014–0022 (PROPOSED). Renomeação CUME-N -> CUME-DB.
- Findings novos reproduzidos pelo autor no protótipo v2: CLIN-14 (visita futura concluída), CLIN-15 (placeholders), F-34 (competência; parcial).

## 2026-10-02 — CUME-CLASS-001 candidate

- `SPECIFIED/MATERIALIZED/EXECUTED/OBSERVED`: introduced a two-axis classification contract separating epistemic/materialization state from surface capability state.
- `MATERIALIZED/OBSERVED`: added `governance/surface_registry_v1.json` with 18 CUME-only work surfaces.
- `EXECUTED/OBSERVED`: `tests/test_23_classification_contract.py` passes and kills a missing-dimension mutant.
- `OBSERVED`: normalized 21 legacy findings from free-form `state` into canonical `epistemic_state` while preserving original detail; no evidentiary promotion was performed.
- `BLOCKED`: independent verification/settlement remains pending.
- HUMAN-OMEGA remains outside CUME architecture, resources, evidence and runtime.

## 2026-10-02 — v0.5+B01 reference candidate
- B-01: added CUME-only `application_ref` boundary with synthetic signed-token verification, server-side subject/tenant mapping and role authorization.
- Added transaction-local tenant context contract and runtime/migration role separation reference.
- Added tests 24–26 with RED→GREEN evidence and mutants for tenant isolation, MFA and transaction-local scope.
- Real OIDC, dedicated PostgreSQL pool/runtime role and deployed network API remain BLOCKED/UNVERIFIED; F-05 OPEN; G7 BLOCKED.

## 2026-10-02 — v0.5+B04 boundary candidate
- B-04 reference boundary `EXECUTED+OBSERVED`: minimized typed Clinical→RCM event; encounter completion has no automatic financial materialization; UNKNOWN pricing is rejected by explicit production materialization.
- `0012_clinical_rcm_boundary.sql` `MATERIALIZED`: `clinical`/`rcm` schemas, specialized roles, explicit billing denial on `clinical`, typed append-only RCM bridge and RLS policies.
- Harness/blueprint made schema-aware for `public+clinical+rcm`; ERD/taxonomy/ontology/data inventory updated; inventory now has 275 rows for these schemas.
- Mutants for UNKNOWN pricing and billing clinical access were detected.
- PostgreSQL execution, runtime permission-denied, real service-role binding and independent review remain `BLOCKED/UNVERIFIED`; G5 not promoted.

## 2026-10-02 — Cycle 11 / B-12
- Added CUME-only versioned terminology resolver, N:N crosswalk contract and hash-gated secure XSD validator reference.
- Added migration 0019 for append-only terminology codes/crosswalks; EXACT requires human review.
- Updated official-source registry from ANS September/2026 + TUSS access + Ministry SIGTAP documentation.
- Official binary package ingestion/XSD validation remains BLOCKED; no demo code was promoted.

## 2026-10-02 — Cycle 12 — B-15 + B-26 + B-27
- Added privacy governance reference contracts (`privacy_ref/governance.py`).
- Added purpose/version-specific consent and exact-channel preference events (`privacy_ref/consent.py`).
- Added retention/erasure eligibility engine with calendar-year periods and legal-review abstention (`privacy_ref/retention.py`).
- Added candidate PostgreSQL migration `0020_privacy_consent_retention.sql` with tenant RLS, append-only consent/preference events and identity-detachment boundary.
- Materialized ADR-0021 technical decision while keeping qualified legal/DPO review BLOCKED.
- Observed current official LGPD/medical-record/ANPD incident sources in `privacy_normative_sources_v1.json`; no compliance self-attestation.
- TDD: tests 46, 47, 48, 48a, 49; mutation tests detect channel fallback, legal-review bypass, incident-risk removal and append-only removal.
- Global suite: 35 PASS / 16 environment-blocked (`pgserver/PostgreSQL`; `hypothesis` additionally for test_12); G10 remains BLOCKED.

## 2026-10-02 — Cycle 17 / Phase 2 of 4 (Claude audit AUD-06/AUD-08/AUD-09)
- Added fail-closed `gen_blueprint_views.py --check` and DDL-derived `generated_catalog.yaml`.
- Regenerated current MASTER_INDEX and ERD; taxonomy coverage is checked against the migration-derived catalog.
- Moved 18 historical manifests to `lineage/manifests/` and documented divergence/authenticity semantics.
- Removed Hypothesis execution cache; documented historical test numbering; reserved ADR-0030/0033/0034.
- Added test_72 with red/green/mutation evidence; 57 non-PostgreSQL suites pass locally.
- PostgreSQL runtime verification remains pending; no gate promoted.

## 2026-10-02 — Cycle 18 / Phase 3 of 4
- AUD-10: exact direct CI dependency lock, Python 3.12.3, embedded-pgserver workflow, Chromium setup, fail-closed generated-view/inventory checks, installed-version verifier.
- AUD-11: migration-derived technical inventory now 370/370 classified with no UNCLASSIFIED/unknown sensitivity; DPO/legal adjudication remains external.
- Added test_73 with RED→GREEN and 3 mutation checks.
