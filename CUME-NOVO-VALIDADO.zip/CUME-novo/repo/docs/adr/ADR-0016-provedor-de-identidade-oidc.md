# ADR-0016 — Provedor de identidade (OIDC)

**Status:** PROPOSED (rascunho; nenhuma decisão tomada)

Gerenciado vs auto-hospedado; MFA como claim; custo e conformidade. Status: PROPOSED.

**Consequências:** a preencher após decisão.
