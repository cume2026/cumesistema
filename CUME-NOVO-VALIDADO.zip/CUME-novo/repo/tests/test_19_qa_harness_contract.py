"""Meta-testes do harness: evita PASS vazio da suíte 15 e imagem de testes incompleta.

Este arquivo usa apenas stdlib para poder detectar defeitos do próprio ambiente de teste
antes de depender de PostgreSQL ou dos pacotes opcionais da suíte 15.
"""
from pathlib import Path
import re
import sys

REPO = Path(__file__).resolve().parent.parent
PACKAGE = REPO.parent
DOCKERFILE = PACKAGE / "blueprint" / "11_infra_deploy" / "Dockerfile.tests"
TEST15 = REPO / "tests" / "test_15_blueprint_consistency.py"
LOCK = REPO / "requirements-ci.lock"

checks = []

def check(label: str, cond: bool, detail: str = "") -> None:
    checks.append((label, bool(cond), detail))
    mark = "✔" if cond else "✘ FALHA"
    print(f" {mark} {label}" + (f" -> {detail}" if detail else ""), flush=True)

print("## 19 contrato do harness QA", flush=True)
docker = DOCKERFILE.read_text(encoding="utf-8")
t15 = TEST15.read_text(encoding="utf-8")

check("Dockerfile de testes existe", DOCKERFILE.is_file())
check("Dockerfile copia repo para /workspace/repo", "COPY repo/ /workspace/repo/" in docker)
check("Dockerfile copia blueprint como irmão do repo", "COPY blueprint/ /workspace/blueprint/" in docker)
check("WORKDIR preserva layout package/repo", "WORKDIR /workspace/repo" in docker)

check("Dockerfile usa requirements-ci.lock", "requirements-ci.lock" in docker and "pip install --no-cache-dir -r" in docker)
lock_text = LOCK.read_text(encoding="utf-8") if LOCK.exists() else ""
for dep in ("PyYAML", "jsonschema", "hypothesis", "pgserver", "openapi-spec-validator", "rdflib", "playwright"):
    m = re.search(rf"(?m)^\s*{re.escape(dep)}==[^\s#]+\s*$", lock_text, re.I)
    check(f"lock fixa dependência {dep}", bool(m))
check("Dockerfile instala Chromium explicitamente", "playwright install --with-deps chromium" in docker)

# A suíte 15 deve abortar de forma não-zero ANTES de importar fixtures/abrir PostgreSQL
# quando o blueprint estiver ausente. O marcador FAIL_CLOSED_BLUEPRINT é intencionalmente
# simples para que este meta-teste continue stdlib-only.
check("test_15 declara fail-closed para blueprint ausente", "FAIL_CLOSED_BLUEPRINT" in t15)
idx_guard = t15.find("FAIL_CLOSED_BLUEPRINT")
idx_fixtures = t15.find("from fixtures import")
check("fail-closed ocorre antes do import de fixtures", idx_guard != -1 and idx_fixtures != -1 and idx_guard < idx_fixtures)
check("test_15 não mantém branch de skip bem-sucedido", "blueprint/ ausente: suíte pulada" not in t15)

bad = [label for label, ok, _ in checks if not ok]
print(f"== 19 contrato do harness QA: {len(checks)-len(bad)} ok, {len(bad)} falha(s)", flush=True)
if bad:
    sys.exit(1)
