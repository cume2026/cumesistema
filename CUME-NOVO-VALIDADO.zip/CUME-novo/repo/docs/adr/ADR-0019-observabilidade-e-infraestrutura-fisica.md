# ADR-0019 — Observabilidade e infraestrutura física

**Status:** PROPOSED (rascunho; nenhuma decisão tomada)

OTel + stack de métricas/logs; custo; retenção; sem K8s/microsserviços sem evidência. Status: PROPOSED.

**Consequências:** a preencher após decisão.
