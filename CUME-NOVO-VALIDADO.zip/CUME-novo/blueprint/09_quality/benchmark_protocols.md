# Protocolos de benchmark e avaliação (separando MEDIDO de ALVO)

## Regra
Uma métrica só é "medida" com **dataset, método, cálculo, ambiente e resultado**. Caso contrário é **alvo** (target) e fica marcada como tal. Não existe SLO sem baseline.

## Medido neste ciclo
| Métrica | Valor | Método | Limites |
|---|---|---|---|
| Custo do RLS em consultas por tenant (SUM/COUNT/top-100, 100.000 pagamentos, 5 tenants) | razão cume_app+RLS / owner+WHERE = 0,99× / 1,01× / 1,03× (medianas ≈ 3–6 ms) | `benchmarks/bench_rls_overhead.py`; EXPLAIN ANALYZE; 1 aquecimento + 9 execuções | sandbox, 1 conexão, sem concorrência, sem rede; **não é SLO** |
| Paridade de hash Python==PG | 11 casos de borda + 150 documentos aleatórios, 0 divergências | tests 10 e 12 | cobre jsonb/numeric/timestamp; não prova outras linguagens |
| Matriz de transições | 60 permitidas aceitas, 162 proibidas barradas | test_09 | transições = hipótese de domínio |
| Detecção de suítes vácuas | 9/9 mutantes detectados | mutation_check.sh | mutantes escolhidos pelo autor |

## A medir (protocolos)
1. **Conciliação (produto)**: *itens conciliados com evidência / itens do demonstrativo*; *duplicações impedidas*; *tempo por pendência*; *saldo recuperado confirmado* (só valor **recebido**, nunca montante contestado). Dataset: retornos reais anonimizados de design partners (após base legal). Baseline: processo atual do cliente.
2. **Matching (se houver assistência IA)**: precision/recall por faixa de confiança, taxa de revisão humana, erro de vínculo *crítico* (vincular errado) separado de erro de omissão. Conjunto-ouro rotulado por 2 revisores com concordância (κ) reportada.
3. **Extração de documento (OCR/LLM, se adotada)**: acurácia por campo, taxa de abstenção, ECE/Brier **apenas** com dataset de calibração separado.
4. **Desempenho**: latência p50/p95/p99 por endpoint, fila (lag), throughput de importação, com perfil de carga realista e concorrência; só depois definir SLOs.
5. **Resiliência**: RPO/RTO medidos em exercício de restore; falha de dependência externa; reprocessamento idempotente.
6. **Acessibilidade**: axe/pa11y sem violações críticas; teclado ponta a ponta; leitor de tela (manual).
