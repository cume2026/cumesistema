#!/usr/bin/env python3
import base64, hashlib, hmac, json, pathlib, sys, time, uuid
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

from application_ref.oidc import SyntheticOIDCVerifier, AuthenticationError
from application_ref.api import CumeReferenceApi, IdentityDirectory, TenantItemStore

SECRET=b'cume-b01-synthetic-test-secret'
ISS='https://idp.synthetic.cume.test'
AUD='cume-api'
NOW=1790917200

def b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b'=').decode()

def token(*, sub, tenant, exp=NOW+300, mfa=False, secret=SECRET, iss=ISS, aud=AUD):
    header={'alg':'HS256','typ':'JWT'}
    payload={'iss':iss,'sub':sub,'aud':aud,'exp':exp,'iat':NOW-1,'tenant_id':tenant,'mfa':mfa}
    h=b64(json.dumps(header,separators=(',',':'),sort_keys=True).encode())
    p=b64(json.dumps(payload,separators=(',',':'),sort_keys=True).encode())
    sig=b64(hmac.new(secret,f'{h}.{p}'.encode(),hashlib.sha256).digest())
    return f'{h}.{p}.{sig}'

def call(api, method, path, bearer=None, headers=None):
    h=dict(headers or {})
    if bearer is not None: h['authorization']='Bearer '+bearer
    return api.handle(method,path,h,now=NOW)

tenant_a=str(uuid.uuid4()); tenant_b=str(uuid.uuid4())
sub_a='user-a'; sub_b='user-b'; sub_clerk='clerk-a'
dir=IdentityDirectory()
dir.provision(issuer=ISS,subject=sub_a,tenant_id=tenant_a,user_id=str(uuid.uuid4()),roles={'BILLING_APPROVER'})
dir.provision(issuer=ISS,subject=sub_b,tenant_id=tenant_b,user_id=str(uuid.uuid4()),roles={'BILLING_APPROVER'})
dir.provision(issuer=ISS,subject=sub_clerk,tenant_id=tenant_a,user_id=str(uuid.uuid4()),roles={'BILLING_CLERK'})
store=TenantItemStore()
a_id=store.add(tenant_a,{'label':'A'})
b_id=store.add(tenant_b,{'label':'B'})
api=CumeReferenceApi(SyntheticOIDCVerifier(issuer=ISS,audience=AUD,secret=SECRET),dir,store)

checks=[]
def ck(label, cond):
    checks.append((label,bool(cond)))
    print((' ✔ ' if cond else ' ✘ FALHA ')+label)

r=call(api,'GET',f'/v1/items/{a_id}')
ck('sem token => 401',r.status==401)
r=call(api,'GET',f'/v1/items/{a_id}',token(sub=sub_a,tenant=tenant_a,exp=NOW-1))
ck('token expirado => 401',r.status==401)
r=call(api,'GET',f'/v1/items/{a_id}',token(sub=sub_a,tenant=tenant_a,secret=b'wrong'))
ck('assinatura inválida => 401',r.status==401)
r=call(api,'GET',f'/v1/items/{a_id}',token(sub=sub_a,tenant=tenant_a))
ck('tenant A lê item A => 200',r.status==200 and r.body.get('label')=='A')
r=call(api,'GET',f'/v1/items/{b_id}',token(sub=sub_a,tenant=tenant_a))
ck('tenant A não lê item B => 404',r.status==404)
r=call(api,'GET',f'/v1/items/{b_id}',token(sub=sub_a,tenant=tenant_a),{'x-tenant-id':tenant_b})
ck('header de tenant não substitui identidade autenticada',r.status==404)
r=call(api,'GET',f'/v1/items/{a_id}',token(sub=sub_a,tenant=tenant_b))
ck('claim tenant divergente do diretório server-side => 403',r.status==403)
r=call(api,'GET',f'/v1/items/{a_id}',token(sub='unknown',tenant=tenant_a))
ck('subject não provisionado => 403',r.status==403)
r=call(api,'POST','/v1/critical/approve',token(sub=sub_a,tenant=tenant_a,mfa=False))
ck('operação crítica sem MFA => 403',r.status==403)
r=call(api,'POST','/v1/critical/approve',token(sub=sub_clerk,tenant=tenant_a,mfa=True))
ck('MFA sem papel aprovador => 403',r.status==403)
r=call(api,'POST','/v1/critical/approve',token(sub=sub_a,tenant=tenant_a,mfa=True))
ck('MFA + papel server-side => 200',r.status==200)

bad=[x for x in checks if not x[1]]
print(f'== 24 B-01 OIDC/API reference contract: {len(checks)-len(bad)} ok, {len(bad)} falha(s)')
sys.exit(1 if bad else 0)
