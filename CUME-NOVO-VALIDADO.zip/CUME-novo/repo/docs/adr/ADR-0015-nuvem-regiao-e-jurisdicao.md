# ADR-0015 — Nuvem, região e jurisdição

**Status:** PROPOSED (rascunho; nenhuma decisão tomada)

Dados de saúde: residência no Brasil? Verificar com jurídico/DPO e contratos de suboperador. Status: PROPOSED; decisão e parecer pendentes.

**Consequências:** a preencher após decisão.
