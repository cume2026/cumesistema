#!/usr/bin/env python3
import json, pathlib, re, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
mig=ROOT/'db'/'migrations'/'0012_clinical_rcm_boundary.sql'
reg=ROOT/'governance'/'cycle6_b04_registry.json'
assert mig.exists(), '0012_clinical_rcm_boundary.sql missing'
assert reg.exists(), 'cycle6_b04_registry.json missing'
sql=mig.read_text()
low=sql.lower()
checks=[]
def ck(label,cond):
    checks.append((label,bool(cond))); print((' ✔ ' if cond else ' ✘ FALHA ')+label)
ck('schema clinical materializado','create schema' in low and 'clinical' in low)
ck('schema rcm materializado','create schema' in low and 'rcm' in low)
ck('clinical_document migra para clinical','alter table public.clinical_document set schema clinical' in low)
ck('document_version migra para clinical','alter table public.document_version set schema clinical' in low)
ck('role cume_billing existe','cume_billing' in low and 'nobypassrls' in low)
ck('billing sem USAGE em clinical',bool(re.search(r'revoke\s+all\s+on\s+schema\s+clinical\s+from[^;]*cume_billing',low,re.S)))
ck('billing sem privilégios em tabelas clinical',bool(re.search(r'revoke\s+all\s+on\s+all\s+tables\s+in\s+schema\s+clinical\s+from[^;]*cume_billing',low,re.S)))
ck('bridge RCM é tipada','create table rcm.performed_item_event' in low and 'jsonb' not in low.split('create table rcm.performed_item_event',1)[1].split(');',1)[0])
ck('participants normalizados','create table rcm.performed_item_event_participant' in low)
ck('clinical só publica no bridge RCM','grant insert on rcm.performed_item_event' in low and 'to cume_clinical' in low)
ck('não há trigger de auto production_item','production_item' not in low or 'create trigger' not in low.split('production_item',1)[0])
# Classification registry
obj=json.loads(reg.read_text())
ck('registry é CUME_ONLY',obj.get('project_scope')=='CUME_ONLY')
items={x['id']:x for x in obj['elements']}
required={'B04_MINIMIZATION_CONTRACT','B04_COMPLETION_NO_AUTO_FINANCE','B04_PHYSICAL_SCHEMA_DDL','B04_BILLING_DENY_DDL','B04_POSTGRES_EXECUTION','B04_BILLING_DENY_RUNTIME_TEST','B04_REAL_SERVICE_ROLE_BINDING','B04_INDEPENDENT_REVIEW'}
ck('8 elementos B04 classificados',required<=set(items))
allowed={'REQUESTED','SPECIFIED','DESIGNED','MATERIALIZED','EXECUTED','OBSERVED','VERIFIED','SETTLED','BLOCKED','FAILED','ABSTAIN','SUPERSEDED','DEPRECATED'}
ck('todos elementos têm classificação/evidência',all(x['classification']['epistemic_state'] in allowed and x['classification'].get('lifecycle_status') and x['classification'].get('evidence_basis') for x in items.values()))
for i in ('B04_POSTGRES_EXECUTION','B04_BILLING_DENY_RUNTIME_TEST','B04_REAL_SERVICE_ROLE_BINDING','B04_INDEPENDENT_REVIEW'):
    ck(i+' permanece BLOCKED',items[i]['classification']['epistemic_state']=='BLOCKED')
ck('nenhum elemento compartilha runtime HUMAN-OMEGA',all(x.get('shares_runtime_with_human_omega') is False for x in items.values()))
bad=[x for x in checks if not x[1]]
print(f'== 28 B-04 physical boundary static/classification: {len(checks)-len(bad)} ok, {len(bad)} falha(s)')
sys.exit(1 if bad else 0)
