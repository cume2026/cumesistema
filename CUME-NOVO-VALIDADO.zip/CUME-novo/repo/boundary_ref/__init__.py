"""CUME-only bounded-context reference contracts.

Classification: MATERIALIZED candidate reference code; not a production runtime.
Project scope: CUME_ONLY.
"""
