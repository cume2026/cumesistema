from dataclasses import dataclass
@dataclass(frozen=True)
class Batch: batch_id:str; tenant_id:str; status:str
