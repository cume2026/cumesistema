import {observeMoney,parseStrictDecimal} from './financial_semantics';
let state=18018>>>0; const rnd=()=>{state=(1664525*state+1013904223)>>>0; return state};
let failures=0; const cases=2000;
for(let i=0;i<cases;i++){
  const unknown=observeMoney(null); if(unknown.status!=='UNKNOWN'||unknown.cents!==null) failures++;
  const cents=BigInt(rnd()%1000000); const x=observeMoney(cents); if(x.status!=='KNOWN'||x.cents!==cents) failures++;
  const amount=(cents/100n).toString()+'.'+(cents%100n).toString().padStart(2,'0');
  const p=parseStrictDecimal(amount); if(p.status!=='KNOWN'||p.cents!==cents) failures++;
}
console.log(`cases=${cases} failures=${failures}`); if(failures) throw new Error(`property failures=${failures}`);
