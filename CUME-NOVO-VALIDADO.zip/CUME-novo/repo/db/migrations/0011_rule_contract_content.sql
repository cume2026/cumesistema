-- CUME 0011 — B-21: content-addressed store de regras e contratos (candidate; dados sintéticos)
-- Decisão de compatibilidade: schema dedicado cume_content; NÃO altera as 33 tabelas públicas validadas por tests 01/08/15.
-- Não edita 0001–0010 e não torna conteúdo obrigatório para versões legadas nesta migração.
BEGIN;

CREATE SCHEMA cume_content;
REVOKE ALL ON SCHEMA cume_content FROM PUBLIC;
GRANT USAGE ON SCHEMA cume_content TO cume_app, cume_auditor;

CREATE FUNCTION cume_content.sha256_text(payload text)
RETURNS text LANGUAGE sql IMMUTABLE STRICT AS $$
  SELECT encode(sha256(convert_to(payload,'UTF8')),'hex')
$$;

CREATE TABLE cume_content.rule_definition (
  tenant_id uuid NOT NULL REFERENCES public.tenant(tenant_id),
  definition_hash text NOT NULL,
  serialization_profile text NOT NULL DEFAULT 'CUME-RULE-JSON-v1',
  canonical_payload text NOT NULL,
  definition jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, definition_hash),
  CONSTRAINT rule_definition_hash_format CHECK (definition_hash ~ '^[0-9a-f]{64}$'),
  CONSTRAINT rule_definition_profile CHECK (serialization_profile = 'CUME-RULE-JSON-v1'),
  CONSTRAINT rule_definition_object CHECK (jsonb_typeof(definition) = 'object'),
  CONSTRAINT rule_definition_payload_matches_json CHECK (canonical_payload::jsonb = definition),
  CONSTRAINT rule_definition_hash_matches_payload CHECK (definition_hash = cume_content.sha256_text(canonical_payload))
);

CREATE TABLE cume_content.contract_content (
  tenant_id uuid NOT NULL REFERENCES public.tenant(tenant_id),
  source_hash text NOT NULL,
  serialization_profile text NOT NULL DEFAULT 'CUME-CONTRACT-JSON-v1',
  canonical_payload text NOT NULL,
  content jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, source_hash),
  CONSTRAINT contract_content_hash_format CHECK (source_hash ~ '^[0-9a-f]{64}$'),
  CONSTRAINT contract_content_profile CHECK (serialization_profile = 'CUME-CONTRACT-JSON-v1'),
  CONSTRAINT contract_content_object CHECK (jsonb_typeof(content) = 'object'),
  CONSTRAINT contract_content_payload_matches_json CHECK (canonical_payload::jsonb = content),
  CONSTRAINT contract_content_hash_matches_payload CHECK (source_hash = cume_content.sha256_text(canonical_payload))
);

CREATE TABLE cume_content.tariff_line (
  tariff_line_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL,
  source_hash text NOT NULL,
  table_key text NOT NULL CHECK (btrim(table_key) <> ''),
  code text NOT NULL CHECK (btrim(code) <> ''),
  amount numeric(19,6) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT tariff_line_amount_nonnegative_finite CHECK (amount >= 0 AND amount <> 'NaN'::numeric),
  CONSTRAINT tariff_line_contract_content_fk FOREIGN KEY (tenant_id, source_hash)
    REFERENCES cume_content.contract_content(tenant_id, source_hash),
  CONSTRAINT tariff_line_natural_uq UNIQUE (tenant_id, source_hash, table_key, code)
);

CREATE FUNCTION cume_content.tariff_line_matches_contract_content() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  payload jsonb;
  raw text;
  parsed numeric;
BEGIN
  SELECT content INTO payload
    FROM cume_content.contract_content
   WHERE tenant_id = NEW.tenant_id AND source_hash = NEW.source_hash;
  raw := payload #>> ARRAY[NEW.table_key, NEW.code];
  IF raw IS NULL THEN
    RAISE EXCEPTION 'tariff_line path %.% absent from contract_content', NEW.table_key, NEW.code
      USING ERRCODE='foreign_key_violation';
  END IF;
  BEGIN
    parsed := raw::numeric;
  EXCEPTION WHEN invalid_text_representation OR numeric_value_out_of_range THEN
    RAISE EXCEPTION 'tariff_line source value %.% is not numeric', NEW.table_key, NEW.code
      USING ERRCODE='check_violation';
  END;
  IF parsed = 'NaN'::numeric OR parsed IS DISTINCT FROM NEW.amount THEN
    RAISE EXCEPTION 'tariff_line amount does not match contract_content at %.%', NEW.table_key, NEW.code
      USING ERRCODE='check_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER tariff_line_content_guard_t
BEFORE INSERT ON cume_content.tariff_line FOR EACH ROW EXECUTE FUNCTION cume_content.tariff_line_matches_contract_content();

-- Content-addressed objects are immutable: change => new bytes/hash, never UPDATE/DELETE.
CREATE TRIGGER rule_definition_append_only
  BEFORE UPDATE OR DELETE ON cume_content.rule_definition FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();
CREATE TRIGGER contract_content_append_only
  BEFORE UPDATE OR DELETE ON cume_content.contract_content FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();
CREATE TRIGGER tariff_line_append_only
  BEFORE UPDATE OR DELETE ON cume_content.tariff_line FOR EACH ROW EXECUTE FUNCTION public.forbid_mutation();

GRANT SELECT, INSERT ON cume_content.rule_definition, cume_content.contract_content, cume_content.tariff_line TO cume_app;
GRANT SELECT ON cume_content.rule_definition, cume_content.contract_content, cume_content.tariff_line TO cume_auditor;

ALTER TABLE cume_content.rule_definition ENABLE ROW LEVEL SECURITY;
CREATE POLICY rule_definition_tenant_isolation ON cume_content.rule_definition FOR ALL TO cume_app, cume_auditor
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);
ALTER TABLE cume_content.contract_content ENABLE ROW LEVEL SECURITY;
CREATE POLICY contract_content_tenant_isolation ON cume_content.contract_content FOR ALL TO cume_app, cume_auditor
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);
ALTER TABLE cume_content.tariff_line ENABLE ROW LEVEL SECURITY;
CREATE POLICY tariff_line_tenant_isolation ON cume_content.tariff_line FOR ALL TO cume_app, cume_auditor
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true),'')::uuid);

COMMENT ON SCHEMA cume_content IS 'B-21 supporting store: conteúdo de regras/contratos endereçado por hash; separado do schema public para preservar a espinha pública v0.5.';
COMMENT ON TABLE cume_content.rule_definition IS 'RuleDefinition imutável endereçada por definition_hash; perfil CUME-RULE-JSON-v1.';
COMMENT ON TABLE cume_content.contract_content IS 'Conteúdo de contrato imutável endereçado por source_hash; perfil CUME-CONTRACT-JSON-v1.';
COMMENT ON TABLE cume_content.tariff_line IS 'Projeção normalizada de tarifas, validada contra contract_content; não substitui o conteúdo-fonte.';

COMMIT;
