#!/usr/bin/env python3
import pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
checks=[]
def ck(label,cond): checks.append((label,bool(cond))); print((' ✔ ' if cond else ' ✘ FALHA ')+label)
texts={p:(ROOT/p).read_text() for p in [
 'tests/test_01_migrations.py','tests/test_08_erd_drift_and_nullability.py',
 'tests/test_13_numeric_nan_hardening.py','tests/test_15_blueprint_consistency.py',
 'tests/seed.py','tests/test_03_audit_append_only.py','tests/test_09_state_machines.py']}
for p in ('tests/test_01_migrations.py','tests/test_08_erd_drift_and_nullability.py','tests/test_13_numeric_nan_hardening.py','tests/test_15_blueprint_consistency.py'):
    ck(p+' conhece clinical/rcm',"'clinical'" in texts[p] and "'rcm'" in texts[p])
ck('seeder aceita schema.table','split_table' in texts['tests/seed.py'])
ck('test_03 usa clinical schema','clinical.clinical_document' in texts['tests/test_03_audit_append_only.py'] and 'clinical.document_version' in texts['tests/test_03_audit_append_only.py'])
ck('test_09 mapeia clinical_document físico','clinical.clinical_document' in texts['tests/test_09_state_machines.py'])

erd=(ROOT/'docs'/'erd.mmd').read_text()
ck('ERD contém bridge event','PERFORMED_ITEM_EVENT' in erd and 'PERFORMED_ITEM_EVENT_PARTICIPANT' in erd)
tax=(ROOT.parent/'blueprint'/'01_taxonomy'/'taxonomy.yaml').read_text()
ck('taxonomia contém bridge event','performed_item_event' in tax and 'performed_item_event_participant' in tax)
onto=(ROOT.parent/'blueprint'/'02_ontology'/'onto_ops_cume.yaml').read_text()
ck('ontologia contém bridge event','PerformedItemEvent' in onto and 'PerformedItemEventParticipant' in onto)
inv=(ROOT.parent/'blueprint'/'07_security_privacy'/'data_inventory.csv').read_text()
ck('inventário contém bridge event','performed_item_event,event_id' in inv and 'performed_item_event_participant,event_id' in inv)
bad=[x for x in checks if not x[1]]
print(f'== 29 B-04 schema-aware harness static: {len(checks)-len(bad)} ok, {len(bad)} falha(s)')
sys.exit(1 if bad else 0)
