#!/usr/bin/env python3
import pathlib,sys
from decimal import Decimal
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'domain_ref'))
from financial_semantics import AmountSemanticError, observe_amount, normalize_remittance_amounts
checks=[]
def ck(label,cond): checks.append((label,bool(cond))); print((' ✔ ' if cond else ' ✘ FALHA ')+label)
def blocked(fn):
    try: fn(); return False
    except AmountSemanticError: return True

u=observe_amount(None)
ck('NULL é UNKNOWN',u.status=='UNKNOWN' and u.amount is None)
z=observe_amount(Decimal('0.00'))
ck('zero explícito é KNOWN',z.status=='KNOWN' and z.amount==Decimal('0.00'))
p=observe_amount(Decimal('12.34'))
ck('valor positivo é KNOWN',p.status=='KNOWN' and p.amount==Decimal('12.34'))
ck('negativo é rejeitado',blocked(lambda:observe_amount(Decimal('-0.01'))))
ck('float é rejeitado',blocked(lambda:observe_amount(1.23)))
row=normalize_remittance_amounts({'allowed_amount':Decimal('0.00'),'denied_amount':None,'contractual_adjustment':Decimal('2.50')})
ck('campo ausente permanece UNKNOWN',row['other_adjustment_status']=='UNKNOWN' and row['other_adjustment'] is None)
ck('NULL explícito permanece UNKNOWN',row['denied_amount_status']=='UNKNOWN' and row['denied_amount'] is None)
ck('zero não se perde',row['allowed_amount_status']=='KNOWN' and row['allowed_amount']==Decimal('0.00'))
ck('valor conhecido preservado',row['contractual_adjustment_status']=='KNOWN' and row['contractual_adjustment']==Decimal('2.50'))
ck('normalização não introduz zero para UNKNOWN',all(not (row[k+'_status']=='UNKNOWN' and row[k] is not None) for k in ['allowed_amount','denied_amount','contractual_adjustment','other_adjustment']))
bad=[x for x in checks if not x[1]]
print(f'== 36 B-09 NULL amount semantics: {len(checks)-len(bad)} ok, {len(bad)} falha(s)')
sys.exit(1 if bad else 0)
