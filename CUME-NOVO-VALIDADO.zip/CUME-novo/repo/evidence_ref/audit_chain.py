from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime
import hashlib, json, re

GENESIS='0'*64
HEX64=re.compile(r'^[0-9a-f]{64}$')

@dataclass(frozen=True)
class AuditEventInput:
    audit_event_id:str; tenant_id:str; actor_id:str|None; action:str; aggregate_type:str; aggregate_id:str|None; correlation_id:str
    before_state:dict|None; after_state:dict|None; reason_code:str|None; occurred_at:datetime

@dataclass(frozen=True)
class ChainedAuditEvent(AuditEventInput):
    sequence_no:int; prev_hash:str; event_hash:str

@dataclass(frozen=True)
class AuditCheckpoint:
    tenant_id:str; event_count:int; head_sequence:int; head_hash:str; checkpoint_hash:str

@dataclass(frozen=True)
class VerificationResult:
    valid:bool; errors:tuple[str,...]

class EvidenceLinkError(ValueError): pass

def _ts(dt:datetime)->str:
    if dt.tzinfo is None: raise ValueError('occurred_at must be timezone-aware')
    return dt.isoformat(timespec='microseconds').replace('+00:00','Z')

def _payload(e:AuditEventInput, sequence_no:int, prev_hash:str)->str:
    obj={
      'audit_event_id':e.audit_event_id,'tenant_id':e.tenant_id,'actor_id':e.actor_id,'action':e.action,
      'aggregate_type':e.aggregate_type,'aggregate_id':e.aggregate_id,'correlation_id':e.correlation_id,
      'before_state':e.before_state,'after_state':e.after_state,'reason_code':e.reason_code,
      'occurred_at':_ts(e.occurred_at),'sequence_no':sequence_no,'prev_hash':prev_hash,
    }
    return json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False)

def _hash(e:AuditEventInput,sequence_no:int,prev_hash:str)->str:
    return hashlib.sha256(_payload(e,sequence_no,prev_hash).encode('utf-8')).hexdigest()

def append_event(chain:list[ChainedAuditEvent], event:AuditEventInput)->ChainedAuditEvent:
    if chain and any(x.tenant_id != event.tenant_id for x in chain): raise ValueError('tenant mismatch')
    sequence_no=(chain[-1].sequence_no+1) if chain else 1
    prev_hash=chain[-1].event_hash if chain else GENESIS
    event_hash=_hash(event,sequence_no,prev_hash)
    return ChainedAuditEvent(**asdict(event),sequence_no=sequence_no,prev_hash=prev_hash,event_hash=event_hash)

def make_checkpoint(chain:list[ChainedAuditEvent])->AuditCheckpoint:
    if not chain: raise ValueError('checkpoint requires non-empty chain')
    tenant=chain[0].tenant_id
    if any(x.tenant_id!=tenant for x in chain): raise ValueError('mixed tenants')
    head=chain[-1]
    raw=json.dumps({'tenant_id':tenant,'event_count':len(chain),'head_sequence':head.sequence_no,'head_hash':head.event_hash},sort_keys=True,separators=(',',':'))
    return AuditCheckpoint(tenant,len(chain),head.sequence_no,head.event_hash,hashlib.sha256(raw.encode()).hexdigest())

def verify_chain(chain:list[ChainedAuditEvent], checkpoint:AuditCheckpoint|None=None)->VerificationResult:
    errors=[]
    if not chain:
        if checkpoint and checkpoint.event_count!=0: errors.append('checkpoint count mismatch')
        return VerificationResult(not errors,tuple(errors))
    tenant=chain[0].tenant_id; prev=GENESIS
    for idx,e in enumerate(chain,1):
        if e.tenant_id!=tenant: errors.append(f'tenant mismatch at {idx}')
        if e.sequence_no!=idx: errors.append(f'sequence mismatch at {idx}')
        if e.prev_hash!=prev: errors.append(f'prev_hash mismatch at {idx}')
        base=AuditEventInput(e.audit_event_id,e.tenant_id,e.actor_id,e.action,e.aggregate_type,e.aggregate_id,e.correlation_id,e.before_state,e.after_state,e.reason_code,e.occurred_at)
        expected=_hash(base,e.sequence_no,e.prev_hash)
        if e.event_hash!=expected: errors.append(f'event_hash mismatch at {idx}')
        prev=e.event_hash
    if checkpoint:
        if checkpoint.tenant_id!=tenant: errors.append('checkpoint tenant mismatch')
        if checkpoint.event_count!=len(chain): errors.append('checkpoint count mismatch')
        if checkpoint.head_sequence!=chain[-1].sequence_no: errors.append('checkpoint sequence mismatch')
        if checkpoint.head_hash!=chain[-1].event_hash: errors.append('checkpoint head mismatch')
    return VerificationResult(not errors,tuple(errors))

def validate_evidence_link(*,audit_event_id:str|None,source_document_id:str|None,artifact_hash:str|None)->bool:
    if not audit_event_id and not source_document_id: raise EvidenceLinkError('evidence must link audit_event or source_document')
    if artifact_hash is not None and not HEX64.fullmatch(artifact_hash): raise EvidenceLinkError('artifact_hash must be lowercase sha256 hex')
    return True
