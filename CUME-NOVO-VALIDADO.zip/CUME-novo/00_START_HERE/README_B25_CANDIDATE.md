# CUME B-25 candidate — parser de entrada pt-BR — 2026-10-02

- `domain_ref/input_parse.py`: contrato de referência sem I/O.
- Dinheiro: `Decimal`; `None`/blank = UNKNOWN; `0,00` = zero explícito; `1.23`, `10abc`, `NaN`, `Infinity`, negativo e formato en-US são rejeitados.
- Data: somente `DD/MM/YYYY`, com calendário Gregoriano real; `99/99`, data não bissexta, ISO silencioso e falta de zero-padding são rejeitados.
- `test_20_input_parsing_ptbr.py`: 22/22 observado; dois mutantes detectados.
- Não existe API/importador real consumindo este parser; B-25 é apenas referência executável e F-03/F-08/F-15 permanecem OPEN.
