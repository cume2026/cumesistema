from dataclasses import dataclass
from datetime import datetime

CHANNELS={'WHATSAPP','SMS','EMAIL','VOICE_CALL','PUSH'}
ACTIONS={'GRANT','REVOKE'}
PREF_ACTIONS={'ALLOW','BLOCK'}

@dataclass(frozen=True)
class ConsentEvent:
    event_id: str
    subject_ref: str
    purpose_code: str
    notice_version: str
    action: str
    source: str
    recorded_at: datetime
    def __post_init__(self):
        if self.action not in ACTIONS or not all((self.event_id,self.subject_ref,self.purpose_code,self.notice_version,self.source)):
            raise ValueError('INVALID_CONSENT_EVENT')

@dataclass(frozen=True)
class ChannelPreferenceEvent:
    event_id: str
    subject_ref: str
    purpose_code: str
    channel: str
    action: str
    recorded_at: datetime
    def __post_init__(self):
        if self.channel not in CHANNELS or self.action not in PREF_ACTIONS or not all((self.event_id,self.subject_ref,self.purpose_code)):
            raise ValueError('INVALID_CHANNEL_PREFERENCE_EVENT')


def _latest(events, at):
    candidates=[e for e in events if e.recorded_at<=at]
    if not candidates: return None
    candidates.sort(key=lambda x:(x.recorded_at,x.event_id))
    return candidates[-1]


def has_valid_consent(events, subject_ref, purpose_code, notice_version, at):
    scoped=[e for e in events if e.subject_ref==subject_ref and e.purpose_code==purpose_code and e.notice_version==notice_version]
    last=_latest(scoped,at)
    return bool(last and last.action=='GRANT')


def is_channel_permitted(events, subject_ref, purpose_code, channel, at):
    if channel not in CHANNELS: return False
    scoped=[e for e in events if e.subject_ref==subject_ref and e.purpose_code==purpose_code and e.channel==channel]
    last=_latest(scoped,at)
    return bool(last and last.action=='ALLOW')


def authorize_communication(subject_ref,purpose_code,channel,legal_basis_code,at,consent_events,preference_events,notice_version=None):
    if legal_basis_code in {None,'','UNKNOWN'}:
        raise ValueError('LEGAL_BASIS_MUST_BE_DECLARED')
    if not is_channel_permitted(preference_events,subject_ref,purpose_code,channel,at):
        raise PermissionError('CHANNEL_NOT_PERMITTED_FOR_PURPOSE')
    if legal_basis_code=='CONSENT':
        if not notice_version or not has_valid_consent(consent_events,subject_ref,purpose_code,notice_version,at):
            raise PermissionError('CONSENT_NOT_EFFECTIVE_FOR_PURPOSE_AND_VERSION')
    return True
