# ADR-0025 — Clinical↔RCM physical boundary candidate

**Project scope:** `CUME_ONLY`  
**Decision state:** `SPECIFIED → MATERIALIZED`; reference behavior `EXECUTED → OBSERVED`; PostgreSQL runtime `BLOCKED`; independent verification `BLOCKED`.

## Context

B-04 exists because clinical narrative and revenue-cycle state cannot rely on a logical convention inside one broad runtime. `CLIN-03` and `CLIN-12` require a physical access boundary; `CLIN-04` requires that encounter completion never invent or hard-code financial value.

## Decision

1. Sensitive clinical documents move from `public` to schema `clinical`.
2. A dedicated `cume_clinical` role receives only clinical/shared-kernel privileges required by the clinical service.
3. A dedicated `cume_billing` role has no schema/table privilege on `clinical`.
4. Clinical→RCM communication crosses only a typed, minimized `rcm.performed_item_event` + normalized participant relation.
5. The bridge contains procedure code/system, quantity, time, encounter/performed-item identifiers and participant identifiers/functions. It contains no clinical narrative, diagnosis, medication, allergy, report body, tariff or price.
6. Encounter completion may publish the minimized event but does not create a `production_item` automatically.
7. Production materialization is a distinct RCM operation and the reference contract rejects `UNKNOWN` pricing.
8. `cume_app` is a transitional broad role from earlier migrations and is explicitly revoked from `clinical` by 0012. Real services must eventually bind to specialized roles; this is not yet executed.

## Evidence classification

- `boundary_ref/clinical_rcm.py`: `MATERIALIZED → EXECUTED → OBSERVED`, `REFERENCE_ONLY`.
- `0012_clinical_rcm_boundary.sql`: `MATERIALIZED`, `NOT_EXECUTED`.
- Billing denial in real PostgreSQL: `BLOCKED / UNVERIFIED`.
- Real clinical/billing service-role bindings: `BLOCKED / UNVERIFIED`.
- Independent security/privacy/domain review: `BLOCKED`.

## Non-decision / non-promotion

This ADR does **not** claim production security, LGPD compliance, real PostgreSQL permission denial, deployed services, or G5 passage. `CLIN-03`, `CLIN-04` and `CLIN-12` remain `OPEN`.
