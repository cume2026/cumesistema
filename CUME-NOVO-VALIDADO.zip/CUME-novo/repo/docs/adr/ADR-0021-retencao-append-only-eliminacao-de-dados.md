# ADR-0021 — Retenção × append-only × eliminação de dados

**Status técnico:** MATERIALIZED_DESIGN_DECISION  
**Status jurídico/privacidade:** LEGAL_REVIEW_PENDING  
**SETTLED:** NO

## Problema

O CUME precisa preservar trilhas de auditoria append-only e, simultaneamente, permitir que pedidos de titulares, término de tratamento e políticas de retenção sejam avaliados sem transformar “imutabilidade técnica” em pretexto para reter identidade direta indefinidamente.

## Decisão técnica candidata

1. **Retenção é versionada e orientada por fonte.** Cada política possui categoria, evento de início, valor/unidade de período, fonte, vigência e `legal_review_status`. Uma política não pode ficar `ACTIVE` no DDL candidato sem `LEGAL_REVIEWED`.
2. **Consentimento não é retenção.** Revogar consentimento ou solicitar eliminação não apaga automaticamente dados: o pedido passa pelo resolver de retenção e por holds aplicáveis. Isso modela a ressalva legal sem decidir qual base jurídica efetivamente se aplica a cada tratamento.
3. **Elegibilidade não é execução.** `DELETE_ELIGIBLE` e `ANONYMIZE_ELIGIBLE` significam somente que o motor de referência não encontrou uma regra ativa/hold que impeça a ação. A classificação **não prova eliminação executada**.
4. **Append-only não recebe hard delete automático.** Quando a retenção aplicável expirou, objetos de evidência append-only seguem `DETACH_OR_PSEUDONYMIZE_IDENTITY`: preserva-se a evidência mínima e rompe-se/se reduz a ligação direta com identidade, mediante `privacy.subject_identity_link` separado. A suficiência jurídica desta estratégia exige revisão qualificada.
5. **PII/saúde não deve ser copiada para payload de auditoria.** B-22 continua governando allowlist/denylist; o hash-chain de B-06 detecta adulteração, mas não cria exceção jurídica à eliminação.
6. **Crypto-shredding não é alegado.** Destruição criptográfica de chave só poderá ser classificada `MATERIALIZED/EXECUTED` quando existir hierarquia de chaves, envelope encryption, rotação, revogação e teste de irrecuperabilidade. Hoje: `NOT_MATERIALIZED`.
7. **Períodos expressos em anos permanecem anos-calendário.** A regra candidata de prontuário observada na Lei 13.787/2018 é representada como `20 YEARS`, não como um número fixo de dias.

## Consequências

- A trilha append-only e o direito de eliminação deixam de ser tratados como uma contradição binária.
- A identidade fica separável da evidência quando tecnicamente possível.
- Nenhuma política normativa é ativada automaticamente pela pesquisa web.
- Pedidos reais, descarte real, anonimização real e suficiência jurídica permanecem `BLOCKED` até runtime + processo operacional + revisão DPO/jurídica.

## Fontes observadas

Ver `governance/privacy_normative_sources_v1.json`. As fontes oficiais foram observadas em 2026-10-02; seu registro não equivale a parecer jurídico.
