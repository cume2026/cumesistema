# CUME Cycle 12 — B-15 + B-26 + B-27

## Canonical status

- B-15 privacy governance reference: `EXECUTED / OBSERVED / REFERENCE_ONLY`.
- B-26 consent + exact-channel preference: `EXECUTED / OBSERVED / REFERENCE_ONLY`.
- B-27 retention/erasure resolver: `EXECUTED / OBSERVED / REFERENCE_ONLY`.
- PostgreSQL migration `0020`: `MATERIALIZED / NOT_EXECUTED_POSTGRES`.
- Official public sources: `OBSERVED`; qualified legal/DPO review: `BLOCKED / NOT_EXECUTED`.
- Real DSAR, deletion, anonymization, messaging, incident response/tabletop: `BLOCKED / NOT_EXECUTED`.
- G10 remains `BLOCKED`.

## Key decisions

1. Consent is specific to purpose + notice version; it is not a general legal basis for all processing.
2. Channel preference is exact: WhatsApp does not imply SMS, e-mail, voice or push.
3. Processing activity cannot become ACTIVE in the candidate schema with UNKNOWN legal basis/retention; sensitive activity additionally requires a declared sensitive basis.
4. Retention rules are effective/versioned and cannot become ACTIVE before qualified legal review.
5. Calendar-year retention stays calendar-year based.
6. Erasure eligibility never self-attests execution.
7. Append-only evidence uses a candidate identity-detachment/pseudonymization boundary instead of automatic hard deletion; legal sufficiency remains pending.
8. Current public authority sources were observed on 2026-10-02 but are not equivalent to a legal opinion.
