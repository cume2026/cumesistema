#!/usr/bin/env python3
"""Gera governance/*_v0_5.* a partir dos v0.4 (arquivados em governance/archive_v0_4/). Reprodutível; idempotente."""
import json,yaml,shutil,re,unicodedata
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent;G=ROOT/'governance';A=G/'archive_v0_4'
for f in ['findings_registry_v0_4.json','gates_G0_G12_v0_4.yaml','backlog_v0_4.yaml']:
    if (G/f).exists(): A.mkdir(exist_ok=True);shutil.move(str(G/f),str(A/f))
reg=json.load((A/'findings_registry_v0_4.json').open());gates=yaml.safe_load((A/'gates_G0_G12_v0_4.yaml').open());bl=yaml.safe_load((A/'backlog_v0_4.yaml').open())
# 1) renomear CUME-DB-01..11 -> CUME-DB-01..11 (evita colisão com N01–N09 das vistorias do ChatGPT)
for f in reg['findings']:
    m=re.fullmatch(r'CUME-N(\d\d)',f['id'])
    if m: f['legacy_id']=f['id'];f['id']=f'CUME-DB-{m.group(1)}'
    else: f['legacy_id']=None
# 2) crosswalk com os IDs do ChatGPT (F01–F18, N01–N09 nas vistorias v1/v2)
X={'F-01':['F01','N01'],'F-02':['F02'],'F-03':['F03'],'F-04':['F04'],'F-05':['F05'],'F-06':['F06'],'F-07':['F06'],'F-09':['F11'],'F-11':['F07'],'F-12':['F08'],'F-13':['F09'],'F-14':['F10'],'F-15':['F12'],'F-08':['F12'],'F-16':['F13'],'F-17':['F14'],'F-18':['F15'],'F-20':['F18'],'F-23':['F11'],'F-25':['F17','N09'],'F-26':['F17'],'F-27':['F16'],'F-28':['F18'],
   'CLIN-01':['N02'],'CLIN-03':['N02'],'CLIN-12':['N02'],'CLIN-02':['N08'],'CLIN-11':['N08'],'CLIN-05':['N01'],'CLIN-06':['N07'],'CLIN-08':['N05'],'CLIN-09':['N07'],'CLIN-13':['N09']}
for f in reg['findings']: f['chatgpt_ids']=X.get(f['id'],[])
byid={f['id']:f for f in reg['findings']}
byid['F-01']['evidence']+=' | REPRODUZIDO PELO AUTOR (2026-10-01, harness Node sobre a classe do v2): agenda clínica -> agenda semanal gera n1 e n2, R$120 cada (evidence/prototype_v2_probe).'
OBS_BY_REPRO='OBSERVED_BY_REPRODUCTION (sandbox, n=1)'
new=[
 dict(id='CUME-DB-12',severity='P1',title='Transições de estado não eram impostas (o banco só validava o conjunto de estados)',evidence='claim podia saltar de DRAFT para CLOSED; nenhuma regra de transição existia em trigger/constraint (inspeção do DDL 0001–0008).',root_cause='CHECK de enum valida valores, não ordem',remediation='0009 gerada de spec/state_machines.yaml + test_09 (matriz exaustiva: 60 permitidas aceitas, 162 proibidas barradas)',residual='as TRANSIÇÕES são HIPÓTESE DE DOMÍNIO (DESIGNED): exigem validação por faturista/auditor médico/DPO (B-20)',state='VERIFIED (sandbox)',lifecycle_status='MITIGATED_PENDING_INDEPENDENT_REVIEW',source='ciclo 2 (sandbox, n=1)',legacy_id=None,chatgpt_ids=[]),
 dict(id='CUME-DB-13',severity='P1',title='Conteúdo de regras e contratos não é armazenado (apenas hashes)',evidence='rule_version(definition_hash) e contract_version(source_hash) não têm tabela de conteúdo; snapshot não é reproduzível a partir do banco.',root_cause='modelo guarda prova de integridade sem o objeto provado',remediation='PENDENTE: rule_definition/tariff_line endereçados por hash + teste de reprodução (B-21). DSL e avaliador de referência existem (spec/rules, domain_ref).',residual='aberto',state='OBSERVED (inspeção do DDL)',lifecycle_status='OPEN',source='ciclo 2',legacy_id=None,chatgpt_ids=[]),
 dict(id='CUME-DB-14',severity='P1',title='Colunas jsonb e texto livre podem carregar dado pessoal/de saúde',evidence='audit_event.before_state/after_state, outbox_event.payload, evidence.metadata, pricing_snapshot.inputs/intermediate_values e financial_adjustment.reason_text são livres (inventário de dados: 6 colunas jsonb + 1 texto livre).',root_cause='ausência de esquema fechado e de redação na gravação',remediation='PENDENTE (B-22): esquemas por tipo, redação, teste de chaves proibidas; eventos já têm JSON Schema fechado (spec)',residual='aberto',state='OBSERVED (inventário heurístico)',lifecycle_status='OPEN',source='ciclo 2',legacy_id=None,chatgpt_ids=[]),
 dict(id='CUME-DB-15',severity='P0',title='NaN aceito em colunas numeric; contorna o teto de alocação',evidence='payment.remitted_amount=NaN aceito; R$6.000.000 alocados contra esse pagamento sem erro (evidence/receipt_nan_bypass.txt). Em PG, NaN > 0 é verdadeiro.',root_cause='CHECK (x > 0) não exclui NaN; used > NaN é falso',remediation='0010: CHECK (col <> NaN) nas 11 colunas numeric; test_13 (catálogo + comportamento); mutantes nan_check e nan_fin_adj',residual='Infinity já é barrado pela precisão numeric(p,s)',state='VERIFIED (sandbox)',lifecycle_status='MITIGATED_PENDING_INDEPENDENT_REVIEW',source='ciclo 2 (sandbox, n=1)',legacy_id=None,chatgpt_ids=[]),
 dict(id='CLIN-14',severity='P1',title='Visita futura/pendente pode ser concluída e gera produção',evidence=OBS_BY_REPRO+': a9 (02/10, Pendente) concluída; cria ehr-a9 R$120; agenda a9 vira Realizada (evidence/prototype_v2_probe).',root_cause='sem máquina de estados de visita nem validação de data/médico',remediation='encounter/appointment state machines (0009) cobrem a ordem; regra de data/médico = serviço (B-01)',residual='aberto no protótipo',state=OBS_BY_REPRO,lifecycle_status='OPEN',source='ChatGPT v2 N03 (reproduzido pelo autor)',legacy_id=None,chatgpt_ids=['N03']),
 dict(id='F-34',severity='P1',title='Registro de outubro contamina totais de setembro (competência não é dimensão)',evidence=OBS_BY_REPRO+': total esperado 7.966,20 -> 8.086,20 ao concluir a9 (data 02/10). NÃO verifiquei por mim: guia 0901-0013 e exclusão no relatório de setembro (afirmadas pelo ChatGPT).',root_cause='competência derivada de texto de data',remediation='competência como dimensão tipada (B-24)',residual='aberto',state=OBS_BY_REPRO+' (parcial)',lifecycle_status='OPEN',source='ChatGPT v2 N04 (parcialmente reproduzido)',legacy_id=None,chatgpt_ids=['N04']),
 dict(id='CLIN-15',severity='P1',title='Relatório com placeholders ([data], [preencher]) é aceito e emitido',evidence=OBS_BY_REPRO+': texto com [data]/[especialidade]/[preencher] passou em docShow/docEmit; a validação é só de presença. (Conteúdo dos modelos do app não verificado por mim.)',root_cause='sem validação semântica de conteúdo',remediation='bloquear placeholders conhecidos com revisão explícita (domínio clínico futuro)',residual='aberto',state=OBS_BY_REPRO,lifecycle_status='OPEN',source='ChatGPT v2 N06 (reproduzido pelo autor)',legacy_id=None,chatgpt_ids=['N06']),
]
reg['findings']+=new
reg['metadata'].update(version='0.5',total=len(reg['findings']),closed=0,note='Nenhum finding é fechado sem revisor independente e receipt. IDs CUME-DB-01..N11 renomeados para CUME-DB-01..11 (colisão com N01–N09 do ChatGPT); legacy_id preservado.',generated='2026-10-01',id_policy='F-xx e CLIN-xx = numeração deste registro (≠ F01–F18/N01–N09 do ChatGPT; ver chatgpt_ids e 14_reconciliation)')
json.dump(reg,open(G/'findings_registry_v0_5.json','w'),ensure_ascii=False,indent=1)
# 3) gates
P={'G1':'Parcial: glossário (33 termos) e taxonomia em blueprint/01; falta aprovação de SME','G2':'Parcial: DDL com 33 tabelas (0001–0010); lacunas modeladas em CUME-DB-13/14 e entidades DESIGNED (coverage, consent, tariff content, settlement); falta revisão de domínio','G3':'Parcial: + máquinas de estado impostas (matriz exaustiva), propriedades (Hypothesis), paridade de hash Python==PG, NaN barrado; faltam invariantes de aplicação','G4':'Parcial: + fatia vertical motor de referência→snapshot→banco→faturabilidade; falta ledger ponta a ponta, importador, repasse, política de resto','G6':'Parcial: migrações 0001–0010 aplicam em PG 16.2 limpo; CI/Docker/restore NÃO executados; falta migração com dados','G9':'Spec apenas: adapter_pipeline.yaml e esquemas de evento validados sintaticamente; nada executável','G10':'Rascunhos: threat model, lacunas LGPD, inventário heurístico, runbook; sem revisão independente'}
for g in gates['gates']:
    g['v0_5_progress']=P.get(g['id'],'Sem avanço verificado no ciclo 2');g['status']='BLOCKED'
gates['version']='0.5';gates['note']='Todos BLOCKED: nenhum receipt foi revisado por pessoa independente. Revisão cruzada por outro modelo ajuda, mas não satisfaz o critério.'
yaml.safe_dump(gates,open(G/'gates_G0_G12_v0_5.yaml','w'),allow_unicode=True,sort_keys=False,width=200)
# 4) backlog
upd={'B-02':'v0.5: DSL + avaliador de referência + fatia vertical + propriedades; FALTA tabela de conteúdo (B-21), vigência por data (B-10), regras reais homologadas','B-12':'v0.5: fontes oficiais mapeadas (tiss_tuss_sigtap_sources.yaml); NADA baixado/validado','B-14':'v0.5: métricas/logs/dashboards ESPECIFICADOS (blueprint/08); nada instrumentado','B-15':'v0.5: inventário de dados (heurístico), threat model, RoPA template, lacunas LGPD; sem revisão do DPO','B-16':'v0.5: arquitetura/CI/runbooks ESPECIFICADOS; Docker/CI NÃO executados','B-17':'v0.5: estratégia/MVP/hipóteses/experimentos escritos; mercado e preço UNKNOWN'}
for it in bl['items']:
    if it['id'] in upd: it['v0_5_note']=upd[it['id']]
bl['items']+=[
 {'id':'B-20','prio':'P1','executor':'HUMAN','gates':['G2','G3'],'title':'Validar com faturista/auditor médico as transições de estado (spec/state_machines.yaml)','why':'hipótese de domínio imposta no banco (0009); errar aqui bloqueia fluxos legítimos ou libera ilegítimos','accept':['revisão assinada por SME','ajustes na spec regeneram 0009 e passam test_09']},
 {'id':'B-21','prio':'P0','executor':'AI','gates':['G4'],'title':'Tabelas de conteúdo de regra/contrato (CUME-DB-13)','do':['rule_definition e contract_content/tariff_line endereçados por hash','teste: recomputar snapshot a partir do banco reproduz o hash']},
 {'id':'B-22','prio':'P1','executor':'AI','gates':['G10'],'title':'Minimização de jsonb/texto livre (CUME-DB-14)','do':['esquemas fechados por tipo','redação na gravação','teste de chaves proibidas']},
 {'id':'B-23','prio':'P1','executor':'MIXED','gates':['G4'],'title':'Política de resto de arredondamento (ADR-0017)','why':'propriedade mostra diferença de até R$0,01 ao dividir valores'},
 {'id':'B-24','prio':'P1','executor':'MIXED','gates':['G2'],'title':'Competência como dimensão tipada e cálculo de prazos com relógio/fuso (F-34, ADV-020/021/049)'},
 {'id':'B-25','prio':'P1','executor':'AI','gates':['G3'],'title':'Parser monetário/data estrito pt-BR na camada de entrada (F-08, F-15; ADV-012)'},
 {'id':'B-26','prio':'P1','executor':'MIXED','gates':['G10'],'title':'Modelo de consentimento e preferência de canal (PRIV-06, F-17)'},
 {'id':'B-27','prio':'P1','executor':'HUMAN','gates':['G10'],'title':'Resolver conflito append-only × eliminação de dados (ADR-0021 + parecer jurídico)'},
 {'id':'B-28','prio':'P2','executor':'HUMAN','gates':['G0'],'title':'Revisão cruzada do pacote por outro modelo (ex.: ChatGPT) — útil, NÃO substitui B-19'}]
bl['version']='0.5';bl['cutoff']='2026-10-01'
yaml.safe_dump(bl,open(G/'backlog_v0_5.yaml','w'),allow_unicode=True,sort_keys=False,width=200)
# 5) ADRs propostos
D=ROOT/'docs'/'adr'
adrs={'0014':('Linguagem/stack de produção','Escolher UM stack (Python ou TypeScript) para domínio+API+worker. Hoje: referência Python (domain_ref) e TS no spine v0.3. Critérios: equipe, bibliotecas de Decimal/OIDC/OTel, testes de paridade de hash. Status: PROPOSED; decisão do dono.'),
 '0015':('Nuvem, região e jurisdição','Dados de saúde: residência no Brasil? Verificar com jurídico/DPO e contratos de suboperador. Status: PROPOSED; decisão e parecer pendentes.'),
 '0016':('Provedor de identidade (OIDC)','Gerenciado vs auto-hospedado; MFA como claim; custo e conformidade. Status: PROPOSED.'),
 '0017':('Política de resto de arredondamento','Propriedade (test_12): Σ partes arredondadas difere do total em até R$0,01. Opções: resto à maior parte; resto à última; regra contratual. Status: PROPOSED; precisa de faturista.'),
 '0018':('Fila/outbox','Postgres (SKIP LOCKED) vs broker. Começar com Postgres; revisar com carga medida. Status: PROPOSED.'),
 '0019':('Observabilidade e infraestrutura física','OTel + stack de métricas/logs; custo; retenção; sem K8s/microsserviços sem evidência. Status: PROPOSED.'),
 '0020':('Posicionamento de produto (RCM vs clínico vs integração)','Ver 12_product_business/product_strategy.md. Recomendação: RCM como MVP. Decisão do dono do produto. Status: PROPOSED.'),
 '0021':('Retenção × append-only × eliminação de dados','Conflito entre trilha imutável e direitos do titular/retenção. Hipótese: referências pseudonimizadas + chaves destruíveis (crypto-shredding) — exige parecer jurídico. Status: PROPOSED.'),
 '0022':('Versionamento de terminologias e crosswalk','Registro por competência; crosswalk TUSS↔SIGTAP N:N versionado; diff revisado por humano. Status: PROPOSED.')}
for k,(t,b) in adrs.items(): (D/f'ADR-{k}-{re.sub(r"[^a-z0-9]+","-",unicodedata.normalize("NFKD",t.lower()).encode("ascii","ignore").decode()).strip("-")[:40]}.md').write_text(f'# ADR-{k} — {t}\n\n**Status:** PROPOSED (rascunho; nenhuma decisão tomada)\n\n{b}\n\n**Consequências:** a preencher após decisão.\n',encoding='utf-8')
print('ok:',len(reg['findings']),'findings;',len(bl['items']),'itens de backlog;',len(adrs),'ADRs')
