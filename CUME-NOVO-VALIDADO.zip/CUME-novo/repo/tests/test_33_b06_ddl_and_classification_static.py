#!/usr/bin/env python3
import pathlib,json,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
checks=[]
def ck(label,cond): checks.append((label,bool(cond))); print((' ✔ ' if cond else ' ✘ FALHA ')+label)
mig=ROOT/'db/migrations/0014_audit_evidence_chain.sql'; reg=ROOT/'governance/cycle8_b06_registry.json'
ck('migration 0014 existe',mig.exists()); ck('registry B-06 existe',reg.exists())
if mig.exists():
 s=mig.read_text().lower()
 ck('sequence_no materializado','sequence_no' in s)
 ck('prev_hash materializado','prev_hash' in s)
 ck('event_hash materializado','event_hash' in s)
 ck('sequência única por tenant','unique (tenant_id, sequence_no)' in s)
 ck('head por tenant materializado','audit_chain_head' in s)
 ck('trigger serializa por tenant','for update' in s and 'audit_chain_head' in s)
 ck('hash inclui prev_hash','prev_hash' in s and 'audit_event_hash' in s)
 ck('evento continua append-only','audit_event_append_only' in s or 'forbid_mutation' in s)
 ck('evidence não pode ser órfã','evidence_must_link_source' in s)
 ck('artifact_hash formatado','evidence_artifact_hash_sha256' in s)
 ck('auditor recebe apenas leitura explícita','grant select on audit_event, evidence, source_document, audit_chain_head to cume_auditor' in s)
 ck('auditor não recebe escrita','grant insert' not in '\n'.join(x for x in s.splitlines() if 'cume_auditor' in x))
if reg.exists():
 r=json.loads(reg.read_text()); elems={e['id']:e for e in r['elements']}
 need={'B06_CHAIN_REFERENCE','B06_DDL_ENFORCEMENT','B06_AUDITOR_READ_ROLE','B06_EXTERNAL_CHECKPOINT'}
 ck('registry contém elementos mínimos',need<=set(elems))
 ck('reference executado/observado',elems['B06_CHAIN_REFERENCE']['classification']['epistemic_state']=='OBSERVED')
 ck('DDL apenas materializado',elems['B06_DDL_ENFORCEMENT']['classification']['epistemic_state']=='MATERIALIZED')
 ck('checkpoint externo não fingido',elems['B06_EXTERNAL_CHECKPOINT']['classification']['epistemic_state']=='BLOCKED')
bad=[x for x in checks if not x[1]]; print(f'== 33 B-06 DDL + classification static: {len(checks)-len(bad)} ok, {len(bad)} falha(s)'); sys.exit(1 if bad else 0)
