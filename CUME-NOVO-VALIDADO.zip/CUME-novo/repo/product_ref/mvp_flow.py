from __future__ import annotations
STATES=("PRODUCTION","CONFERENCE","PENDING_OR_DIVERGENCE","RESOLUTION","RECEIPT","REPORT")
_ALLOWED=set(zip(STATES,STATES[1:]))
class FlowError(ValueError): pass

def advance(current: str, target: str) -> str:
    if current not in STATES or target not in STATES:
        raise FlowError("unknown flow state")
    if (current,target) not in _ALLOWED:
        raise FlowError(f"illegal MVP transition: {current}->{target}")
    return target
