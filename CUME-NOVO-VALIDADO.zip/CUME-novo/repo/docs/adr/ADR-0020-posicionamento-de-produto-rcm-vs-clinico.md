# ADR-0020 — Posicionamento de produto (RCM vs clínico vs integração)

**Status:** PROPOSED (rascunho; nenhuma decisão tomada)

Ver 12_product_business/product_strategy.md. Recomendação: RCM como MVP. Decisão do dono do produto. Status: PROPOSED.

**Consequências:** a preencher após decisão.
