"""Implementação de REFERÊNCIA (Python) do pricing_snapshot_hash() do banco (migração 0008).
Objetivo: qualquer motor de regras (Python/TS/Java) deve produzir EXATAMENTE este hash; tests/test_10 prova a paridade contra o PostgreSQL.
Regras que o PG impõe e que aqui são reproduzidas: jsonb ordena chaves por (comprimento em bytes, bytes); separadores ', ' e ': ';
numeric preserva a escala do literal JSON (1.50 permanece 1.50; 1e2 vira 100); trim_scale() no valor monetário; timestamp em UTC com 6 casas."""
import json,hashlib
from decimal import Decimal
from datetime import datetime,timezone
def _num(d:Decimal)->str:
    s=format(d,'f')
    return s if 'E' not in s.upper() else format(d.quantize(Decimal(1)),'f')
def _enc(v)->str:
    if v is None: return 'null'
    if v is True: return 'true'
    if v is False: return 'false'
    if isinstance(v,Decimal): return _num(v)
    if isinstance(v,int): return str(v)
    if isinstance(v,str): return json.dumps(v,ensure_ascii=False)
    if isinstance(v,list): return '['+', '.join(_enc(x) for x in v)+']'
    if isinstance(v,dict):
        ks=sorted(v,key=lambda k:(len(k.encode('utf-8')),k.encode('utf-8')))
        return '{'+', '.join(json.dumps(k,ensure_ascii=False)+': '+_enc(v[k]) for k in ks)+'}'
    raise TypeError(type(v))
def parse_json(txt:str):
    return json.loads(txt,parse_float=Decimal,parse_int=lambda s:Decimal(s))
def trim_scale_text(amt):
    if amt is None: return None
    d=Decimal(str(amt)) if not isinstance(amt,Decimal) else amt
    if d==0: return '0'
    t=format(d.normalize(),'f')
    return t
def pricing_snapshot_hash(rule:str,contract:str,cur:str,amt,status:str,inputs_json:str,inter_json:str,formula:str,ref:datetime)->str:
    ref_utc=ref.astimezone(timezone.utc)
    ts=ref_utc.strftime('%Y-%m-%dT%H:%M:%S.')+f'{ref_utc.microsecond:06d}Z'
    arr=[rule,contract,cur,trim_scale_text(amt),status,parse_json(inputs_json),parse_json(inter_json),formula,ts]
    return hashlib.sha256(_enc(arr).encode('utf-8')).hexdigest()
