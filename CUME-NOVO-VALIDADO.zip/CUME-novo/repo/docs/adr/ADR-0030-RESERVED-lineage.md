# ADR-0030 — RESERVED (lineage)

Status: **RESERVED — NO DECISION RECORDED**

This identifier was skipped historically. Phase 2/4 reserves it explicitly so it cannot later be reused as if it had always represented a substantive architectural decision.

- No architecture choice is introduced by this file.
- No gate or finding is promoted.
- The gap is preserved as lineage rather than silently renumbering later ADRs.
