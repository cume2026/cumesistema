# Como apresentar este pacote ao ChatGPT (e o que NÃO fazer)

## Princípio
O ChatGPT não deve "analisar tudo de novo". Ele já produziu três relatórios, e o primeiro (QA aprovado) foi contradito pelos seguintes. O que falta é **reconciliar, executar e tentar quebrar**. Dê a ele um papel por vez, com entregável verificável.

## Protocolo em 4 mensagens (uma por vez; espere cada resposta)
1. **PROMPT_1_CONTEXTO** + anexe `CUME_Complete_Package_v0_5.zip`. Objetivo: ele inventariar o que recebeu e confirmar os hashes. Não aceite resumo sem a lista de arquivos lidos.
2. **PROMPT_2_RECONCILIACAO**: cruzar os relatórios dele com `chatgpt_crosswalk.csv`. Ele deve apontar o que discorda, **com evidência**, e dizer o que consegue ou não reproduzir.
3. **PROMPT_3_CICLO2**: implementar UM item do backlog (recomendo B-21 e B-25, depois B-02/B-03), com receipt e **sem** alterar testes para passar.
4. **PROMPT_4_REVISAO_ADVERSARIAL**: tentar quebrar o pacote (migrações, spec de estados, regras, privacidade) e reportar findings.

## Regras que valem em todas as mensagens
- Exija **receipts** (comando, saída, ambiente). "Testei" sem saída não conta.
- Se ele não tiver PostgreSQL/Python no ambiente, deve dizer, não simular.
- Peça sempre a separação **observado / inferido / não verificado**.
- Peça diff mínimo: nada de reescrever o repositório.

## Limite importante (honestidade)
Revisão por outro modelo é **útil, mas não é o revisor independente humano** exigido pelos gates (B-19). Todos os 13 gates continuam BLOCKED até uma pessoa qualificada (técnica + faturamento/privacidade) revisar.

## Decisões que são suas (nenhum modelo deve tomar por você)
Posicionamento (ADR-0020), jurisdição/nuvem (0015), IdP (0016), política de resto de arredondamento (0017), retenção×eliminação (0021) e quem valida as transições de estado (B-20) e o conteúdo dos contratos.

## O que NÃO pedir
"Implemente tudo", "diga que está pronto", "gere o sistema completo", "gere preços/mercado/concorrentes" (não há dado: está como UNKNOWN de propósito).
