#!/usr/bin/env python3
from pathlib import Path
import argparse, importlib.metadata as md, json, sys
parser=argparse.ArgumentParser()
parser.add_argument('--allow-missing',action='store_true')
a=parser.parse_args()
repo=Path(__file__).resolve().parent.parent
lock=repo/'requirements-ci.lock'
expected={}
for raw in lock.read_text().splitlines():
    s=raw.strip()
    if not s or s.startswith('#'): continue
    if '==' not in s: raise SystemExit(f'unpinned requirement: {s}')
    n,v=s.split('==',1); expected[n]=v
rows=[]; bad=0
for n,v in expected.items():
    try: got=md.version(n); state='MATCH' if got==v else 'MISMATCH'
    except md.PackageNotFoundError: got=None; state='MISSING'
    if state=='MISMATCH' or (state=='MISSING' and not a.allow_missing): bad+=1
    rows.append({'package':n,'expected':v,'observed':got,'state':state})
print(json.dumps({'python':sys.version.split()[0],'requirements':rows,'bad':bad},indent=2))
raise SystemExit(1 if bad else 0)
