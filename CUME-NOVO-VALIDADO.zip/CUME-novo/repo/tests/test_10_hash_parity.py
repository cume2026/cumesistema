"""Paridade cross-language: domain_ref/pricing_hash.py (Python) == pricing_snapshot_hash() (PostgreSQL 0008) em casos de borda."""
import sys
from datetime import datetime,timezone,timedelta
from decimal import Decimal
sys.path.insert(0,str(__import__('pathlib').Path(__file__).resolve().parent.parent/'domain_ref'))
from pricing_hash import pricing_snapshot_hash as py_hash
from base import *
r=Report('10 paridade de hash Python == PostgreSQL')
uri=fresh('t10')
R,C=u(),u()
tz3=timezone(timedelta(hours=-3))
cases=[
 ('básico',          '150.00','PRICED','{"q":1}','{}','base*q',datetime(2026,3,1,tzinfo=timezone.utc)),
 ('escala 150.10',   '150.10','PRICED','{"q":1}','{}','base*q',datetime(2026,3,1,tzinfo=timezone.utc)),
 ('zero contratual', '0','CONTRACTUAL_ZERO','{}','{}','0',datetime(2026,3,1,tzinfo=timezone.utc)),
 ('unknown/NULL',    None,'UNKNOWN','{"motivo":"tarifa ausente"}','{}','n/a',datetime(2026,3,1,tzinfo=timezone.utc)),
 ('0.005 (3 casas)', '0.005','PRICED','{"a":1}','{}','x',datetime(2026,3,1,tzinfo=timezone.utc)),
 ('chaves fora de ordem/comprimento','99.99','PRICED','{"zz":1,"a":2,"mm":{"b":1,"aaa":2,"cc":3}}','{"y":[3,2,1],"x":null}','f',datetime(2026,3,1,tzinfo=timezone.utc)),
 ('números JSON: 1.50, 1e2, -0.10, 12345678901234567890','10.00','PRICED','{"a":1.50,"b":1e2,"c":-0.10,"d":12345678901234567890}','{"t":true,"f":false}','f',datetime(2026,3,1,tzinfo=timezone.utc)),
 ('unicode e escapes','10.00','PRICED','{"nome":"João Ação \\"q\\" \\\\ \\n \\t ç ü 😀"}','{}','a·b×c÷d',datetime(2026,3,1,tzinfo=timezone.utc)),
 ('timestamp µs e fuso -03:00','10.00','PRICED','{}','{}','f',datetime(2026,3,1,3,15,7,123456,tzinfo=tz3)),
 ('array aninhado vazio','10.00','PRICED','{"l":[[],[{}],[1,[2,[3]]]]}','{}','f',datetime(2026,12,31,23,59,59,999999,tzinfo=timezone.utc)),
 ('valor grande','123456789012345.67','PRICED','{"q":1}','{}','f',datetime(2026,3,1,tzinfo=timezone.utc)),
]
def esc(s): return s.replace("'","''")
for name,amt,st,inp,inter,f,ref in cases:
    iso=ref.astimezone(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.')+f'{ref.astimezone(timezone.utc).microsecond:06d}+00'
    sql=f"select pricing_snapshot_hash('{R}','{C}','BRL',{'NULL' if amt is None else amt},'{st}','{esc(inp)}'::jsonb,'{esc(inter)}'::jsonb,'{esc(f)}','{iso}')"
    rc,o=sh(uri,sql,t=True)
    db=o.strip() if rc==0 else f'ERRO {rc}'
    py=py_hash(R,C,'BRL',amt,st,inp,inter,f,ref)
    r.check(f'paridade: {name}',db==py,'' if db==py else f'db={db[:12]} py={py[:12]}')
r.done()
