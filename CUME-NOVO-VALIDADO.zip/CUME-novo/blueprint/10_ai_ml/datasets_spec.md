# Datasets (especificação) — nenhum dataset real existe neste pacote
| Dataset | Origem | Uso | Regras |
|---|---|---|---|
| `synthetic_core` | Gerador próprio (`repo/tests/seed.py`/fixtures; ampliar) | testes de invariantes, carga | 100% sintético; sem aparência de dado real (evitar nomes/CPF/telefones plausíveis) |
| `synthetic_returns` | Gerador de retornos TISS fictícios | testes de importador/matching | cobrir parcial/glosa/rejeição/duplicado/ambíguo; sementes fixas |
| `gold_matching` | Revisões humanas anonimizadas de design partners | avaliar AI-02/03 | base legal + anonimização; 2 rotuladores; κ; versionado |
| `gold_terminology_queries` | Faturistas | avaliar AI-06/07 | consultas reais sem PII |
| `calibration_set` | Separado do treino | ECE/Brier | nunca reutilizar o teste |
| `contracts_samples` | Contratos reais anonimizados | AI-05 | autorização contratual; remover identificadores |
Governança: cada dataset tem `dataset_id`, versão, hash, proveniência, base legal, retenção, finalidade; nenhum dado real sai do ambiente isolado.
