# CUME Cycle 14 — B-13 + B-17

## Scope
Local technical-spine materialization only. No production or pilot promotion.

## B-13
- TypeScript reference UI: MATERIALIZED → EXECUTED → OBSERVED_LOCAL.
- Server-only financial display contract: OBSERVED_LOCAL.
- Chromium 1280x900 pixel baseline: EXECUTED → OBSERVED_LOCAL.
- Chromium 390x844 mobile smoke: EXECUTED → OBSERVED_LOCAL.
- Browser semantic/accessibility smoke: EXECUTED → OBSERVED_LOCAL.
- axe/pa11y: BLOCKED_BY_DEPENDENCY / NOT_EXECUTED.
- Real API/auth/runtime integration: BLOCKED_EXTERNAL / NOT_EXECUTED.

## B-17
- Canonical MVP flow reference: MATERIALIZED → EXECUTED → OBSERVED_LOCAL.
- Market size, price, CAC, LTV: UNKNOWN / ABSTAIN pending experiments.
- Pilot: BLOCKED by G0–G10, restore and independent review.

## Non-promotion
G11 and G12 remain BLOCKED. Legacy frontend findings remain OPEN until actual replacement/decommission and independent accessibility review.
