-- CUME 0008 — regras/contratos versionados e aprovados; snapshot verificável; UNKNOWN != ZERO (candidate, dados sintéticos)
-- Pré-requisito: rule_version, contract_version e pricing_snapshot VAZIAS (colunas NOT NULL novas). Com dados, exige ADR de backfill.
BEGIN;
-- NOTA: sem btree_gist neste ambiente (Postgres embutido sem contribs): não-sobreposição via trigger + advisory lock.
-- Onde btree_gist existir, preferir EXCLUDE USING gist (tenant_id WITH =, <key> WITH =, tstzrange(effective_from,effective_to) WITH &&) [HIPÓTESE: não testado aqui].

-- 1) versões: aprovação obrigatória, sem sobreposição, só fechamento (aprovado) é permitido
ALTER TABLE rule_version     ADD COLUMN approval_id uuid NOT NULL, ADD COLUMN closure_approval_id uuid;
ALTER TABLE contract_version ADD COLUMN approval_id uuid NOT NULL, ADD COLUMN closure_approval_id uuid;
ALTER TABLE rule_version     ADD CONSTRAINT rule_version_approval_fk  FOREIGN KEY (tenant_id, approval_id) REFERENCES approval_request (tenant_id, approval_id),
                             ADD CONSTRAINT rule_version_closure_fk   FOREIGN KEY (tenant_id, closure_approval_id) REFERENCES approval_request (tenant_id, approval_id),
                             ADD CONSTRAINT rule_version_approval_uq  UNIQUE (approval_id), ADD CONSTRAINT rule_version_closure_uq UNIQUE (closure_approval_id),
                             ADD CONSTRAINT rule_version_closure_pair CHECK ((effective_to IS NULL) = (closure_approval_id IS NULL));
ALTER TABLE contract_version ADD CONSTRAINT contract_version_approval_fk FOREIGN KEY (tenant_id, approval_id) REFERENCES approval_request (tenant_id, approval_id),
                             ADD CONSTRAINT contract_version_closure_fk  FOREIGN KEY (tenant_id, closure_approval_id) REFERENCES approval_request (tenant_id, approval_id),
                             ADD CONSTRAINT contract_version_approval_uq UNIQUE (approval_id), ADD CONSTRAINT contract_version_closure_uq UNIQUE (closure_approval_id),
                             ADD CONSTRAINT contract_version_closure_pair CHECK ((effective_to IS NULL) = (closure_approval_id IS NULL));

CREATE FUNCTION version_no_overlap() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE keycol text := TG_ARGV[0]; pk text := TG_ARGV[1]; k text := to_jsonb(NEW)->>keycol; n int;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtextextended(NEW.tenant_id::text||'|'||TG_TABLE_NAME||'|'||k,0));
  EXECUTE format('SELECT count(*) FROM %I WHERE tenant_id=$1 AND %I=$2 AND %I<>$3 AND tstzrange(effective_from,effective_to) && tstzrange($4,$5)',TG_TABLE_NAME,keycol,pk)
    INTO n USING NEW.tenant_id,k,(to_jsonb(NEW)->>pk)::uuid,NEW.effective_from,NEW.effective_to;
  IF n>0 THEN RAISE EXCEPTION 'effectivity overlaps another version of %', k USING ERRCODE='exclusion_violation'; END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER rule_version_no_overlap_t     BEFORE INSERT OR UPDATE ON rule_version     FOR EACH ROW EXECUTE FUNCTION version_no_overlap('rule_key','rule_version_id');
CREATE TRIGGER contract_version_no_overlap_t BEFORE INSERT OR UPDATE ON contract_version FOR EACH ROW EXECUTE FUNCTION version_no_overlap('contract_key','contract_version_id');

CREATE FUNCTION version_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE op text := TG_ARGV[0]; pk text := TG_ARGV[1]; vid uuid; ap uuid; a approval_request%ROWTYPE;
BEGIN
  IF TG_OP='INSERT' THEN
    vid := (to_jsonb(NEW)->>pk)::uuid; ap := NEW.approval_id;
    IF NEW.effective_to IS NOT NULL THEN RAISE EXCEPTION 'version must be created open-ended' USING ERRCODE='check_violation'; END IF;
  ELSE
    vid := (to_jsonb(OLD)->>pk)::uuid;
    IF OLD.effective_to IS NOT NULL THEN RAISE EXCEPTION 'closed version is immutable' USING ERRCODE='integrity_constraint_violation'; END IF;
    IF (to_jsonb(OLD) - 'effective_to' - 'closure_approval_id') <> (to_jsonb(NEW) - 'effective_to' - 'closure_approval_id') THEN
      RAISE EXCEPTION 'version content is immutable; only approved closure allowed' USING ERRCODE='integrity_constraint_violation'; END IF;
    IF NEW.effective_to IS NULL THEN RAISE EXCEPTION 'version cannot be reopened/changed without closure' USING ERRCODE='integrity_constraint_violation'; END IF;
    IF NEW.effective_to <= OLD.effective_from THEN RAISE EXCEPTION 'closure must be after effective_from' USING ERRCODE='check_violation'; END IF;
    ap := NEW.closure_approval_id;
  END IF;
  SELECT * INTO a FROM approval_request WHERE tenant_id=NEW.tenant_id AND approval_id=ap;
  IF a.status IS DISTINCT FROM 'APPROVED' THEN RAISE EXCEPTION '% requires APPROVED approval (found %)', TG_OP, a.status USING ERRCODE='insufficient_privilege'; END IF;
  IF a.operation <> op OR a.subject_type <> TG_TABLE_NAME OR a.subject_id <> vid THEN
    RAISE EXCEPTION 'approval does not cover this version (operation/subject mismatch)' USING ERRCODE='insufficient_privilege'; END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER rule_version_guard_t     BEFORE INSERT OR UPDATE ON rule_version     FOR EACH ROW EXECUTE FUNCTION version_guard('RULE_CHANGE','rule_version_id');
CREATE TRIGGER contract_version_guard_t BEFORE INSERT OR UPDATE ON contract_version FOR EACH ROW EXECUTE FUNCTION version_guard('CONTRACT_CHANGE','contract_version_id');
CREATE TRIGGER rule_version_no_delete     BEFORE DELETE ON rule_version     FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
CREATE TRIGGER contract_version_no_delete BEFORE DELETE ON contract_version FOR EACH ROW EXECUTE FUNCTION forbid_mutation();

-- 2) pricing_snapshot: UNKNOWN != ZERO, data de referência, hash verificável, append-only
ALTER TABLE pricing_snapshot ALTER COLUMN expected_amount DROP NOT NULL;
ALTER TABLE pricing_snapshot ADD COLUMN price_status text NOT NULL CHECK (price_status IN ('PRICED','CONTRACTUAL_ZERO','UNKNOWN'));
ALTER TABLE pricing_snapshot ADD COLUMN reference_at timestamptz NOT NULL;
ALTER TABLE pricing_snapshot ADD CONSTRAINT pricing_status_amount CHECK (
  (price_status='PRICED' AND expected_amount IS NOT NULL AND expected_amount > 0)
  OR (price_status='CONTRACTUAL_ZERO' AND expected_amount IS NOT NULL AND expected_amount = 0)
  OR (price_status='UNKNOWN' AND expected_amount IS NULL));
-- ATENÇÃO (achado do teste): CHECK com resultado NULL PASSA em SQL; por isso o IS NOT NULL explícito acima (NULL>0 e NULL=0 são NULL, não FALSE).

CREATE FUNCTION pricing_snapshot_hash(rule uuid, contract uuid, cur text, amt numeric, st text, inputs jsonb, inter jsonb, formula text, ref timestamptz)
RETURNS text LANGUAGE sql IMMUTABLE AS $$
  SELECT encode(sha256(convert_to(jsonb_build_array(rule, contract, cur, trim_scale(amt)::text, st, inputs, inter, formula,
         to_char(ref AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'))::text,'UTF8')),'hex') $$;

CREATE FUNCTION pricing_snapshot_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE r rule_version%ROWTYPE; c contract_version%ROWTYPE;
BEGIN
  SELECT * INTO r FROM rule_version     WHERE tenant_id=NEW.tenant_id AND rule_version_id=NEW.rule_version_id;
  SELECT * INTO c FROM contract_version WHERE tenant_id=NEW.tenant_id AND contract_version_id=NEW.contract_version_id;
  IF NEW.reference_at < r.effective_from OR (r.effective_to IS NOT NULL AND NEW.reference_at >= r.effective_to) THEN
    RAISE EXCEPTION 'reference_at outside rule_version effectivity' USING ERRCODE='check_violation'; END IF;
  IF NEW.reference_at < c.effective_from OR (c.effective_to IS NOT NULL AND NEW.reference_at >= c.effective_to) THEN
    RAISE EXCEPTION 'reference_at outside contract_version effectivity' USING ERRCODE='check_violation'; END IF;
  IF NEW.snapshot_hash <> pricing_snapshot_hash(NEW.rule_version_id, NEW.contract_version_id, NEW.currency::text, NEW.expected_amount, NEW.price_status, NEW.inputs, NEW.intermediate_values, NEW.formula, NEW.reference_at) THEN
    RAISE EXCEPTION 'snapshot_hash does not match content' USING ERRCODE='check_violation'; END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER pricing_snapshot_guard_t BEFORE INSERT ON pricing_snapshot FOR EACH ROW EXECUTE FUNCTION pricing_snapshot_guard();
CREATE TRIGGER pricing_snapshot_append_only BEFORE UPDATE OR DELETE ON pricing_snapshot FOR EACH ROW EXECUTE FUNCTION forbid_mutation();
REVOKE UPDATE ON pricing_snapshot FROM cume_app;

-- 3) preço desconhecido não é faturável
CREATE FUNCTION claim_item_requires_priced() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE st text;
BEGIN
  SELECT ps.price_status INTO st FROM production_item pi JOIN pricing_snapshot ps ON ps.tenant_id=pi.tenant_id AND ps.pricing_snapshot_id=pi.pricing_snapshot_id
   WHERE pi.tenant_id=NEW.tenant_id AND pi.production_item_id=NEW.production_item_id;
  IF st IS DISTINCT FROM 'PRICED' AND st IS DISTINCT FROM 'CONTRACTUAL_ZERO' THEN
    RAISE EXCEPTION 'item with price_status % cannot be claimed (UNKNOWN != ZERO)', COALESCE(st,'<none>') USING ERRCODE='check_violation'; END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER claim_item_requires_priced_t BEFORE INSERT ON claim_item FOR EACH ROW EXECUTE FUNCTION claim_item_requires_priced();
COMMIT;
