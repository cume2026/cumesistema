-- CUME 0016 — B-09/B-10/B-24 candidate enforcement.
-- State: MATERIALIZED DDL CANDIDATE; NOT EXECUTED on dedicated CUME PostgreSQL in this cycle.
-- B-23 rounding policy is application-domain logic and is intentionally not duplicated in SQL here.

BEGIN;

-- B-09: NULL/absent remittance monetary values mean UNKNOWN, never zero.
ALTER TABLE remittance_item ADD COLUMN allowed_amount_status text;
ALTER TABLE remittance_item ADD COLUMN denied_amount_status text;
ALTER TABLE remittance_item ADD COLUMN contractual_adjustment_status text;
ALTER TABLE remittance_item ADD COLUMN other_adjustment_status text;

UPDATE remittance_item SET
  allowed_amount_status = CASE WHEN allowed_amount IS NULL THEN 'UNKNOWN' ELSE 'KNOWN' END,
  denied_amount_status = CASE WHEN denied_amount IS NULL THEN 'UNKNOWN' ELSE 'KNOWN' END,
  contractual_adjustment_status = CASE WHEN contractual_adjustment IS NULL THEN 'UNKNOWN' ELSE 'KNOWN' END,
  other_adjustment_status = CASE WHEN other_adjustment IS NULL THEN 'UNKNOWN' ELSE 'KNOWN' END;

ALTER TABLE remittance_item ALTER COLUMN allowed_amount_status SET NOT NULL;
ALTER TABLE remittance_item ALTER COLUMN denied_amount_status SET NOT NULL;
ALTER TABLE remittance_item ALTER COLUMN contractual_adjustment_status SET NOT NULL;
ALTER TABLE remittance_item ALTER COLUMN other_adjustment_status SET NOT NULL;

ALTER TABLE remittance_item ADD CONSTRAINT remittance_allowed_amount_semantics CHECK (
  (allowed_amount_status='UNKNOWN' AND allowed_amount IS NULL)
  OR (allowed_amount_status='KNOWN' AND allowed_amount IS NOT NULL));
ALTER TABLE remittance_item ADD CONSTRAINT remittance_denied_amount_semantics CHECK (
  (denied_amount_status='UNKNOWN' AND denied_amount IS NULL)
  OR (denied_amount_status='KNOWN' AND denied_amount IS NOT NULL));
ALTER TABLE remittance_item ADD CONSTRAINT remittance_contractual_adjustment_semantics CHECK (
  (contractual_adjustment_status='UNKNOWN' AND contractual_adjustment IS NULL)
  OR (contractual_adjustment_status='KNOWN' AND contractual_adjustment IS NOT NULL));
ALTER TABLE remittance_item ADD CONSTRAINT remittance_other_adjustment_semantics CHECK (
  (other_adjustment_status='UNKNOWN' AND other_adjustment IS NULL)
  OR (other_adjustment_status='KNOWN' AND other_adjustment IS NOT NULL));

-- B-10: the pricing reference instant is the performed-item service instant.
-- 0008 already validates that reference_at lies inside rule/contract effectivity windows.
CREATE OR REPLACE FUNCTION production_item_pricing_reference_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE pi performed_item%ROWTYPE; ps pricing_snapshot%ROWTYPE;
BEGIN
  SELECT * INTO pi FROM performed_item
    WHERE tenant_id=NEW.tenant_id AND performed_item_id=NEW.performed_item_id;
  SELECT * INTO ps FROM pricing_snapshot
    WHERE tenant_id=NEW.tenant_id AND pricing_snapshot_id=NEW.pricing_snapshot_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'pricing snapshot not found for production item' USING ERRCODE='foreign_key_violation';
  END IF;
  IF ps.reference_at IS DISTINCT FROM pi.performed_at THEN
    RAISE EXCEPTION 'pricing reference_at must equal performed_at' USING ERRCODE='check_violation';
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS production_item_pricing_reference_guard_t ON production_item;
CREATE TRIGGER production_item_pricing_reference_guard_t
BEFORE INSERT OR UPDATE OF performed_item_id, pricing_snapshot_id ON production_item
FOR EACH ROW EXECUTE FUNCTION production_item_pricing_reference_guard();

-- B-24: operational timezone is explicit. No timezone is fabricated for pre-existing tenants.
ALTER TABLE tenant ADD COLUMN operational_timezone text;
ALTER TABLE performed_item ADD COLUMN service_timezone text;
ALTER TABLE performed_item ADD COLUMN competence_month date;
ALTER TABLE performed_item ADD CONSTRAINT performed_item_competence_first_day CHECK (
  competence_month IS NULL OR date_trunc('month', competence_month)::date = competence_month);

CREATE OR REPLACE FUNCTION cume_timezone_exists(tz text) RETURNS boolean LANGUAGE sql STABLE AS $$
  SELECT EXISTS (SELECT 1 FROM pg_timezone_names WHERE name=tz)
$$;

CREATE OR REPLACE FUNCTION tenant_operational_timezone_guard() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.operational_timezone IS NULL OR btrim(NEW.operational_timezone)='' THEN
    RAISE EXCEPTION 'tenant operational_timezone is required' USING ERRCODE='not_null_violation';
  END IF;
  IF NOT cume_timezone_exists(NEW.operational_timezone) THEN
    RAISE EXCEPTION 'unknown operational_timezone %', NEW.operational_timezone USING ERRCODE='check_violation';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER tenant_operational_timezone_guard_t
BEFORE INSERT OR UPDATE OF operational_timezone ON tenant
FOR EACH ROW EXECUTE FUNCTION tenant_operational_timezone_guard();

CREATE OR REPLACE FUNCTION performed_item_temporal_guard() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE tz text;
BEGIN
  IF TG_OP='UPDATE' THEN
    IF NEW.performed_at IS DISTINCT FROM OLD.performed_at
       OR NEW.tenant_id IS DISTINCT FROM OLD.tenant_id
       OR NEW.service_timezone IS DISTINCT FROM OLD.service_timezone
       OR NEW.competence_month IS DISTINCT FROM OLD.competence_month THEN
      RAISE EXCEPTION 'service temporal fields are immutable' USING ERRCODE='integrity_constraint_violation';
    END IF;
    RETURN NEW;
  END IF;

  IF NEW.service_timezone IS NOT NULL OR NEW.competence_month IS NOT NULL THEN
    RAISE EXCEPTION 'client supplied service temporal fields are forbidden' USING ERRCODE='check_violation';
  END IF;
  SELECT operational_timezone INTO tz FROM tenant WHERE tenant_id=NEW.tenant_id;
  IF tz IS NULL THEN
    RAISE EXCEPTION 'tenant operational_timezone is required' USING ERRCODE='not_null_violation';
  END IF;
  IF NOT cume_timezone_exists(tz) THEN
    RAISE EXCEPTION 'unknown operational_timezone %', tz USING ERRCODE='check_violation';
  END IF;
  NEW.service_timezone := tz;
  NEW.competence_month := date_trunc('month', NEW.performed_at AT TIME ZONE tz)::date;
  RETURN NEW;
END $$;
CREATE TRIGGER performed_item_temporal_guard_t
BEFORE INSERT OR UPDATE ON performed_item
FOR EACH ROW EXECUTE FUNCTION performed_item_temporal_guard();

-- Existing rows are NOT silently assigned a timezone. They remain explicitly visible for controlled backfill.
CREATE OR REPLACE VIEW performed_item_temporal_backfill_needed AS
SELECT performed_item_id, tenant_id, performed_at
FROM performed_item
WHERE service_timezone IS NULL OR competence_month IS NULL;

COMMIT;
