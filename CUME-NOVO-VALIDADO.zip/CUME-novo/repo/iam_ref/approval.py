from __future__ import annotations
from dataclasses import dataclass, replace

class ApprovalError(ValueError): pass

@dataclass(frozen=True)
class Principal:
    user_id:str
    roles:frozenset[str]

@dataclass(frozen=True)
class ApprovalRequest:
    approval_id:str
    operation:str
    subject_type:str
    subject_id:str
    maker_id:str
    checker_id:str|None=None
    status:str='PENDING'

BILLING_MAKER={'BILLING_CLERK','BILLING_APPROVER'}
BILLING_CHECKER={'BILLING_APPROVER'}
OPS={'CONTRACT_CHANGE','RULE_CHANGE','FINANCIAL_ADJUSTMENT','WRITE_OFF','DENIAL_ACCEPT','PERMISSION_CHANGE','PHYSICIAN_SETTLEMENT'}

def validate_role_set(roles:set[str]|frozenset[str])->bool:
    r=set(roles)
    if 'SECURITY_ADMIN' in r and ({'BILLING_CLERK','BILLING_APPROVER'} & r):
        raise ApprovalError('SECURITY_ADMIN must be segregated from BILLING roles')
    return True

def _has_any(p:Principal, needed:set[str])->bool:
    validate_role_set(p.roles)
    return bool(set(p.roles)&needed)

def request_approval(operation:str,subject_type:str,subject_id:str,maker:Principal)->ApprovalRequest:
    import uuid
    if operation not in OPS: raise ApprovalError('unsupported operation')
    if operation=='PERMISSION_CHANGE':
        if not _has_any(maker,{'SECURITY_ADMIN'}): raise ApprovalError('maker lacks SECURITY_ADMIN')
    elif not _has_any(maker,BILLING_MAKER):
        raise ApprovalError('maker lacks active BILLING role')
    return ApprovalRequest(str(uuid.uuid4()),operation,subject_type,subject_id,maker.user_id)

def decide_approval(req:ApprovalRequest,checker:Principal,approve:bool)->ApprovalRequest:
    if req.status!='PENDING': raise ApprovalError('decided approval is immutable')
    if checker.user_id==req.maker_id: raise ApprovalError('maker and checker must differ')
    needed={'SECURITY_ADMIN'} if req.operation=='PERMISSION_CHANGE' else BILLING_CHECKER
    if not _has_any(checker,needed): raise ApprovalError('checker lacks required role')
    return replace(req,checker_id=checker.user_id,status='APPROVED' if approve else 'REJECTED')

def authorize_commit(operation:str,subject_type:str,subject_id:str,approval:ApprovalRequest)->bool:
    if approval.status!='APPROVED': raise ApprovalError('approval not APPROVED')
    if (approval.operation,approval.subject_type,approval.subject_id)!=(operation,subject_type,subject_id): raise ApprovalError('approval does not cover operation/subject')
    return True

def authorize_role_grant(assignment_id:str,*,target_user_id:str,role:str,grantor:Principal,approval:ApprovalRequest|None)->bool:
    if approval is None: raise ApprovalError('role grant requires approval')
    if target_user_id==grantor.user_id: raise ApprovalError('self grant forbidden')
    if not _has_any(grantor,{'SECURITY_ADMIN'}): raise ApprovalError('grantor lacks SECURITY_ADMIN')
    authorize_commit('PERMISSION_CHANGE','role_assignment',assignment_id,approval)
    return True
