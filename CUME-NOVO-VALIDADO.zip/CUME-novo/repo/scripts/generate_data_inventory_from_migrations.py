#!/usr/bin/env python3
"""Derive the public/clinical/rcm column inventory from canonical migrations.
No database is required. This is a drift guard, not a DPO adjudication.
"""
from __future__ import annotations
from pathlib import Path
import csv,re,sys,io

TARGET_SCHEMAS={'public','clinical','rcm'}
CONSTRAINT_START=('CONSTRAINT ','PRIMARY KEY','UNIQUE ','FOREIGN KEY','CHECK ','EXCLUDE ')

def strip_comments(s:str)->str:
    return re.sub(r'--[^\n]*','',s)

def split_top(s:str):
    out=[]; start=0; depth=0; inq=False; i=0
    while i < len(s):
        ch=s[i]
        if ch=="'":
            if inq and i+1<len(s) and s[i+1]=="'": i+=2; continue
            inq=not inq
        elif not inq:
            if ch=='(': depth+=1
            elif ch==')': depth-=1
            elif ch==',' and depth==0:
                out.append(s[start:i].strip()); start=i+1
        i+=1
    tail=s[start:].strip()
    if tail: out.append(tail)
    return out

def normalize_type(defn:str)->str:
    u=defn.strip()
    # remove constraints/defaults from the type tail
    m=re.split(r'\s+(?=NOT\s+NULL|NULL\b|DEFAULT\b|PRIMARY\s+KEY|UNIQUE\b|REFERENCES\b|CHECK\b|CONSTRAINT\b)',u,maxsplit=1,flags=re.I)
    t=m[0].strip().lower()
    if t in ('timestamptz','timestamp with time zone'): return 'timestamp with time zone'
    if t in ('timestamp','timestamp without time zone'): return 'timestamp without time zone'
    if t.startswith('numeric'): return 'numeric'
    if t.startswith('varchar') or t.startswith('character varying'): return 'character varying'
    if t.startswith('char(') or t=='char': return 'character'
    if t.endswith('[]'): return 'ARRAY'
    return t

def parse_col(piece:str):
    p=piece.strip()
    if not p or p.upper().startswith(CONSTRAINT_START): return None
    m=re.match(r'"?([A-Za-z_][A-Za-z0-9_]*)"?\s+(.+)$',p,re.S)
    if not m: return None
    name,rest=m.group(1),m.group(2).strip()
    typ=normalize_type(rest)
    nullable='NO' if re.search(r'\bNOT\s+NULL\b|\bPRIMARY\s+KEY\b',rest,re.I) else 'YES'
    return name,typ,nullable

def find_balanced(sql,start):
    depth=0; inq=False; i=start
    while i<len(sql):
        ch=sql[i]
        if ch=="'":
            if inq and i+1<len(sql) and sql[i+1]=="'": i+=2; continue
            inq=not inq
        elif not inq:
            if ch=='(': depth+=1
            elif ch==')':
                depth-=1
                if depth==0: return i
        i+=1
    raise ValueError('unbalanced CREATE TABLE')

def build_schema(mig_dir:Path):
    tables={}
    moves=[]
    for f in sorted(mig_dir.glob('0*.sql')):
        sql=strip_comments(f.read_text(encoding='utf-8'))
        # CREATE TABLE blocks
        for m in re.finditer(r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?((?:[A-Za-z_][\w]*\.)?[A-Za-z_][\w]*)\s*\(',sql,re.I):
            raw=m.group(1); schema,table=(raw.split('.',1) if '.' in raw else ('public',raw))
            end=find_balanced(sql,m.end()-1)
            cols=tables.setdefault((schema,table),{})
            for piece in split_top(sql[m.end():end]):
                c=parse_col(piece)
                if c: cols[c[0]]={'data_type':c[1],'nullable':c[2]}
        # schema moves
        for m in re.finditer(r'ALTER\s+TABLE\s+((?:[A-Za-z_]\w*\.)?[A-Za-z_]\w*)\s+SET\s+SCHEMA\s+([A-Za-z_]\w*)',sql,re.I):
            raw,new=m.group(1),m.group(2); old,tab=(raw.split('.',1) if '.' in raw else ('public',raw)); moves.append((old,tab,new))
        # ALTER TABLE statements; use semicolon chunks
        for stmt in sql.split(';'):
            m=re.match(r'\s*ALTER\s+TABLE\s+((?:[A-Za-z_]\w*\.)?[A-Za-z_]\w*)\s+(.+)$',stmt,re.I|re.S)
            if not m: continue
            raw,tail=m.group(1),m.group(2); schema,table=(raw.split('.',1) if '.' in raw else ('public',raw))
            cols=tables.setdefault((schema,table),{})
            for am in re.finditer(r'ADD\s+COLUMN\s+([A-Za-z_]\w*)\s+(.+?)(?=,\s*ADD\s+COLUMN\b|,\s*ALTER\s+COLUMN\b|$)',tail,re.I|re.S):
                name,rest=am.group(1),am.group(2).strip()
                cols[name]={'data_type':normalize_type(rest),'nullable':'NO' if re.search(r'\bNOT\s+NULL\b',rest,re.I) else 'YES'}
            for nm in re.findall(r'ALTER\s+COLUMN\s+([A-Za-z_]\w*)\s+SET\s+NOT\s+NULL',tail,re.I):
                if nm in cols: cols[nm]['nullable']='NO'
            for nm in re.findall(r'ALTER\s+COLUMN\s+([A-Za-z_]\w*)\s+DROP\s+NOT\s+NULL',tail,re.I):
                if nm in cols: cols[nm]['nullable']='YES'
    # Apply schema moves by MERGING, because later migrations can already have altered the moved table.
    for old,tab,new in moves:
        if (old,tab) in tables:
            moved=tables.pop((old,tab))
            if (new,tab) in tables:
                moved.update(tables[(new,tab)])
            tables[(new,tab)]=moved
    # Inventory historically covers information_schema.columns, which includes views.
    # 0016 creates this three-column operational view; keep it derived rather than hard-coded in CSV.
    for f in sorted(mig_dir.glob('0*.sql')):
        sql=strip_comments(f.read_text(encoding='utf-8'))
        for m in re.finditer(r'CREATE\s+(?:OR\s+REPLACE\s+)?VIEW\s+((?:[A-Za-z_]\w*\.)?[A-Za-z_]\w*)\s+AS\s+SELECT\s+(.+?)\s+FROM\s+',sql,re.I|re.S):
            raw,selects=m.group(1),m.group(2); schema,view=(raw.split('.',1) if '.' in raw else ('public',raw))
            cols=tables.setdefault((schema,view),{})
            for expr in split_top(selects):
                alias=re.search(r'\s+AS\s+([A-Za-z_]\w*)\s*$',expr,re.I)
                name=alias.group(1) if alias else expr.strip().split('.')[-1].strip()
                if re.fullmatch(r'[A-Za-z_]\w*',name): cols[name]={'data_type':'UNKNOWN_VIEW_DERIVED','nullable':'YES'}
    return tables

def classify(table,col,typ):
    c=col.lower(); t=table.lower()
    if c in {'granted_by'}:
        return 'TECHNICAL_IDENTIFIER','medium','Identificador interno do ator concedente; revisar com DPO'
    if c in {'version_number'}:
        return 'TECHNICAL_METADATA','low','Número de versão técnica'
    if c in {'sha256'}:
        return 'AUDIT_INTEGRITY','low','Digest criptográfico de integridade; vínculo pode ser sensível'
    if c.endswith('_id') or c in {'tenant_id','correlation_id'}:
        return 'TECHNICAL_IDENTIFIER','low','Chave técnica (UUID/identificador)'
    if c.endswith('_at') or c.endswith('_date') or c in {'created_at','updated_at','generated_at','period_start','period_end','competence_month'}:
        return 'TECHNICAL_METADATA','medium','Tempo/metadado operacional'
    if any(x in c for x in ('amount','currency','price','tariff')) or t in {'settlement','physician_settlement'}:
        return 'FINANCIAL_METADATA','medium','Dado financeiro; requer revisão DPO'
    if t in {'clinical_note','diagnostic_order','medication_order','clinical_document','document_version'} or any(x in c for x in ('diagnostic','medication','clinical','code')):
        return 'HEALTH_SENSITIVE','high','Potencial dado de saúde; requer revisão DPO'
    if c in {'display_name','email','phone','document_number'}:
        return 'PERSONAL_DIRECT_IDENTIFIER','high','Identificador pessoal direto'
    if 'hash' in c:
        return 'AUDIT_INTEGRITY','low','Hash/integridade; vínculo pode ser sensível'
    return 'TECHNICAL_METADATA','low','Classificação heurística; requer revisão DPO'

def load_existing(path:Path):
    if not path.exists(): return {}
    with path.open(encoding='utf-8',newline='') as f:
        return {(r['table'],r['column']):r for r in csv.DictReader(f)}

def build_rows(mig_dir:Path, existing_csv:Path|None=None):
    schema=build_schema(mig_dir); existing=load_existing(existing_csv) if existing_csv else {}
    rows=[]
    for (sch,tab),cols in sorted(schema.items()):
        if sch not in TARGET_SCHEMAS: continue
        for col,d in sorted(cols.items()):
            old=existing.get((tab,col),{})
            cl,risk,note=classify(tab,col,d['data_type'])
            rows.append({
                'schema':sch,'table':tab,'column':col,'data_type':old.get('data_type') or d['data_type'],
                'nullable':d['nullable'],'classification':(old.get('classification') if old.get('classification') not in ('',None,'UNCLASSIFIED') else cl),
                'sensitivity_risk':(old.get('sensitivity_risk') if old.get('sensitivity_risk') not in ('',None,'unknown') else risk),
                'retention_policy':old.get('retention_policy') or 'UNKNOWN (definir com DPO)',
                'legal_basis':old.get('legal_basis') or 'UNKNOWN (definir com DPO)',
                'classification_method':old.get('classification_method') or 'migration-derived heuristic; REQUER REVISÃO DO DPO',
                'note':old.get('note') or note,
            })
    return rows

def render_csv(rows):
    fields=['table','column','data_type','nullable','classification','sensitivity_risk','retention_policy','legal_basis','classification_method','note']
    buf=io.StringIO(newline='')
    w=csv.DictWriter(buf,fieldnames=fields,lineterminator='\n'); w.writeheader(); w.writerows({k:r[k] for k in fields} for r in rows)
    return buf.getvalue()

def main():
    repo=Path(__file__).resolve().parent.parent; pkg=repo.parent
    out=pkg/'blueprint/07_security_privacy/data_inventory.csv'
    rows=build_rows(repo/'db/migrations',out)
    rendered=render_csv(rows)
    if '--check' in sys.argv:
        if not out.exists() or out.read_text(encoding='utf-8') != rendered:
            print(f'DRIFT: {out} must be regenerated', file=sys.stderr)
            return 1
        unclassified=[r for r in rows if r['classification']=='UNCLASSIFIED' or r['sensitivity_risk']=='unknown']
        if unclassified:
            print(f'INCOMPLETE: {len(unclassified)} columns unclassified', file=sys.stderr)
            return 1
        print(f'OK inventory: {len(rows)} rows; unclassified=0')
        return 0
    out.write_text(rendered,encoding='utf-8')
    print(f'wrote {len(rows)} rows to {out}')
    return 0
if __name__=='__main__': raise SystemExit(main())
