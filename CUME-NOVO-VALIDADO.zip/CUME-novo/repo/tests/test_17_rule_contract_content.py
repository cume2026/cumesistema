"""B-21 integration: DB content -> reference evaluator -> snapshot hash -> PostgreSQL parity."""
import json, sys
from datetime import datetime, timezone
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / 'domain_ref'))
from content_address import (
    RULE_PROFILE, CONTRACT_PROFILE,
    rule_definition_payload, rule_definition_hash,
    contract_content_payload, contract_content_hash,
)
from rule_eval import evaluate
from pricing_hash import pricing_snapshot_hash as py_hash
from fixtures import *

r = Report('17 B-21 rule/contract content -> reproducible pricing snapshot')
uri = fresh('t17')
t = u()
r.expect('tenant sintético', sh(uri, f"insert into tenant(tenant_id,legal_name,operational_timezone) values('{t}','Tenant B21 sintético','America/Sao_Paulo')"), 'ok')
adm = add_user(uri,t,'adm-b21@sint.test'); clerk = add_user(uri,t,'clerk-b21@sint.test'); approver = add_user(uri,t,'approver-b21@sint.test')
grant(uri,t,clerk,'BILLING_CLERK',adm); grant(uri,t,approver,'BILLING_APPROVER',adm)

root = Path(__file__).resolve().parent.parent
defn = json.loads((root/'spec'/'rules'/'EXAMPLE_rule_ILLUSTRATIVE.json').read_text())
contract = {'procedimentos': {'P1': '150.00', 'P0': '0', 'PZ': '100.00'}}
rpayload = rule_definition_payload(defn); rhash = rule_definition_hash(defn)
cpayload = contract_content_payload(contract); chash = contract_content_hash(contract)

def esc(s): return s.replace("'", "''")

# Content address must be proven by the stored bytes, not trusted from the caller.
r.expect('hash incorreto de regra é barrado', sh(uri,
    f"insert into cume_content.rule_definition(tenant_id,definition_hash,serialization_profile,canonical_payload,definition) values('{t}','{'0'*64}','{RULE_PROFILE}','{esc(rpayload)}','{esc(rpayload)}'::jsonb)"),
    'fail','rule_definition_hash_matches_payload')
r.expect('rule_definition endereçada pelo hash', sh(uri,
    f"insert into cume_content.rule_definition(tenant_id,definition_hash,serialization_profile,canonical_payload,definition) values('{t}','{rhash}','{RULE_PROFILE}','{esc(rpayload)}','{esc(rpayload)}'::jsonb)"), 'ok')
r.expect('contract_content endereçado pelo hash', sh(uri,
    f"insert into cume_content.contract_content(tenant_id,source_hash,serialization_profile,canonical_payload,content) values('{t}','{chash}','{CONTRACT_PROFILE}','{esc(cpayload)}','{esc(cpayload)}'::jsonb)"), 'ok')

for code, amount in [('P1','150.00'),('P0','0'),('PZ','100.00')]:
    r.expect(f'tariff_line fiel ao conteúdo: {code}', sh(uri,
        f"insert into cume_content.tariff_line(tariff_line_id,tenant_id,source_hash,table_key,code,amount) values('{u()}','{t}','{chash}','procedimentos','{code}',{amount})"), 'ok')
r.expect('tariff_line divergente é barrada', sh(uri,
    f"insert into cume_content.tariff_line(tariff_line_id,tenant_id,source_hash,table_key,code,amount) values('{u()}','{t}','{chash}','procedimentos','P1',999)"),
    'fail','does not match contract_content')
r.expect('conteúdo de regra é append-only', sh(uri,
    f"update cume_content.rule_definition set serialization_profile=serialization_profile where tenant_id='{t}' and definition_hash='{rhash}'"),
    'fail','append-only')
r.expect('conteúdo de contrato é append-only', sh(uri,
    f"delete from cume_content.contract_content where tenant_id='{t}' and source_hash='{chash}'"),
    'fail','append-only')

rid, cid = u(), u()
ra = approve(uri,t,clerk,approver,'RULE_CHANGE','rule_version',rid)
ca = approve(uri,t,clerk,approver,'CONTRACT_CHANGE','contract_version',cid)
r.expect('rule_version referencia semanticamente conteúdo pelo mesmo hash', sh(uri,
    f"insert into rule_version(rule_version_id,tenant_id,rule_key,version,effective_from,definition_hash,approval_id) values('{rid}','{t}','{defn['rule_key']}','1','2026-01-01','{rhash}','{ra}')"), 'ok')
r.expect('contract_version referencia semanticamente conteúdo pelo mesmo hash', sh(uri,
    f"insert into contract_version(contract_version_id,tenant_id,contract_key,version,effective_from,source_hash,approval_id) values('{cid}','{t}','CT-B21','1','2026-01-01','{chash}','{ca}')"), 'ok')

resolved = q(uri, f"select count(*) from rule_version rv join cume_content.rule_definition rd on rd.tenant_id=rv.tenant_id and rd.definition_hash=rv.definition_hash where rv.tenant_id='{t}' and rv.rule_version_id='{rid}'")[0]
r.check('rule_version resolve exatamente um rule_definition', resolved == '1', resolved)
resolved = q(uri, f"select count(*) from contract_version cv join cume_content.contract_content cc on cc.tenant_id=cv.tenant_id and cc.source_hash=cv.source_hash where cv.tenant_id='{t}' and cv.contract_version_id='{cid}'")[0]
r.check('contract_version resolve exatamente um contract_content', resolved == '1', resolved)

# Reconstruct the engine inputs only from content persisted in PostgreSQL.
db_rule_text = q(uri, f"select definition::text from cume_content.rule_definition where tenant_id='{t}' and definition_hash='{rhash}'")[0]
db_rule = json.loads(db_rule_text)
db_tariffs = {}
for row in q(uri, f"select table_key,code,trim_scale(amount)::text from cume_content.tariff_line where tenant_id='{t}' and source_hash='{chash}' order by table_key,code"):
    table_key, code, amount = row.split('|')
    db_tariffs.setdefault(table_key, {})[code] = amount
res = evaluate(db_rule, {'procedure_code':'P1','participation_pct':'100','urgency':False,'quantity':1}, db_tariffs)
r.check('conteúdo do banco reproduz preço determinístico', res['price_status']=='PRICED' and res['expected_amount']=='150.00', f"{res['price_status']} {res['expected_amount']}")

ref = datetime(2026,3,1,12,0,tzinfo=timezone.utc)
inputs = json.dumps(res['inputs'], ensure_ascii=False)
inter = json.dumps(res['intermediate_values'], ensure_ascii=False)
h = py_hash(rid,cid,'BRL',res['expected_amount'],res['price_status'],inputs,inter,res['formula'],ref)
sid,out = insert_snapshot(uri,t,rid,cid,res['expected_amount'],res['price_status'],ref='2026-03-01T12:00:00Z',inputs=inputs,inter=inter,formula=res['formula'],hash_=h)
r.expect('snapshot reconstruído do conteúdo é aceito pelo banco', out, 'ok')
parity = q(uri, f"select snapshot_hash=pricing_snapshot_hash(rule_version_id,contract_version_id,currency,expected_amount,price_status,inputs,intermediate_values,formula,reference_at) from pricing_snapshot where pricing_snapshot_id='{sid}'")[0]
r.check('domain_ref/pricing_hash.py mantém paridade com PostgreSQL', parity == 't', parity)

r.done()
