# Rastreamento, correlação e auditoria (DESIGNED)
- **Correlation ID** em toda requisição/job/evento; propagado em logs, traces (OpenTelemetry/W3C traceparent), `outbox_event`, `audit_event.correlation_id`.
- **Três trilhas distintas**: (1) *logs de aplicação* (diagnóstico, efêmeros, sem PII), (2) *traces/métricas* (desempenho), (3) *`audit_event`* (prova, append-only, retenção por política). Nunca usar logs como prova.
- **Spans mínimos**: `command.<nome>` → `db.tx` → `rule.evaluate` → `outbox.enqueue`; importação: um span por estágio (`import.receive … import.commit`).
- **Auditoria de leitura**: leitura de dado clínico/financeiro sensível gera `audit_event` (a definir quais leituras; custo/volume a medir).
- **Amostragem**: traces com amostragem; auditoria sem amostragem.
- Ferramentas (alvo, não adotadas): OpenTelemetry SDK + Collector; Prometheus/Grafana ou serviço gerenciado; Loki/ELK para logs. A escolha final depende de custo e equipe (ADR-0019).
