"""FATIA VERTICAL: DSL -> avaliador Python -> snapshot (hash Python) -> banco aceita -> faturabilidade (UNKNOWN barrado). Prova o encaixe motor<->banco."""
import sys,json,hashlib
from pathlib import Path
from datetime import datetime,timezone
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'domain_ref'))
from rule_eval import evaluate,canonical_definition_hash
from pricing_hash import pricing_snapshot_hash as py_hash
from fixtures import *
r=Report('11 fatia vertical: motor de regras -> snapshot -> banco -> faturabilidade')
defn=json.loads((ROOT/'spec'/'rules'/'EXAMPLE_rule_ILLUSTRATIVE.json').read_text())   # ILUSTRATIVA: percentuais/valores NÃO são contratuais
tariffs={'procedimentos':{'P1':'150.00','P0':'0','PZ':'100.00'}}                     # conteúdo de contrato ILUSTRATIVO
uri=fresh('t11');s=S(uri);tA=u();F=build(s,tA)
rid,cid=u(),u();ra=approve(uri,tA,F['clerk'],F['approver'],'RULE_CHANGE','rule_version',rid);ca=approve(uri,tA,F['clerk'],F['approver'],'CONTRACT_CHANGE','contract_version',cid)
dh=canonical_definition_hash(defn);ch=hashlib.sha256(json.dumps(tariffs,sort_keys=True).encode()).hexdigest()
r.expect('regra com definition_hash = sha256(definição canônica)',sh(uri,f"insert into rule_version(rule_version_id,tenant_id,rule_key,version,effective_from,definition_hash,approval_id) values('{rid}','{tA}','{defn['rule_key']}','1','2026-01-01','{dh}','{ra}')"),'ok')
r.expect('contrato com source_hash = sha256(tarifas)',sh(uri,f"insert into contract_version(contract_version_id,tenant_id,contract_key,version,effective_from,source_hash,approval_id) values('{cid}','{tA}','CT-ILUSTRATIVO','1','2026-01-01','{ch}','{ca}')"),'ok')
ref=datetime(2026,3,1,12,0,tzinfo=timezone.utc)
cases=[('principal 100%, sem urgência',{'procedure_code':'P1','participation_pct':'100','urgency':False,'quantity':1},'PRICED','150.00'),
       ('auxiliar 30% + urgência 1,3',{'procedure_code':'P1','participation_pct':'30','urgency':True,'quantity':1},'PRICED','58.50'),
       ('quantidade 2',{'procedure_code':'P1','participation_pct':'100','urgency':False,'quantity':2},'PRICED','300.00'),
       ('tarifa explícita 0 => CONTRACTUAL_ZERO',{'procedure_code':'P0','participation_pct':'100','urgency':False,'quantity':1},'CONTRACTUAL_ZERO','0.00'),
       ('tarifa AUSENTE => UNKNOWN',{'procedure_code':'PX','participation_pct':'100','urgency':False,'quantity':1},'UNKNOWN',None),
       ('percentual ausente => UNKNOWN',{'procedure_code':'P1','urgency':False,'quantity':1},'UNKNOWN',None)]
expect_claim={'PRICED':'ok','CONTRACTUAL_ZERO':'ok','UNKNOWN':'fail'}
assert s.ins('claim',tA)[0]==0
for name,inp,st,amt in cases:
    res=evaluate(defn,inp,tariffs)
    r.check(f'motor: {name}',res['price_status']==st and res['expected_amount']==amt,f"{res['price_status']} {res['expected_amount']}")
    ij,mj=json.dumps(res['inputs'],ensure_ascii=False),json.dumps(res['intermediate_values'],ensure_ascii=False)
    h=py_hash(rid,cid,'BRL',res['expected_amount'],res['price_status'],ij,mj,res['formula'],ref)
    sid,out=insert_snapshot(uri,tA,rid,cid,res['expected_amount'],res['price_status'],ref='2026-03-01T12:00:00Z',inputs=ij,inter=mj,formula=res['formula'],hash_=h)
    r.expect(f'banco aceita snapshot com HASH CALCULADO EM PYTHON: {name}',out,'ok')
    rc,e,pi=s.ins('production_item',tA,over={'pricing_snapshot_id':sid});r.check(f'production_item criado: {name}',rc==0,e)
    r.expect(f'faturabilidade {st}: {name}',s.ins('claim_item',tA,over={'production_item_id':pi})[:2],expect_claim[st],'UNKNOWN != ZERO' if st=='UNKNOWN' else None)
bad=evaluate(defn,{'procedure_code':'P1','participation_pct':'100','urgency':False,'quantity':1},tariffs)
h=py_hash(rid,cid,'BRL','150.00','PRICED',json.dumps(bad['inputs']),json.dumps(bad['intermediate_values']),bad['formula'],ref)
r.expect('adulteração: mesmo hash com valor 999.00',insert_snapshot(uri,tA,rid,cid,'999.00','PRICED',ref='2026-03-01T12:00:00Z',inputs=json.dumps(bad['inputs']),inter=json.dumps(bad['intermediate_values']),formula=bad['formula'],hash_=h)[1],'fail','snapshot_hash')
r.done()
