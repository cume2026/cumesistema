# ADR-0026 — Clinical document authorship, signing state and server-recorded time

**Project scope:** `CUME_ONLY`  
**Decision state:** `SPECIFIED + MATERIALIZED`; reference behavior `EXECUTED + OBSERVED`; PostgreSQL enforcement `NOT_EXECUTED / BLOCKED`.

## Decision

CUME uses the existing `spec/state_machines.yaml` clinical-document machine as the single transition source. Every accepted document state change creates an immutable `document_version`; post-FINAL changes supersede the previous version. Authorship is derived from the authenticated server-side user context, never from free-form client input.

`SIGNED` is a workflow/attestation state and requires an active user linked to a practitioner with an active `PHYSICIAN` role scoped to the document's `practice_organization_id`. `FINAL` remains distinct from `SIGNED`; printing/exporting does not create `SIGNED`.

`server_recorded_at` is database-server time. Client-supplied evidentiary timestamps are forbidden. This does **not** constitute an independent trusted timestamp authority and does not by itself implement a cryptographic or ICP-Brasil signature.

## Consequences

- `clinical.document_version` stays append-only.
- `app.user_id` becomes a required transaction context for real clinical writes.
- Real PostgreSQL execution is required before the DDL can move from `MATERIALIZED` to `EXECUTED/OBSERVED`.
- Cryptographic signature provider/certificate-chain validation and independent TSA, if required by the final product/regulatory design, remain separate capabilities and cannot inherit the status of `SIGNED`.
