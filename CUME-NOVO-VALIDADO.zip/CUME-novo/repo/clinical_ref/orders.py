from dataclasses import dataclass
@dataclass(frozen=True)
class ClinicalNote: note_id:str; tenant_id:str; encounter_id:str; status:str
@dataclass(frozen=True)
class DiagnosticOrder: order_id:str; tenant_id:str; encounter_id:str; status:str
@dataclass(frozen=True)
class MedicationOrder: order_id:str; tenant_id:str; encounter_id:str; status:str
