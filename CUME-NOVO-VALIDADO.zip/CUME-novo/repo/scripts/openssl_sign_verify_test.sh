#!/bin/bash
set -euo pipefail
D=$(mktemp -d); trap 'rm -rf "$D"' EXIT
printf '%s\n' 'CUME synthetic release artifact' > "$D/artifact.txt"
openssl genpkey -algorithm ED25519 -out "$D/private.pem" >/dev/null 2>&1
openssl pkey -in "$D/private.pem" -pubout -out "$D/public.pem" >/dev/null 2>&1
openssl pkeyutl -sign -rawin -inkey "$D/private.pem" -in "$D/artifact.txt" -out "$D/artifact.sig" >/dev/null 2>&1
openssl pkeyutl -verify -rawin -pubin -inkey "$D/public.pem" -in "$D/artifact.txt" -sigfile "$D/artifact.sig" >/dev/null 2>&1
printf '%s\n' SIGNATURE_VERIFY_PASS
