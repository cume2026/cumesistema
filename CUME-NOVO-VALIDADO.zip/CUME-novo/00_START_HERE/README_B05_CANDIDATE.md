# CUME B-05 candidate — start here

B-05 adds a CUME-only clinical-document lifecycle reference and PostgreSQL enforcement candidate.

- Reference lifecycle/authorship: `EXECUTED + OBSERVED` locally.
- DDL 0013: `MATERIALIZED`, not executed against PostgreSQL in this host.
- `SIGNED`: authenticated workflow state; **not** evidence of a verified cryptographic/digital signature.
- `server_recorded_at`: server-side database time candidate; **not** an independent TSA.
- Findings CLIN-02/06/11 remain OPEN; gates G5/G8 remain BLOCKED.

Read `repo/docs/CYCLE7_B05_STATUS.md` and `repo/governance/cycle7_b05_registry.json` before promoting any status.
