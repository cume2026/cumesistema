# ADR-0024 — B-01 reference application boundary

**Project scope:** `CUME_ONLY`  
**Decision status:** `ACCEPTED_FOR_REFERENCE_ONLY`  
**Epistemic classification:** `MATERIALIZED → EXECUTED → OBSERVED` for the local reference; `VERIFIED = NO`; `SETTLED = NO`.

## Context

B-01 requires a minimum application service with signed-token authentication, tenant context per database transaction, runtime role separation, server-side identity/role authorization and MFA for critical operations. The current environment has no dedicated CUME PostgreSQL runtime and no CUME OIDC provider.

## Decision

Materialize a Python **reference boundary only**, without settling ADR-0014 (production language) or ADR-0016 (OIDC provider):

- `application_ref/oidc.py`: strict synthetic HS256 verifier for tests only;
- `application_ref/api.py`: in-process API contract; tenant comes from verified identity plus server-owned `(issuer, subject)` mapping; roles come from the server-side directory, not from JWT role claims;
- `application_ref/tenant_tx.py`: transaction-local tenant context via PostgreSQL `set_config('app.tenant_id', value, true)` and runtime-role guard;
- no HUMAN-OMEGA dependency or resource sharing.

## Security boundaries

`AVAILABLE != CONNECTED != AUTHORIZED != EXECUTABLE != VERIFIED`. A passing synthetic token test does **not** establish a real OIDC connection. A fake pooled connection does **not** verify PostgreSQL/pool reset semantics. A module called API does **not** establish a deployed network service.

## Consequences

B-01 is only partially advanced. Real OIDC/JWKS, dedicated CUME PostgreSQL, `cume_app` runtime connection, migration credential separation in a real secret store, pool reuse against PostgreSQL, and a deployed network API remain `BLOCKED/UNVERIFIED`.
