# CUME B-01 candidate — read first

Classification is mandatory. The local B-01 reference implementation is `OBSERVED`, but real OIDC, a dedicated PostgreSQL pool, the live `cume_app` role and a deployed network API are `BLOCKED/UNVERIFIED`.

Do not infer production readiness from tests 24–26. Do not reuse HUMAN-OMEGA infrastructure. See `repo/governance/cycle5_b01_registry.json` and `repo/docs/CYCLE5_B01_STATUS.md`.
