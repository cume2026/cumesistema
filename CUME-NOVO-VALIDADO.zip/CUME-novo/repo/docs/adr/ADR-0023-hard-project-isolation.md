# ADR-0023 — Hard project isolation for CUME

- **Date:** 2026-10-02
- **Status:** ACCEPTED_BY_OWNER / MATERIALIZED_AS_POLICY; runtime verification pending
- **Decision owner:** project owner
- **Requirement:** REQ-ISO-001
- **Invariant:** I-25
- **Policy:** `governance/project_isolation_policy_v1.json`

## Context
CUME and HUMAN-OMEGA are distinct products. Earlier blueprint material contained conceptual references suggesting that CUME could inherit governance or future AI behavior from HUMAN-OMEGA. The owner explicitly rejected that coupling and required complete operational and architectural independence.

## Decision
CUME SHALL be designed, deployed, operated, secured, observed, backed up and evolved as an autonomous system. It SHALL NOT share concrete runtime resources or required dependencies with HUMAN-OMEGA or another product.

A common vendor or public technology is not itself a shared architecture, provided CUME receives a distinct provider project/resource boundary, credentials and lifecycle. The only commonality permitted is administrative ownership, public standards and independently selected generic technology.

The following must be dedicated to CUME: repository; cloud project; database cluster and credentials; IAM client/tenant configuration; secrets; object storage; queues/workers; observability project/DSNs; CI/CD credentials and targets; deployment runtime; environment namespace; backup and disaster-recovery chain.

No exception mechanism exists in this ADR. Reversal requires an explicit new owner decision that supersedes this ADR; until then `exceptions_allowed=false` is normative.

## Consequences
1. Existing HUMAN-OMEGA resources cannot be used as CUME staging, CI, database, IAM, storage, observability or runtime.
2. Cross-project runtime calls cannot be a required dependency of CUME.
3. Active CUME architecture documents must not inherit design requirements from HUMAN-OMEGA.
4. Historical comparisons may be retained only under `reference/` and marked `SUPERSEDED_NON_OPERATIONAL`.
5. G12 cannot pass until the dedicated CUME provider project and its isolation have runtime receipts.

## Verification
- Static: `tests/test_18_project_isolation.py`.
- Runtime: dedicated cloud/database/runtime receipts, negative endpoint/secret scan, independent backup/restore evidence.
