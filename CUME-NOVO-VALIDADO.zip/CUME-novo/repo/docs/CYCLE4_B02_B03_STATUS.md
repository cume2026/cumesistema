# CUME Cycle 4 — B-02 + B-03

## Decision
Reference-only implementations were added. No finding or gate is closed.

## B-02
`domain_ref/rule_engine.py` wraps the existing `rule_eval.evaluate()` and canonical `pricing_hash.pricing_snapshot_hash()`; it does not define a second pricing formula or hash.
Observed locally: deterministic result, UNKNOWN != ZERO, explicit CONTRACTUAL_ZERO, version IDs fixed in snapshot, old snapshot object unchanged after a new contract calculation, canonical-hash oracle.
Not proven: PostgreSQL persistence, real/homologated contract content, effective-date selection (B-10), F-23/F-24 specialist validation, full property-based suite.

## B-03
`domain_ref/ledger.py` is a pure reference reconciliation model. It models source SHA-256, deterministic receipt, MATCHED/UNMATCHED, allocation, derived outstanding and payment conservation.
Observed locally: same document -> same identity/receipt; partial return does not settle absent/partial claims; unmatched remains visible and unallocated; over-allocation rejected.
Not proven: real file parser/adapter pipeline, PostgreSQL commit, maker-checker adjustments, remittance persistence, external integration, G4/G9.

## Epistemic state
B-02: EXECUTED_OBSERVED_REFERENCE_ONLY
B-03: EXECUTED_OBSERVED_REFERENCE_ONLY
G0-G12: unchanged BLOCKED
production_ready: false
pilot_ready: false
