from dataclasses import dataclass
from datetime import date, timedelta
import calendar

@dataclass(frozen=True)
class RetentionRule:
    policy_id: str
    data_category: str
    trigger_event: str
    minimum_value: int
    period_unit: str
    basis_source: str
    legal_review_status: str
    disposition_after_expiry: str
    def __post_init__(self):
        if self.minimum_value<=0: raise ValueError('RETENTION_PERIOD_MUST_BE_POSITIVE')
        if self.period_unit not in {'DAYS','YEARS'}: raise ValueError('INVALID_RETENTION_PERIOD_UNIT')
        if self.legal_review_status not in {'PENDING_LEGAL_REVIEW','LEGAL_REVIEWED'}:
            raise ValueError('INVALID_LEGAL_REVIEW_STATUS')
        if not all((self.policy_id,self.data_category,self.trigger_event,self.basis_source,self.disposition_after_expiry)):
            raise ValueError('INCOMPLETE_RETENTION_RULE')

@dataclass(frozen=True)
class RetentionDecision:
    action: str
    reason: str
    eligible_at: date|None
    executed: bool=False


def _add_calendar_years(d: date, years: int) -> date:
    target_year=d.year+years
    target_day=min(d.day,calendar.monthrange(target_year,d.month)[1])
    return date(target_year,d.month,target_day)


def _eligibility_date(rule: RetentionRule, trigger_date: date) -> date:
    if rule.period_unit=='YEARS': return _add_calendar_years(trigger_date,rule.minimum_value)
    return trigger_date+timedelta(days=rule.minimum_value)


def evaluate_retention(rule: RetentionRule, trigger_date: date, as_of: date, legal_hold: bool, anonymization_possible: bool, append_only: bool):
    if rule.legal_review_status!='LEGAL_REVIEWED':
        return RetentionDecision('MANUAL_REVIEW_REQUIRED','RETENTION_RULE_NOT_LEGALLY_REVIEWED',None,False)
    eligible_at=_eligibility_date(rule,trigger_date)
    if legal_hold:
        return RetentionDecision('RETAIN_RESTRICTED','ACTIVE_LEGAL_HOLD',eligible_at,False)
    if as_of<eligible_at:
        return RetentionDecision('RETAIN_RESTRICTED','MINIMUM_RETENTION_NOT_EXPIRED',eligible_at,False)
    if append_only:
        return RetentionDecision('DETACH_OR_PSEUDONYMIZE_IDENTITY','PRESERVE_APPEND_ONLY_EVIDENCE_WITHOUT_DIRECT_IDENTITY',eligible_at,False)
    if anonymization_possible:
        return RetentionDecision('ANONYMIZE_ELIGIBLE','RETENTION_EXPIRED_AND_ANONYMIZATION_AVAILABLE',eligible_at,False)
    return RetentionDecision('DELETE_ELIGIBLE','RETENTION_EXPIRED',eligible_at,False)


def resolve_erasure(request_basis: str, rule: RetentionRule|None, trigger_date: date, as_of: date, legal_hold: bool, append_only: bool):
    if not request_basis: raise ValueError('REQUEST_BASIS_REQUIRED')
    if rule is None:
        if legal_hold:
            return RetentionDecision('MANUAL_REVIEW_REQUIRED','LEGAL_HOLD_WITHOUT_RESOLVED_RETENTION_RULE',None,False)
        if append_only:
            return RetentionDecision('DETACH_OR_PSEUDONYMIZE_IDENTITY','NO_ACTIVE_RETENTION_RULE_BUT_APPEND_ONLY_EVIDENCE',None,False)
        return RetentionDecision('DELETE_ELIGIBLE','NO_ACTIVE_REVIEWED_RETENTION_RULE',None,False)
    return evaluate_retention(rule,trigger_date,as_of,legal_hold,False,append_only)
