from __future__ import annotations
from pathlib import Path
import hashlib,re

def _sha_file(p:Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
def build_manifest(root:Path)->dict:
    root=Path(root)
    fs={p.relative_to(root).as_posix():_sha_file(p) for p in sorted(root.rglob('*')) if p.is_file()}
    return {'schema':'CUME-RELEASE-MANIFEST-v1','files':fs}
def verify_manifest(root:Path,manifest:dict)->bool: return build_manifest(Path(root))==manifest
def build_sbom(root:Path,component_name:str)->dict:
    root=Path(root); comps=[]
    for p in sorted(root.rglob('*')):
        if p.is_file(): comps.append({'type':'file','name':p.relative_to(root).as_posix(),'hashes':[{'alg':'SHA-256','content':_sha_file(p)}]})
    return {'bomFormat':'CycloneDX','specVersion':'1.5','version':1,'metadata':{'component':{'type':'application','name':component_name}},'components':comps}
_SHA=re.compile(r'^sha256:[0-9a-f]{64}$')
def verify_rollback_descriptor(d:dict)->bool:
    return bool(_SHA.match(str(d.get('release_digest',''))) and _SHA.match(str(d.get('previous_release_digest',''))) and d.get('database_strategy') in {'forward_fix_only','restore_from_verified_backup'})
