# Arquitetura de segurança (DESIGNED; só o que está marcado VERIFICADO existe)

| Camada | Controle | Estado |
|---|---|---|
| Identidade | OIDC externo; banco guarda só (issuer, subject); MFA como claim exigido p/ operações críticas | DESIGNED (B-01); `mfa_enrolled` é só flag |
| Autorização | Escopos por papel (`access_matrix.yaml`) na API **+** RLS por tenant no banco | RLS **VERIFICADA (sandbox)**; escopos DESIGNED |
| Segregação de funções | maker≠checker; checker com papel ativo; decisão imutável; uso único | **VERIFICADA (sandbox)** |
| Integridade | append-only (audit, versões, snapshots, ajustes, aprovações); hash recomputado; FK composto de tenant; teto de alocação; máquinas de estado | **VERIFICADAS (sandbox)** |
| Privilégio mínimo no banco | `cume_app` sem DELETE/TRUNCATE/DDL; `cume_auditor` só leitura; credencial de migração separada | roles **VERIFICADAS**; separação de credencial NÃO implementada |
| Segredos | Fora do cliente e do repositório; cofre; rotação | DESIGNED |
| Transporte/repouso | TLS; criptografia em repouso e gestão de chaves; backups cifrados | DESIGNED |
| Entrada de arquivos | Quarentena, limites, parsers seguros, sem fórmulas ativas | DESIGNED |
| Cadeia de suprimentos | SBOM, scanner de dependências/segredos/containers, assinatura de artefato, build reprodutível | DESIGNED (`11_infra_deploy/ci`) |
| Auditoria | `audit_event` append-only separado de logs; leitura auditada | tabela **VERIFICADA**; geração automática NÃO existe |
| Resposta a incidentes | Runbook, contatos, notificação (ANPD/titulares quando aplicável — decisão do DPO/jurídico) | rascunho em `incident_response_runbook.md` |
| Isolamento entre produtos | Projeto, banco, IAM, secrets, storage, filas, observabilidade, CI/CD, runtime, backup e DR exclusivos do CUME | política MATERIALIZED; runtime dedicado ainda BLOCKED |

## Princípios
1. Frontend nunca é mecanismo de autorização. 2. Defesa em profundidade (API + RLS + privilégios). 3. Falhar fechado. 4. Nada de dado real em ambientes sem base legal/controles. 5. Separar log de aplicação de prova de auditoria. 6. **Declarar o que NÃO está feito**. 7. Recursos e dependências runtime de outros produtos ficam fora da trust boundary do CUME; ver CUME-ISO-001 / ADR-0023.

## Limites conhecidos (herdados do ADR-0013)
`app.tenant_id` é GUC de sessão alterável por aplicação comprometida; owner ignora RLS/triggers; custo de RLS não medido; pooler não testado.
