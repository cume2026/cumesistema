"""Canonical serialization profiles for content-addressed CUME rule/contract artifacts.

These profiles intentionally preserve the hash semantics already used by v0.5:
- rules: rule_eval.canonical_definition_hash (compact UTF-8 JSON, sorted keys);
- contracts: test_11 / contract_version.source_hash (json.dumps(sort_keys=True) defaults).

Changing either profile is a compatibility change and requires a new profile id.
"""
from __future__ import annotations
import hashlib
import json
from typing import Any

RULE_PROFILE = 'CUME-RULE-JSON-v1'
CONTRACT_PROFILE = 'CUME-CONTRACT-JSON-v1'


def rule_definition_payload(definition: dict[str, Any]) -> str:
    return json.dumps(definition, sort_keys=True, separators=(',', ':'), ensure_ascii=False)


def rule_definition_hash(definition: dict[str, Any]) -> str:
    return hashlib.sha256(rule_definition_payload(definition).encode('utf-8')).hexdigest()


def contract_content_payload(content: dict[str, Any]) -> str:
    # Compatibility contract: this is exactly the v0.5 test_11 source_hash profile.
    return json.dumps(content, sort_keys=True)


def contract_content_hash(content: dict[str, Any]) -> str:
    return hashlib.sha256(contract_content_payload(content).encode('utf-8')).hexdigest()
