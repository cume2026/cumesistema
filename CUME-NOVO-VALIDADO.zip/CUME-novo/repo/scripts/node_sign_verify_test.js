// Synthetic Ed25519 regression using Node's OpenSSL-backed crypto implementation.
// Keys remain in memory; no private material is written to the source tree.
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const artifact = Buffer.from('CUME synthetic release artifact\n', 'utf8');
const { privateKey, publicKey } = crypto.generateKeyPairSync('ed25519');
const signature = crypto.sign(null, artifact, privateKey);
assert(crypto.verify(null, artifact, publicKey, signature));
assert(!crypto.verify(null, Buffer.from('CUME modified artifact\n'), publicKey, signature));
const otherPublicKey = crypto.generateKeyPairSync('ed25519').publicKey;
assert(!crypto.verify(null, artifact, otherPublicKey, signature));
console.log(`SIGNATURE_VERIFY_PASS OpenSSL=${process.versions.openssl} tamper=rejected wrong_key=rejected`);
