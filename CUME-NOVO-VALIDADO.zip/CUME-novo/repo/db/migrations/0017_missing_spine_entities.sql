-- CUME 0017 — materialização das sete entidades de espinha previamente DESIGNED.
-- Classification: MATERIALIZED DDL CANDIDATE; NOT EXECUTED against PostgreSQL in this environment.
-- Terminal reconciliation: tenant-consistent FKs + canonical PHYSICIAN_SETTLEMENT approval subject.
BEGIN;

CREATE TABLE batch (
  batch_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  status text NOT NULL CHECK(status IN ('PREPARED','SUBMITTED','ACKNOWLEDGED','REJECTED','CLOSED')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, batch_id)
);
ALTER TABLE claim ADD COLUMN batch_id uuid;
ALTER TABLE claim ADD CONSTRAINT claim_batch_id_same_tenant
  FOREIGN KEY (tenant_id, batch_id) REFERENCES batch(tenant_id, batch_id);

CREATE TABLE settlement (
  settlement_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  currency char(3) NOT NULL DEFAULT 'BRL',
  settlement_amount numeric(19,2) NOT NULL CHECK(settlement_amount>=0)
    CONSTRAINT settlement_amount_not_nan CHECK(settlement_amount <> 'NaN'::numeric),
  period_start date NOT NULL,
  period_end date NOT NULL,
  status text NOT NULL CHECK(status IN ('DRAFT','APPROVED','POSTED','REVERSED')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, settlement_id),
  CHECK(period_end>=period_start)
);

CREATE TABLE physician_settlement (
  physician_settlement_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  settlement_id uuid NOT NULL,
  practitioner_id uuid NOT NULL,
  amount numeric(19,2) NOT NULL CHECK(amount>=0)
    CONSTRAINT physician_settlement_amount_not_nan CHECK(amount <> 'NaN'::numeric),
  approval_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, physician_settlement_id),
  UNIQUE (settlement_id, practitioner_id),
  UNIQUE (approval_id),
  FOREIGN KEY (tenant_id, settlement_id) REFERENCES settlement(tenant_id, settlement_id),
  FOREIGN KEY (tenant_id, practitioner_id) REFERENCES practitioner(tenant_id, practitioner_id),
  FOREIGN KEY (tenant_id, approval_id) REFERENCES approval_request(tenant_id, approval_id)
);

CREATE TABLE clinical.clinical_note (
  clinical_note_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  encounter_id uuid NOT NULL,
  document_id uuid,
  status text NOT NULL CHECK(status IN ('DRAFT','FINAL','SIGNED','AMENDED','CANCELLED','SUPERSEDED','ENTERED_IN_ERROR')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, clinical_note_id),
  FOREIGN KEY (tenant_id, encounter_id) REFERENCES encounter(tenant_id, encounter_id),
  FOREIGN KEY (tenant_id, document_id) REFERENCES clinical.clinical_document(tenant_id, document_id)
);

CREATE TABLE clinical.diagnostic_order (
  diagnostic_order_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  encounter_id uuid NOT NULL,
  terminology_version_id uuid REFERENCES terminology_version(terminology_version_id),
  code text NOT NULL,
  status text NOT NULL CHECK(status IN ('REQUESTED','SCHEDULED','COMPLETED','CANCELLED','ENTERED_IN_ERROR')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, diagnostic_order_id),
  FOREIGN KEY (tenant_id, encounter_id) REFERENCES encounter(tenant_id, encounter_id)
);

CREATE TABLE clinical.medication_order (
  medication_order_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  encounter_id uuid NOT NULL,
  medication_code_system text NOT NULL,
  medication_code text NOT NULL,
  status text NOT NULL CHECK(status IN ('DRAFT','ACTIVE','COMPLETED','CANCELLED','ENTERED_IN_ERROR')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, medication_order_id),
  FOREIGN KEY (tenant_id, encounter_id) REFERENCES encounter(tenant_id, encounter_id)
);

CREATE TABLE report_snapshot (
  report_snapshot_id uuid PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES tenant(tenant_id),
  report_type text NOT NULL,
  artifact_hash text NOT NULL CHECK(artifact_hash ~ '^[0-9a-f]{64}$'),
  generated_at timestamptz NOT NULL DEFAULT now(),
  parameters jsonb NOT NULL DEFAULT '{}'::jsonb,
  UNIQUE (tenant_id, report_snapshot_id)
);

CREATE OR REPLACE FUNCTION require_physician_settlement_approval() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE a approval_request%ROWTYPE;
BEGIN
  SELECT * INTO a
    FROM approval_request
   WHERE tenant_id=NEW.tenant_id AND approval_id=NEW.approval_id;
  IF NOT FOUND
     OR a.operation<>'PHYSICIAN_SETTLEMENT'
     OR a.status<>'APPROVED'
     OR a.subject_type<>'physician_settlement'
     OR a.subject_id<>NEW.physician_settlement_id THEN
    RAISE EXCEPTION 'covered PHYSICIAN_SETTLEMENT approval required' USING ERRCODE='insufficient_privilege';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER trg_physician_settlement_approval
  BEFORE INSERT OR UPDATE ON physician_settlement
  FOR EACH ROW EXECUTE FUNCTION require_physician_settlement_approval();

COMMIT;
