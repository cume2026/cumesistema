from pathlib import Path
import json,subprocess,shutil,os
HERE=Path(__file__).resolve().parent
tsc_js=os.environ.get('CUME_TSC_JS')
tsc=[shutil.which('node') or 'node',tsc_js] if tsc_js else [shutil.which('tsc')]
if not tsc[-1]:
    raise SystemExit('TypeScript compiler missing: add its bin directory to PATH')
subprocess.run([*tsc,'-p',str(HERE/'tsconfig.json')],check=True)
model={
 'title':'Reconciliação explicável',
 'items':[
  {'id':'production','label':'Produção','state':'OBSERVED','source':'reference dataset','evidence':'receipt:synthetic-production','lastUpdated':'2026-10-02T12:00:00Z','responsible':'Billing analyst','nextAction':'Conferir itens','displayValue':'12 itens'},
  {'id':'divergence','label':'Pendências / divergências','state':'ABSTAIN','source':'reconciliation service','evidence':'no real remittance loaded','lastUpdated':'2026-10-02T12:00:00Z','responsible':'Billing analyst','nextAction':'Importar retorno validado','displayValue':'UNKNOWN'},
  {'id':'receipt','label':'Recebimento','state':'BLOCKED','source':'ledger reference','evidence':'real payment source unavailable','lastUpdated':'2026-10-02T12:00:00Z','responsible':'Finance reviewer','nextAction':'Conectar fonte real','displayValue':'UNKNOWN'}
 ]
}
probe='const {renderApp}=require(process.argv[1]); const model=JSON.parse(process.argv[2]); process.stdout.write(renderApp(model));'
r=subprocess.run(['node','-e',probe,str(HERE/'build'/'render.js'),json.dumps(model,ensure_ascii=False)],check=True,capture_output=True,text=True)
css=(HERE/'tokens.css').read_text()
html='<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>CUME · Reconciliação explicável</title><style>'+css+'</style></head><body>'+r.stdout+'</body></html>'
(HERE/'dist').mkdir(exist_ok=True)
(HERE/'dist'/'index.html').write_text(html)
print(HERE/'dist'/'index.html')
